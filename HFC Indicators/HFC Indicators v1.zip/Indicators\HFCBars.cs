#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class HFCBars : Indicator
	{
		private double high,low,close,open,range;
		
		private Brush brshD100;
		private Brush brshD80;
		private Brush brshD20;
		private Brush brshD3060;
		
		private Brush brshD50;
		private Brush brshS50;
		
		
		
		private Brush brshS100;
		private Brush brshS80;
		private Brush brshS20;
		private Brush brshS3060;
		
		//Bullish
		private Brush D100 = Brushes.LimeGreen; //95% to 100%
		private Brush D80 = Brushes.LimeGreen; //78% to 94.99%
		private Brush D20 = Brushes.NavajoWhite; // 5.1% to 22%
		private Brush D3060 = Brushes.ForestGreen;
		
		//Insignificant
		private Brush DS50 = Brushes.Gray;
		
		//Bearish
		private Brush S100 = Brushes.OrangeRed; //5% to 0%
		private Brush S80 = Brushes.Tomato; //22% to 5.1%
		private Brush S20 = Brushes.LightGreen; //94.99% to 78%
		private Brush S3060 = Brushes.Coral;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"This is based on HLC bars and few thresholds";
				Name										= "HFCBars";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				EqColStrength								= true;
				
			}
			else if (State == State.Configure)
			{
			}
			else if (State == State.DataLoaded)
			{
			
				
				brshD50 = new SolidColorBrush(Color.FromArgb(190,78,168,222));
				brshD50.Freeze();
				//D50 = brshD100;
				
				brshS50 = new SolidColorBrush(Color.FromArgb(190,239,35,60));
				brshS50.Freeze();
				//S50 = brshD50;
				
				/*brshD20 = new SolidColorBrush(Color.FromArgb(255,234,196,213));
				brshD20.Freeze();
				D20 = brshD20;
				
				brshD3060 = new SolidColorBrush(Color.FromArgb(255,223,115,115));
				brshD3060.Freeze();
				D3060 = brshD3060;
				
	
				brshS100 = new SolidColorBrush(Color.FromArgb(255,128,155,206));
				brshS100.Freeze();
				S100 = brshS100;
				
				brshS80 = new SolidColorBrush(Color.FromArgb(255,149,184,209));
				brshS80.Freeze();
				S80 = brshS80;
				
				brshS20 = new SolidColorBrush(Color.FromArgb(255,214,234,223));
				brshS20.Freeze();
				S20 = brshS20;
				
				brshS3060 = new SolidColorBrush(Color.FromArgb(255,184,224,210));
				brshS3060.Freeze();
				S3060 = brshS3060;*/
				
			}
		}

		protected override void OnBarUpdate()
		{
			if (CurrentBar<2)
				return;
			
			//Add your custom indicator logic here.
			
			high =  High[0];
			low = Low[0];
			close = Close[0];
			open = Open[0];
			
			//BarBrushes[0] = D3060;
			
			CandleOutlineBrushes[0] = Brushes.DarkGray;
			
			//D100 and S100

		
			#region Bullish
			if (close > open)
			{
				range = ((low-close)/(high-low)*-1);// for human inderstandable multiplied -1, coz we always read from low to close
				if (range>=.97) 
				{
					BarBrushes[0] = D100;
				}
				else if (range>=.78 && range<.97) 
				{
					BarBrushes[0] = D100;
				}
				else if (range>=.45 && range<=.55) 
				{
					BarBrushes[0] = DS50;
					if (EqColStrength)
					{
					Draw.Dot(this,Time[0].ToString() + "B",true,0,low-TickSize,brshD50);
					}
				}
				else if (range>.03 && range<=.22) 
				{
					BarBrushes[0] = D20;
				}
				else
				{
					BarBrushes[0] = D3060;
				}
			}
			#endregion
			#region Bearish
			if (close < open)
			{
				range = ((low-close)/(high-low)*-1);
				if (range<=.03) 
				{
					BarBrushes[0] = S100;
				} else 
				if (range>.03 && range<=.22) 
				{
					BarBrushes[0] = S100;
				}
				else if (range>=.45 && range<=.55) 
				{
					BarBrushes[0] = DS50;
					if(EqColStrength)
					{
					Draw.Dot(this,Time[0].ToString() + "S",true,0,low-TickSize,brshS50);
					}
				}
				else if (range >= .78 && range<.97) 
				{
					BarBrushes[0] = S20;
				}
				else
				{
					BarBrushes[0] = S3060;
				}
			}
			#endregion			
			
		
		}
		
		#region Properties
		[NinjaScriptProperty]
		[Display(Name="Indicate Candle Color in Equal Strenght", Description="Mark only GapUps", Order=1, GroupName="Parameters")]
		public bool EqColStrength
		{ get; set; }
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HFCBars[] cacheHFCBars;
		public HFCBars HFCBars(bool eqColStrength)
		{
			return HFCBars(Input, eqColStrength);
		}

		public HFCBars HFCBars(ISeries<double> input, bool eqColStrength)
		{
			if (cacheHFCBars != null)
				for (int idx = 0; idx < cacheHFCBars.Length; idx++)
					if (cacheHFCBars[idx] != null && cacheHFCBars[idx].EqColStrength == eqColStrength && cacheHFCBars[idx].EqualsInput(input))
						return cacheHFCBars[idx];
			return CacheIndicator<HFCBars>(new HFCBars(){ EqColStrength = eqColStrength }, input, ref cacheHFCBars);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HFCBars HFCBars(bool eqColStrength)
		{
			return indicator.HFCBars(Input, eqColStrength);
		}

		public Indicators.HFCBars HFCBars(ISeries<double> input , bool eqColStrength)
		{
			return indicator.HFCBars(input, eqColStrength);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HFCBars HFCBars(bool eqColStrength)
		{
			return indicator.HFCBars(Input, eqColStrength);
		}

		public Indicators.HFCBars HFCBars(ISeries<double> input , bool eqColStrength)
		{
			return indicator.HFCBars(input, eqColStrength);
		}
	}
}

#endregion
