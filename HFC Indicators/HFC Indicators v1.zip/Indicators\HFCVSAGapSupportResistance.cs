#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class HFCVSAGapSupportResistance : Indicator
	{
		
		public int varTotBars = 0;
		public double k,l;
		public Brush TransparentDarkGrey;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"This is a exclusive indicator for Support & Resistance with respect to GapUps and GapDowns";
				Name										= "HFCVSAGapSupportResistance";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				GapUp					= true;
				GapDown					= true;
				LimitLookBack			= true;
				LookBackPeriod					= 150;
				density					= true;
				
				//My CustomBrush
				Brush TransparentDarkGrey = new SolidColorBrush(Color.FromArgb(10,100,100,100));
				TransparentDarkGrey.Freeze();
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
			if(LimitLookBack)
			{
				if (CurrentBar < LookBackPeriod)
					return;
			}
			else
			{
				if (CurrentBar <= 2)
					return;
			}
			
			varTotBars = Bars.Count;
			
			if (LimitLookBack)
			{
				#region Limit look back code
				if (CurrentBar>(varTotBars-LookBackPeriod))
				{
					for(int i = LookBackPeriod;i>0;i--)
					{
						// We will have to put the revrse count for bteer understanding, market moved f/w and index is in reverese.
						// This if condition will tell, if the current candle is opend GapUp from the previos candle
						//GapUp Logic
						if(GapUp)
						{
							if (High[i] < Low[i-1] && High[i] < Close[i-1] && High[i] < Open[i-1])
							{
								if (density)
								{
								Draw.RegionHighlightY(this,"GU"+Time[i].ToString(),false,High[i],Low[i-1],TransparentDarkGrey,Brushes.LightSkyBlue,10);
								}
								else
								{
								Draw.Text(this,"GU"+Time[0].ToString(),"--",0,Low[i-1],Brushes.LightSkyBlue);
								}
							}
						}
						
						//GapDownLogic
						if(GapDown)
						{
							if (Low[i] > High[i-1] && Low[i] > Close[i-1] && Low[i] > Open[i-1])
							{
								if (density)
								{
								Draw.RegionHighlightY(this,"GD"+Time[i].ToString(),false,Low[i],High[i-1],TransparentDarkGrey,Brushes.LightSalmon,10);									
								}
								else
								{
								Draw.Text(this,"GD"+Time[0].ToString(),"--",0,High[i-1],Brushes.LightSalmon);									
								}							
							}
						}
						
					}					
				}
				#endregion
			}
			else
			{
				if(GapUp)
				{
					if(Low[0]>High[1])
					{
						if(density)
						{
							Draw.RegionHighlightY(this,"GU"+Time[0].ToString(),false,High[1],Low[0],TransparentDarkGrey,Brushes.LightSkyBlue,10);
						}
						else
						{
							k = Low[0];
						}
					}
					if(!density)
					{
						Draw.Text(this,"GU"+Time[0].ToString(),"--",0,k,Brushes.LightSkyBlue);
					}
				}
				if(GapDown)
				{
					if(High[0]<Low[1])
					{
						if(density)
						{
							Draw.RegionHighlightY(this,"GD"+Time[0].ToString(),false,Low[1],High[0],TransparentDarkGrey,Brushes.LightSalmon,10);
						}
						else
						{
							l = High[0];
						}
					}
					if(!density)
					{
						Draw.Text(this,"GD"+Time[0].ToString(),"--",0,l,Brushes.LightSalmon);
					}
												
				}
				
			}
			
			
			
			

		}

		#region Properties
		[NinjaScriptProperty]
		[Display(Name="GapUp", Description="Mark only GapUps", Order=1, GroupName="Parameters")]
		public bool GapUp
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="GapDOwn", Description="Mark Only Mark Downs", Order=2, GroupName="Parameters")]
		public bool GapDown
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="Limit Lookback", Description="If Checked, The will limit the lookback within 'look back period'.", Order=3, GroupName="Parameters")]
		public bool LimitLookBack
		{ get; set; }

		[NinjaScriptProperty]
		[Range(4, int.MaxValue)]
		[Display(Name="Look Back Period", Description="The will find the gap ups or Gap Downs with in the Look back range", Order=4, GroupName="Parameters")]
		public int LookBackPeriod
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="Show Density Clusters", Description="If Checked, It will show density range, else single line", Order=5, GroupName="Parameters")]
		public bool density
		{ get; set; }
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HFCVSAGapSupportResistance[] cacheHFCVSAGapSupportResistance;
		public HFCVSAGapSupportResistance HFCVSAGapSupportResistance(bool gapUp, bool gapDown, bool limitLookBack, int lookBackPeriod, bool density)
		{
			return HFCVSAGapSupportResistance(Input, gapUp, gapDown, limitLookBack, lookBackPeriod, density);
		}

		public HFCVSAGapSupportResistance HFCVSAGapSupportResistance(ISeries<double> input, bool gapUp, bool gapDown, bool limitLookBack, int lookBackPeriod, bool density)
		{
			if (cacheHFCVSAGapSupportResistance != null)
				for (int idx = 0; idx < cacheHFCVSAGapSupportResistance.Length; idx++)
					if (cacheHFCVSAGapSupportResistance[idx] != null && cacheHFCVSAGapSupportResistance[idx].GapUp == gapUp && cacheHFCVSAGapSupportResistance[idx].GapDown == gapDown && cacheHFCVSAGapSupportResistance[idx].LimitLookBack == limitLookBack && cacheHFCVSAGapSupportResistance[idx].LookBackPeriod == lookBackPeriod && cacheHFCVSAGapSupportResistance[idx].density == density && cacheHFCVSAGapSupportResistance[idx].EqualsInput(input))
						return cacheHFCVSAGapSupportResistance[idx];
			return CacheIndicator<HFCVSAGapSupportResistance>(new HFCVSAGapSupportResistance(){ GapUp = gapUp, GapDown = gapDown, LimitLookBack = limitLookBack, LookBackPeriod = lookBackPeriod, density = density }, input, ref cacheHFCVSAGapSupportResistance);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HFCVSAGapSupportResistance HFCVSAGapSupportResistance(bool gapUp, bool gapDown, bool limitLookBack, int lookBackPeriod, bool density)
		{
			return indicator.HFCVSAGapSupportResistance(Input, gapUp, gapDown, limitLookBack, lookBackPeriod, density);
		}

		public Indicators.HFCVSAGapSupportResistance HFCVSAGapSupportResistance(ISeries<double> input , bool gapUp, bool gapDown, bool limitLookBack, int lookBackPeriod, bool density)
		{
			return indicator.HFCVSAGapSupportResistance(input, gapUp, gapDown, limitLookBack, lookBackPeriod, density);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HFCVSAGapSupportResistance HFCVSAGapSupportResistance(bool gapUp, bool gapDown, bool limitLookBack, int lookBackPeriod, bool density)
		{
			return indicator.HFCVSAGapSupportResistance(Input, gapUp, gapDown, limitLookBack, lookBackPeriod, density);
		}

		public Indicators.HFCVSAGapSupportResistance HFCVSAGapSupportResistance(ISeries<double> input , bool gapUp, bool gapDown, bool limitLookBack, int lookBackPeriod, bool density)
		{
			return indicator.HFCVSAGapSupportResistance(input, gapUp, gapDown, limitLookBack, lookBackPeriod, density);
		}
	}
}

#endregion
