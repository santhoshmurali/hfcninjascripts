#region Using declarations
using System;
using System.IO; //Added New for Telegram BOT
using System.Net; //Added New for Telegram BOT
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class HFCHeikenAshiCandleSticksEntry : Indicator
	{
		private HeikenAshi8 myHA8;
		private int index,check;
		private bool GoLong,GoShort;
		private double vPut = 0;
		private double vCall = 0;
		
		
		//Set-up for telegram BOT
		private DateTime dateTime;
		private string botUrl = "https://api.telegram.org/bot{0}/sendMessage?chat_id={1}&text={2}";
		private string apiKey = "821657137:AAFTYKH0sRIBIlJyVFUl9uqu3qlVNj5R4rA";
		private string chatId = "-1001431579079";
		private string messageText = "";
		private string instrumentName = "";
		private string contractMonth = "";
		private string signalSeries = "";
		private string CurrentDate = "";
		private string dataSeriesDate = "";
		private string indicatorName = "HeikenAshi CandleSticks Entry  \n";
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Signals Based on HeikenAshi and Candlestick Combination";
				Name										= "HFCHeikenAshiCandleSticksEntry";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				VMultiplier					= 100;
				
				TelegramAlert = false;
			}
			else if (State == State.Configure)
			{
				myHA8 = HeikenAshi8();
				check = 0;
				index = 1;
				
				GoLong = true;
				GoShort = false;
				TelegramAlert = true;

			}
			else if (State == State.DataLoaded)
			{
				instrumentName = Instrument.FullName;
				contractMonth = dateTime.Date.ToString("MMM");
				
				//Capture Current Date
				CurrentDate = DateTime.Now.ToString("dd-MM-yyyy");
								
				
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
			if (CurrentBar <2)
				return;
			
			vPut = Close[0] - (Close[0]%VMultiplier);
			vCall = vPut + VMultiplier;

			dataSeriesDate = Time[0].ToString().Substring(0,10);
			
			
			if (GoLong == true)
			{
			
				for(int i = 0;i<index;i++)
				{
				if (Close[i]>Open[i] && Close[i+1]>Open[i+1] && myHA8.HAClose[i]>myHA8.HAOpen[i] && myHA8.HAClose[i+1]>myHA8.HAOpen[i+1])
					check=check+1;
				else if (Close[i+1]==Open[i+1] && Close[i]>Open[i] && Close[i+2]>Open[i+2] && myHA8.HAClose[i]>myHA8.HAOpen[i] && myHA8.HAClose[i+2]>myHA8.HAOpen[i+2])
					check=check+1;
				}
				
				if(check==index)
				{
					Draw.Dot(this,"long"+Time[0].ToString(),true,0,Low[0] - (Low[0]-Open[0]),Brushes.Cyan);
					Draw.Text(this,"vCALL"+Time[0].ToString(),"CE- " + vCall.ToString(),0,Low[0] - (1.5*(Low[0]-Open[0])));
					//Alert("LongAlert", Priority.High, "Long Entry", NinjaTrader.Core.Globals.InstallDir+@"\sounds\Alert1.wav", 30, Brushes.Black, Brushes.Green);  
					
					//For Telegram Bot
					if (CurrentDate == dataSeriesDate && TelegramAlert == true)
					{
						signalSeries = indicatorName + instrumentName + " " + contractMonth + " " + vCall.ToString() + " CE";
						messageText = signalSeries;
						botUrl = "https://api.telegram.org/bot{0}/sendMessage?chat_id={1}&text={2}";
						botUrl = String.Format(botUrl, apiKey, chatId, messageText);
						WebRequest request = WebRequest.Create(botUrl);
						request.GetResponse();
					
						
						//signalSeries = "";
					}
					GoLong = false;
					GoShort = true;		
				}
				check=0;
			}		

			if (GoShort == true)
			{
			
				for(int i = 0;i<index;i++)
				{
				if (Close[i]<Open[i] && Close[i+1]<Open[i+1] && myHA8.HAClose[i]<myHA8.HAOpen[i] && myHA8.HAClose[i+1]<myHA8.HAOpen[i+1])
					check=check+1;
				else if (Close[i+1]==Open[i+1] && Close[i]<Open[i] && Close[i+2]<Open[i+2] && myHA8.HAClose[i]<myHA8.HAOpen[i] && myHA8.HAClose[i+2]<myHA8.HAOpen[i+2])
					check=check+1;
				}
				
				if(check==index)
				{
					Draw.Dot(this,"short"+Time[0].ToString(),true,0,High[0]  + (High[0]-Open[0]),Brushes.DeepPink);
					Draw.Text(this,"vPUT"+Time[0].ToString(),"PE- " + vPut.ToString(),0,High[0] +(1.5*(High[0]-Open[0])));
					//Alert("ShortAlert", Priority.High, "Short Entry", NinjaTrader.Core.Globals.InstallDir+@"\sounds\Alert1.wav", 30, Brushes.Black, Brushes.Red);  

					if (CurrentDate == dataSeriesDate && TelegramAlert == true)
					{
						signalSeries = indicatorName + instrumentName + " " + contractMonth + " " + vPut.ToString() + " PE";
						messageText = signalSeries;
						botUrl = "https://api.telegram.org/bot{0}/sendMessage?chat_id={1}&text={2}";
						botUrl = String.Format(botUrl, apiKey, chatId, messageText);
						WebRequest request = WebRequest.Create(botUrl);
						request.GetResponse();
						//Stream rs = request.GetResponse().GetResponseStream();
						//rs.Close();						
					}
					GoLong = true;
					GoShort = false;
				}
				check=0;
				
			}			
			
			
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(0.05, double.MaxValue)]
		[Display(Name="VMultiplier", Order=1, GroupName="Parameters")]
		public double VMultiplier
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="Telegram Alert", Order=1, GroupName="Parameters")]
		public bool TelegramAlert
		{ get; set; }
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HFCHeikenAshiCandleSticksEntry[] cacheHFCHeikenAshiCandleSticksEntry;
		public HFCHeikenAshiCandleSticksEntry HFCHeikenAshiCandleSticksEntry(double vMultiplier, bool telegramAlert)
		{
			return HFCHeikenAshiCandleSticksEntry(Input, vMultiplier, telegramAlert);
		}

		public HFCHeikenAshiCandleSticksEntry HFCHeikenAshiCandleSticksEntry(ISeries<double> input, double vMultiplier, bool telegramAlert)
		{
			if (cacheHFCHeikenAshiCandleSticksEntry != null)
				for (int idx = 0; idx < cacheHFCHeikenAshiCandleSticksEntry.Length; idx++)
					if (cacheHFCHeikenAshiCandleSticksEntry[idx] != null && cacheHFCHeikenAshiCandleSticksEntry[idx].VMultiplier == vMultiplier && cacheHFCHeikenAshiCandleSticksEntry[idx].TelegramAlert == telegramAlert && cacheHFCHeikenAshiCandleSticksEntry[idx].EqualsInput(input))
						return cacheHFCHeikenAshiCandleSticksEntry[idx];
			return CacheIndicator<HFCHeikenAshiCandleSticksEntry>(new HFCHeikenAshiCandleSticksEntry(){ VMultiplier = vMultiplier, TelegramAlert = telegramAlert }, input, ref cacheHFCHeikenAshiCandleSticksEntry);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HFCHeikenAshiCandleSticksEntry HFCHeikenAshiCandleSticksEntry(double vMultiplier, bool telegramAlert)
		{
			return indicator.HFCHeikenAshiCandleSticksEntry(Input, vMultiplier, telegramAlert);
		}

		public Indicators.HFCHeikenAshiCandleSticksEntry HFCHeikenAshiCandleSticksEntry(ISeries<double> input , double vMultiplier, bool telegramAlert)
		{
			return indicator.HFCHeikenAshiCandleSticksEntry(input, vMultiplier, telegramAlert);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HFCHeikenAshiCandleSticksEntry HFCHeikenAshiCandleSticksEntry(double vMultiplier, bool telegramAlert)
		{
			return indicator.HFCHeikenAshiCandleSticksEntry(Input, vMultiplier, telegramAlert);
		}

		public Indicators.HFCHeikenAshiCandleSticksEntry HFCHeikenAshiCandleSticksEntry(ISeries<double> input , double vMultiplier, bool telegramAlert)
		{
			return indicator.HFCHeikenAshiCandleSticksEntry(input, vMultiplier, telegramAlert);
		}
	}
}

#endregion
