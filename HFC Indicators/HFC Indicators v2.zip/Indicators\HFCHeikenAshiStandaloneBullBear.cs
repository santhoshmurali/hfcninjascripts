#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class HFCHeikenAshiStandaloneBullBear : Indicator
	{
		private HeikenAshi8 myHA;
		private double HAavgs, HAPrice;
		private bool GoLong,GoShort;
		private double vPut = 0;
		private double vCall = 0;		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter Call on Genuine Bull and Put and genuine Bear heiken ashi. Bull : Open == Low, bear : Open == High ";
				Name										= "HFCHeikenAshiStandaloneBullBear";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.Configure)
			{
				myHA = HeikenAshi8();
				
				GoLong = false;
				GoShort = false;
				
				vMultiplier = 100;				
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
			if (CurrentBar < 2)
				return;
			
			vPut = Close[0] - (Close[0]%vMultiplier);
			vCall = vPut + vMultiplier;
			
			//Green - Long : Open == Low
			if (myHA.HAOpen[0] == myHA.HALow[0])
			{
				if (GoLong==false)
				{
					GoLong = true;
					GoShort = false;
					HAPrice = myHA.HALow[0];
					Draw.ArrowUp(this,"CELong"+Time[0].ToString(),true,0,HAPrice,Brushes.DarkGreen);
					Draw.Text(this,"Long"+Time[0].ToString(),"CE- " + vCall.ToString(),0,HAPrice - (2*TickSize));
				}
			}
			//Red - Long : Open == High
			else if (myHA.HAOpen[0] == myHA.HAHigh[0])
			{
		
				if(GoShort == false)
				{
					GoLong = false;
					GoShort = true;
					//StayPut = false;
					HAPrice = myHA.HAHigh[0];
					Draw.ArrowDown(this,"CEShort"+Time[0].ToString(),true,0,HAPrice,Brushes.DarkRed);
					Draw.Text(this,"Long"+Time[0].ToString(),"PE- " + vPut.ToString(),0,HAPrice + (2*TickSize));
				}
				
			}			
		}
		#region Properties
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Strike Price Multiplier", Order=1, GroupName="Parameters")]
		public int vMultiplier
		{ get; set; }		
		
		#endregion		
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HFCHeikenAshiStandaloneBullBear[] cacheHFCHeikenAshiStandaloneBullBear;
		public HFCHeikenAshiStandaloneBullBear HFCHeikenAshiStandaloneBullBear(int vMultiplier)
		{
			return HFCHeikenAshiStandaloneBullBear(Input, vMultiplier);
		}

		public HFCHeikenAshiStandaloneBullBear HFCHeikenAshiStandaloneBullBear(ISeries<double> input, int vMultiplier)
		{
			if (cacheHFCHeikenAshiStandaloneBullBear != null)
				for (int idx = 0; idx < cacheHFCHeikenAshiStandaloneBullBear.Length; idx++)
					if (cacheHFCHeikenAshiStandaloneBullBear[idx] != null && cacheHFCHeikenAshiStandaloneBullBear[idx].vMultiplier == vMultiplier && cacheHFCHeikenAshiStandaloneBullBear[idx].EqualsInput(input))
						return cacheHFCHeikenAshiStandaloneBullBear[idx];
			return CacheIndicator<HFCHeikenAshiStandaloneBullBear>(new HFCHeikenAshiStandaloneBullBear(){ vMultiplier = vMultiplier }, input, ref cacheHFCHeikenAshiStandaloneBullBear);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HFCHeikenAshiStandaloneBullBear HFCHeikenAshiStandaloneBullBear(int vMultiplier)
		{
			return indicator.HFCHeikenAshiStandaloneBullBear(Input, vMultiplier);
		}

		public Indicators.HFCHeikenAshiStandaloneBullBear HFCHeikenAshiStandaloneBullBear(ISeries<double> input , int vMultiplier)
		{
			return indicator.HFCHeikenAshiStandaloneBullBear(input, vMultiplier);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HFCHeikenAshiStandaloneBullBear HFCHeikenAshiStandaloneBullBear(int vMultiplier)
		{
			return indicator.HFCHeikenAshiStandaloneBullBear(Input, vMultiplier);
		}

		public Indicators.HFCHeikenAshiStandaloneBullBear HFCHeikenAshiStandaloneBullBear(ISeries<double> input , int vMultiplier)
		{
			return indicator.HFCHeikenAshiStandaloneBullBear(input, vMultiplier);
		}
	}
}

#endregion
