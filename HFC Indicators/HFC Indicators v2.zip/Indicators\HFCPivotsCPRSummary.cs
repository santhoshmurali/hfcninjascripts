#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class HFCPivotsCPRSummary : Indicator
	{
		private double yesterS1,yesterR1,prevYesterS1,prevYesterR1,minS1,MaxR1;
		private double yesterH,yesterL,yesterC,pYesterH,pYesterL,pYesterC,yesterPP,pYesterPP;
		private double yesterTC,yesterBC,pYesterTC,pYesterBC;
		private double YesterDaySpreadPercent,PrevYesterDaySpreadPercent,CPRSpread,ConsolidatedSpreadPercent;
		
		private string yesterdayDate, daybeforeDate;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"We will see a summary of Pivot spread and CPRs for better planning";
				Name										= "HFCPivotsCPRSummary";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				
				
				pYesterdaySpread = true;
				pPrevYesterdaySpread = false;
				pCombinedSpread = false;
				pCPRSpread = true;
			}
			else if (State == State.Configure)
			{
				AddDataSeries(BarsPeriodType.Day,1);
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
			if (CurrentBars[1]<3 || CurrentBars[0]<3)
				return;
			
			yesterdayDate = Times[1][0].Date.Day.ToString()+" st/th";
			daybeforeDate = Times[1][1].Date.Day.ToString()+" st/th";
			//Yesterday HLC
			yesterH = Highs[1][0];
			yesterL = Lows[1][0];
			yesterC = Closes[1][0];
			yesterPP = (yesterH + yesterL + yesterC)/3;
			yesterBC = (yesterH + yesterL)/2;
			yesterTC = (yesterPP - yesterBC)+yesterPP;
			yesterS1 = 2 * yesterPP - yesterH;
			yesterR1 = 2 * yesterPP - yesterL;
			Print(yesterdayDate + " - " + yesterS1 + " - " + yesterR1);
			YesterDaySpreadPercent = Math.Round(Math.Log(yesterR1/yesterS1),3)*100;
			CPRSpread = Math.Round(Math.Log(yesterTC/yesterBC)*100,3);
			if (CPRSpread<0)
			{ 
				CPRSpread = CPRSpread*-1;
				
			}
			
			//Previous Yesterday HLC
			pYesterH = Highs[1][1];
			pYesterL = Lows[1][1];
			pYesterC = Closes[1][1];
			pYesterPP = (pYesterH + pYesterL + pYesterC)/3;
			pYesterBC = (pYesterH + pYesterL)/2;
			pYesterTC = (pYesterH - pYesterBC)+pYesterH;			
			prevYesterS1 = 2 * pYesterPP - pYesterH;
			prevYesterR1 = 2 * pYesterPP - pYesterL;
			PrevYesterDaySpreadPercent = Math.Round(Math.Log(prevYesterR1/prevYesterS1),3)*100;
			
			
			//Consolidated Spread
			ConsolidatedSpreadPercent = Math.Round(Math.Log(Math.Max(yesterR1,prevYesterR1)/Math.Min(yesterS1,prevYesterS1)),3)*100;
		}

		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
				// This sample should be used along side the help guide educational resource on this topic:
				// http://www.ninjatrader.com/support/helpGuides/nt8/en-us/?using_sharpdx_for_custom_chart_rendering.htm

				// Default plotting in base class. Uncomment if indicators holds at least one plot
				// in this case we would expect NOT to see the SMA plot we have as well in this sample script
				//base.OnRender(chartControl, chartScale);
					
				int startx = Convert.ToInt32(ChartPanel.W - (ChartPanel.W * .70));
			
				// define the point for the text to render
				SharpDX.Vector2 startPoint1 = new SharpDX.Vector2(startx, ChartPanel.Y+ChartPanel.H - 85);	
				SharpDX.Vector2 startPoint2 = new SharpDX.Vector2(startx, ChartPanel.Y+ChartPanel.H - 65);
				SharpDX.Vector2 startPoint3 = new SharpDX.Vector2(startx+100, ChartPanel.Y+ChartPanel.H - 65);
				SharpDX.Vector2 startPoint4 = new SharpDX.Vector2(startx+200, ChartPanel.Y+ChartPanel.H - 65);
				SharpDX.Vector2 startPoint5 = new SharpDX.Vector2(startx+300, ChartPanel.Y+ChartPanel.H - 65);
			
				SharpDX.Vector2 startPoint21 = new SharpDX.Vector2(startx, ChartPanel.Y+ChartPanel.H - 40);
				SharpDX.Vector2 startPoint31 = new SharpDX.Vector2(startx+100, ChartPanel.Y+ChartPanel.H - 40);
				SharpDX.Vector2 startPoint41 = new SharpDX.Vector2(startx+200, ChartPanel.Y+ChartPanel.H - 40);
				SharpDX.Vector2 startPoint51 = new SharpDX.Vector2(startx+300, ChartPanel.Y+ChartPanel.H - 40);
			
			

				
				// construct the text format with desired font family and size
				SharpDX.DirectWrite.TextFormat textFormat1 = new SharpDX.DirectWrite.TextFormat(Core.Globals.DirectWriteFactory, "Calibri", 14);
				SharpDX.DirectWrite.TextFormat textFormat2 = new SharpDX.DirectWrite.TextFormat(Core.Globals.DirectWriteFactory, "Calibri", 12);
				SharpDX.DirectWrite.TextFormat textFormat3 = new SharpDX.DirectWrite.TextFormat(Core.Globals.DirectWriteFactory, "Calibri", 24);
				
					
				// construct the text layout with desired text, text format, max width and height
				SharpDX.DirectWrite.TextLayout textLayout1 = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, "R1 - S1 Pivot Spreads in %", textFormat1, ChartPanel.W, ChartPanel.H);
				SharpDX.DirectWrite.TextLayout textLayout2 = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory,daybeforeDate, textFormat2, ChartPanel.W, ChartPanel.H);
				SharpDX.DirectWrite.TextLayout textLayout3 = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory,yesterdayDate , textFormat2, ChartPanel.W, ChartPanel.H);
				SharpDX.DirectWrite.TextLayout textLayout4 = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, "Consolidated", textFormat2, ChartPanel.W, ChartPanel.H);
				SharpDX.DirectWrite.TextLayout textLayout5 = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, "CPR", textFormat2, ChartPanel.W, ChartPanel.H);
				
				SharpDX.DirectWrite.TextLayout textLayout21 = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory,PrevYesterDaySpreadPercent.ToString()+"%", textFormat3, ChartPanel.W, ChartPanel.H);
				SharpDX.DirectWrite.TextLayout textLayout31 = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory,YesterDaySpreadPercent.ToString()+"%" , textFormat3, ChartPanel.W, ChartPanel.H);
				SharpDX.DirectWrite.TextLayout textLayout41 = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, ConsolidatedSpreadPercent.ToString()+"%", textFormat3, ChartPanel.W, ChartPanel.H);
				SharpDX.DirectWrite.TextLayout textLayout51 = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, CPRSpread.ToString()+"%", textFormat3, ChartPanel.W, ChartPanel.H);
				
				
				// create a rectangle which will automatically resize to the width/height of the textLayout
				SharpDX.RectangleF rectangleF1 = new SharpDX.RectangleF(startPoint1.X-5, startPoint1.Y-5,400, (textLayout1.Metrics.Height)+10);
				SharpDX.RectangleF rectangleF2 = new SharpDX.RectangleF(startPoint2.X-5, startPoint2.Y-5,100, (textLayout2.Metrics.Height)+10);
				SharpDX.RectangleF rectangleF3 = new SharpDX.RectangleF(startPoint3.X-5, startPoint3.Y-5,100, (textLayout3.Metrics.Height)+10);
				SharpDX.RectangleF rectangleF4 = new SharpDX.RectangleF(startPoint4.X-5, startPoint4.Y-5,100, (textLayout4.Metrics.Height)+10);			
				SharpDX.RectangleF rectangleF5 = new SharpDX.RectangleF(startPoint5.X-5, startPoint5.Y-5,100, (textLayout5.Metrics.Height)+10);
			
				SharpDX.RectangleF rectangleF21 = new SharpDX.RectangleF(startPoint21.X-5, startPoint21.Y-5,100, (textLayout2.Metrics.Height)+20);
				SharpDX.RectangleF rectangleF31 = new SharpDX.RectangleF(startPoint31.X-5, startPoint31.Y-5,100, (textLayout3.Metrics.Height)+20);
				SharpDX.RectangleF rectangleF41 = new SharpDX.RectangleF(startPoint41.X-5, startPoint41.Y-5,100, (textLayout4.Metrics.Height)+20);			
				SharpDX.RectangleF rectangleF51 = new SharpDX.RectangleF(startPoint51.X-5, startPoint51.Y-5,100, (textLayout5.Metrics.Height)+20);
					
					
				// define the brush used for the text and rectangle
				SharpDX.Direct2D1.SolidColorBrush customDXBrush1 = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, SharpDX.Color.Black);
				customDXBrush1.Opacity = 0.6f;
			
				SharpDX.Direct2D1.SolidColorBrush customDXBrush2 = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, SharpDX.Color.WhiteSmoke);
				customDXBrush2.Opacity = 0.6f;
				
				// Rectacngle  Background	
				SharpDX.Direct2D1.SolidColorBrush areaBrushDx1= new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, SharpDX.Color.Transparent);						
					areaBrushDx1.Opacity = 0.4f;
				
				SharpDX.Direct2D1.SolidColorBrush areaBrushDx2= new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, SharpDX.Color.YellowGreen);						
					areaBrushDx2.Opacity = 0.4f;
			
				SharpDX.Direct2D1.SolidColorBrush areaBrushDx3= new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, SharpDX.Color.SkyBlue);						
					areaBrushDx3.Opacity = 0.4f;
			
				SharpDX.Direct2D1.SolidColorBrush areaBrushDx4= new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, SharpDX.Color.Gold);						
					areaBrushDx4.Opacity = 0.4f;			

				SharpDX.Direct2D1.SolidColorBrush areaBrushDx5= new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, SharpDX.Color.PeachPuff);						
					areaBrushDx5.Opacity = 0.4f;		
			
				
				SharpDX.Direct2D1.SolidColorBrush areaBrushDx21= new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, SharpDX.Color.ForestGreen);						
					areaBrushDx21.Opacity = 0.6f;
			
				SharpDX.Direct2D1.SolidColorBrush areaBrushDx31= new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, SharpDX.Color.SteelBlue);						
					areaBrushDx31.Opacity = 0.6f;
			
				SharpDX.Direct2D1.SolidColorBrush areaBrushDx41= new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, SharpDX.Color.Goldenrod);						
					areaBrushDx41.Opacity = 0.6f;			

				SharpDX.Direct2D1.SolidColorBrush areaBrushDx51= new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, SharpDX.Color.DarkOrange);						
					areaBrushDx51.Opacity = 0.6f;			


				
				//RenderTarget.DrawRectangle(rectangleF1, customDXBrush);
				RenderTarget.FillRectangle(rectangleF1, areaBrushDx1);
			
				//RenderTarget.DrawRectangle(rectangleF2, customDXBrush);
				RenderTarget.FillRectangle(rectangleF2, areaBrushDx2);
				RenderTarget.FillRectangle(rectangleF21, areaBrushDx21);
				
				//RenderTarget.DrawRectangle(rectangleF3, customDXBrush);
				RenderTarget.FillRectangle(rectangleF3, areaBrushDx3);
				RenderTarget.FillRectangle(rectangleF31, areaBrushDx31);
				
				//RenderTarget.DrawRectangle(rectangleF4, customDXBrush);
				RenderTarget.FillRectangle(rectangleF4, areaBrushDx4);
				RenderTarget.FillRectangle(rectangleF41, areaBrushDx41);
			
				//RenderTarget.DrawRectangle(rectangleF5, customDXBrush);
				RenderTarget.FillRectangle(rectangleF5, areaBrushDx5);			
				RenderTarget.FillRectangle(rectangleF51, areaBrushDx51);			
					
				// execute the render target text layout command with desired values
				RenderTarget.DrawTextLayout(startPoint1, textLayout1, customDXBrush1);
				RenderTarget.DrawTextLayout(startPoint2, textLayout2, customDXBrush1);
				RenderTarget.DrawTextLayout(startPoint3, textLayout3, customDXBrush1);
				RenderTarget.DrawTextLayout(startPoint4, textLayout4, customDXBrush1);
				RenderTarget.DrawTextLayout(startPoint5, textLayout5, customDXBrush1);
			
				RenderTarget.DrawTextLayout(startPoint21, textLayout21, customDXBrush2);
				RenderTarget.DrawTextLayout(startPoint31, textLayout31, customDXBrush2);
				RenderTarget.DrawTextLayout(startPoint41, textLayout41, customDXBrush2);
				RenderTarget.DrawTextLayout(startPoint51, textLayout51, customDXBrush2);
		
				 

				// always dispose of textLayout, textFormat, or brush when finished
				textLayout1.Dispose();
				textLayout2.Dispose();
				textLayout3.Dispose();
				textLayout4.Dispose();
				textLayout5.Dispose();
				textLayout21.Dispose();
				textLayout31.Dispose();
				textLayout41.Dispose();
				textLayout51.Dispose();			
			
				textFormat1.Dispose();
				textFormat2.Dispose();
				textFormat3.Dispose();
				
				areaBrushDx1.Dispose();
				areaBrushDx2.Dispose();
				areaBrushDx3.Dispose();
				areaBrushDx4.Dispose();
				areaBrushDx5.Dispose();

				areaBrushDx21.Dispose();
				areaBrushDx31.Dispose();
				areaBrushDx41.Dispose();
				areaBrushDx51.Dispose();			
				
				
				customDXBrush1.Dispose();
				customDXBrush2.Dispose();
				
			
		}			
		
		
		
		
		
		#region Properties		
		[NinjaScriptProperty]
		[Display(Name="R1 - S1 Yesterday Spread", Order=1, GroupName="Display Spreads")]
		public bool pYesterdaySpread
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="R1 - S1 Previous Yesterday Spread", Order=2, GroupName="Display Spreads")]
		public bool pPrevYesterdaySpread
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="R1 - S1 Combined Spread", Order=3, GroupName="Display Spreads")]
		public bool pCombinedSpread
		{ get; set; }		

		[NinjaScriptProperty]
		[Display(Name="CPR Spread", Order=4, GroupName="Display Spreads")]
		public bool pCPRSpread
		{ get; set; }			
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HFCPivotsCPRSummary[] cacheHFCPivotsCPRSummary;
		public HFCPivotsCPRSummary HFCPivotsCPRSummary(bool pYesterdaySpread, bool pPrevYesterdaySpread, bool pCombinedSpread, bool pCPRSpread)
		{
			return HFCPivotsCPRSummary(Input, pYesterdaySpread, pPrevYesterdaySpread, pCombinedSpread, pCPRSpread);
		}

		public HFCPivotsCPRSummary HFCPivotsCPRSummary(ISeries<double> input, bool pYesterdaySpread, bool pPrevYesterdaySpread, bool pCombinedSpread, bool pCPRSpread)
		{
			if (cacheHFCPivotsCPRSummary != null)
				for (int idx = 0; idx < cacheHFCPivotsCPRSummary.Length; idx++)
					if (cacheHFCPivotsCPRSummary[idx] != null && cacheHFCPivotsCPRSummary[idx].pYesterdaySpread == pYesterdaySpread && cacheHFCPivotsCPRSummary[idx].pPrevYesterdaySpread == pPrevYesterdaySpread && cacheHFCPivotsCPRSummary[idx].pCombinedSpread == pCombinedSpread && cacheHFCPivotsCPRSummary[idx].pCPRSpread == pCPRSpread && cacheHFCPivotsCPRSummary[idx].EqualsInput(input))
						return cacheHFCPivotsCPRSummary[idx];
			return CacheIndicator<HFCPivotsCPRSummary>(new HFCPivotsCPRSummary(){ pYesterdaySpread = pYesterdaySpread, pPrevYesterdaySpread = pPrevYesterdaySpread, pCombinedSpread = pCombinedSpread, pCPRSpread = pCPRSpread }, input, ref cacheHFCPivotsCPRSummary);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HFCPivotsCPRSummary HFCPivotsCPRSummary(bool pYesterdaySpread, bool pPrevYesterdaySpread, bool pCombinedSpread, bool pCPRSpread)
		{
			return indicator.HFCPivotsCPRSummary(Input, pYesterdaySpread, pPrevYesterdaySpread, pCombinedSpread, pCPRSpread);
		}

		public Indicators.HFCPivotsCPRSummary HFCPivotsCPRSummary(ISeries<double> input , bool pYesterdaySpread, bool pPrevYesterdaySpread, bool pCombinedSpread, bool pCPRSpread)
		{
			return indicator.HFCPivotsCPRSummary(input, pYesterdaySpread, pPrevYesterdaySpread, pCombinedSpread, pCPRSpread);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HFCPivotsCPRSummary HFCPivotsCPRSummary(bool pYesterdaySpread, bool pPrevYesterdaySpread, bool pCombinedSpread, bool pCPRSpread)
		{
			return indicator.HFCPivotsCPRSummary(Input, pYesterdaySpread, pPrevYesterdaySpread, pCombinedSpread, pCPRSpread);
		}

		public Indicators.HFCPivotsCPRSummary HFCPivotsCPRSummary(ISeries<double> input , bool pYesterdaySpread, bool pPrevYesterdaySpread, bool pCombinedSpread, bool pCPRSpread)
		{
			return indicator.HFCPivotsCPRSummary(input, pYesterdaySpread, pPrevYesterdaySpread, pCombinedSpread, pCPRSpread);
		}
	}
}

#endregion
