#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.HFCTradingSystem
{
	public class HFCLevarageBasedEntryCalculator : Indicator
	{
		private string StrQuantity;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Formula = (Capital * Leverage)/Current Price";
				Name										= "HFCLevarageBasedEntryCalculator";
				Calculate									= Calculate.OnEachTick;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				IsAutoScale 								= false;
				LeveragePercent					= 7.5;
				Margin					= 10000;
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
			if (CurrentBar<2)
				return;
			StrQuantity = Math.Round((LeveragePercent * Margin)/Close[0],0).ToString();
		}

		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
				// This sample should be used along side the help guide educational resource on this topic:
				// http://www.ninjatrader.com/support/helpGuides/nt8/en-us/?using_sharpdx_for_custom_chart_rendering.htm

				// Default plotting in base class. Uncomment if indicators holds at least one plot
				// in this case we would expect NOT to see the SMA plot we have as well in this sample script
				//base.OnRender(chartControl, chartScale);
					
				// define the point for the text to render
				SharpDX.Vector2 startPoint1 = new SharpDX.Vector2(ChartPanel.X + 20, ChartPanel.Y+ChartPanel.H - 30);	

				
				// construct the text format with desired font family and size
				SharpDX.DirectWrite.TextFormat textFormat1 = new SharpDX.DirectWrite.TextFormat(Core.Globals.DirectWriteFactory, "Arial", 12);
				
					
				// construct the text layout with desired text, text format, max width and height
				SharpDX.DirectWrite.TextLayout textLayout1 = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, "Quantities You can Buy With Leverage of " + LeveragePercent.ToString() + "x , Committing Margin of " + Margin.ToString() + " : " + StrQuantity, textFormat1, ChartPanel.W, ChartPanel.H);
				
				
				
				// create a rectangle which will automatically resize to the width/height of the textLayout
				SharpDX.RectangleF rectangleF = new SharpDX.RectangleF(startPoint1.X-5, startPoint1.Y-5,	(textLayout1.Metrics.Width)+10, (textLayout1.Metrics.Height)+10);		
				
					
					
				// define the brush used for the text and rectangle
				SharpDX.Direct2D1.SolidColorBrush customDXBrush = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, SharpDX.Color.DarkBlue);
				customDXBrush.Opacity = 0.6f;
				
				// Rectacngle  Background	
				SharpDX.Direct2D1.SolidColorBrush areaBrushDx = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, SharpDX.Color.DodgerBlue);						
					areaBrushDx.Opacity = 0.4f;
				
				RenderTarget.DrawRectangle(rectangleF, customDXBrush);
				RenderTarget.FillRectangle(rectangleF, areaBrushDx);
			
			
					

					
				// execute the render target text layout command with desired values
				RenderTarget.DrawTextLayout(startPoint1, textLayout1, customDXBrush);
		
				 

				// always dispose of textLayout, textFormat, or brush when finished
				textLayout1.Dispose();
				areaBrushDx.Dispose();
				customDXBrush.Dispose();
				
			
		}			
		
		#region Properties
		[NinjaScriptProperty]
		[Range(1, double.MaxValue)]
		[Display(Name="Leverage Percent", Order=1, GroupName="Parameters")]
		public double LeveragePercent
		{ get; set; }

		[NinjaScriptProperty]
		[Range(3000, double.MaxValue)]
		[Display(Name="Margin", Order=2, GroupName="Parameters")]
		public double Margin
		{ get; set; }
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HFCTradingSystem.HFCLevarageBasedEntryCalculator[] cacheHFCLevarageBasedEntryCalculator;
		public HFCTradingSystem.HFCLevarageBasedEntryCalculator HFCLevarageBasedEntryCalculator(double leveragePercent, double margin)
		{
			return HFCLevarageBasedEntryCalculator(Input, leveragePercent, margin);
		}

		public HFCTradingSystem.HFCLevarageBasedEntryCalculator HFCLevarageBasedEntryCalculator(ISeries<double> input, double leveragePercent, double margin)
		{
			if (cacheHFCLevarageBasedEntryCalculator != null)
				for (int idx = 0; idx < cacheHFCLevarageBasedEntryCalculator.Length; idx++)
					if (cacheHFCLevarageBasedEntryCalculator[idx] != null && cacheHFCLevarageBasedEntryCalculator[idx].LeveragePercent == leveragePercent && cacheHFCLevarageBasedEntryCalculator[idx].Margin == margin && cacheHFCLevarageBasedEntryCalculator[idx].EqualsInput(input))
						return cacheHFCLevarageBasedEntryCalculator[idx];
			return CacheIndicator<HFCTradingSystem.HFCLevarageBasedEntryCalculator>(new HFCTradingSystem.HFCLevarageBasedEntryCalculator(){ LeveragePercent = leveragePercent, Margin = margin }, input, ref cacheHFCLevarageBasedEntryCalculator);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HFCTradingSystem.HFCLevarageBasedEntryCalculator HFCLevarageBasedEntryCalculator(double leveragePercent, double margin)
		{
			return indicator.HFCLevarageBasedEntryCalculator(Input, leveragePercent, margin);
		}

		public Indicators.HFCTradingSystem.HFCLevarageBasedEntryCalculator HFCLevarageBasedEntryCalculator(ISeries<double> input , double leveragePercent, double margin)
		{
			return indicator.HFCLevarageBasedEntryCalculator(input, leveragePercent, margin);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HFCTradingSystem.HFCLevarageBasedEntryCalculator HFCLevarageBasedEntryCalculator(double leveragePercent, double margin)
		{
			return indicator.HFCLevarageBasedEntryCalculator(Input, leveragePercent, margin);
		}

		public Indicators.HFCTradingSystem.HFCLevarageBasedEntryCalculator HFCLevarageBasedEntryCalculator(ISeries<double> input , double leveragePercent, double margin)
		{
			return indicator.HFCLevarageBasedEntryCalculator(input, leveragePercent, margin);
		}
	}
}

#endregion
