#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.HFCTradingSystem
{
	public class HFCPlannerVSASimpleCPR : Indicator
	{
		private string dailyCheck;
		private SimpleFont errFont;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"following things will be checked, 1.wyckoff phase, 2. Donchain based VSA phase 3. Donchain Position 4. Bollinger Position ";
				Name										= "HFCPlannerVSASimpleCPR";
				Calculate									= Calculate.OnEachTick;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				ChkdPoiints									= false;
			}
			else if (State == State.Configure)
			{
				
			}
			else if (State == State.DataLoaded)
			{
				if(BarsPeriod.BarsPeriodType != BarsPeriodType.Minute)
				{
					errFont = new SimpleFont("Courier New", 12) { Size = 30, Bold = true };
					Draw.TextFixed(this,"Error","Error : Select Only Minute Period for planer to work!",TextPosition.BottomLeft,Brushes.Red,errFont,Brushes.Red,Brushes.Yellow,60);
					return;
				}
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
				if (CurrentBar < 2)
					return;
				
				if(BarsPeriod.BarsPeriodType != BarsPeriodType.Minute)
				{
					return;
				}

				if ((Time[0].Date==Time[1].Date) && ChkdPoiints == false)
				{
					dailyCheck = "N";
				}
				else
				{
					dailyCheck = "Y";
					ChkdPoiints = true;
				}
			
			
		}
		
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
				// This sample should be used along side the help guide educational resource on this topic:
				// http://www.ninjatrader.com/support/helpGuides/nt8/en-us/?using_sharpdx_for_custom_chart_rendering.htm

				// Default plotting in base class. Uncomment if indicators holds at least one plot
				// in this case we would expect NOT to see the SMA plot we have as well in this sample script
				//base.OnRender(chartControl, chartScale);
					
				// define the point for the text to render
				SharpDX.Vector2 startPoint1 = new SharpDX.Vector2(ChartPanel.X + 20, ChartPanel.Y+ChartPanel.H - 100);	
				SharpDX.Vector2 startPoint2 = new SharpDX.Vector2(ChartPanel.X + 20, ChartPanel.Y+ChartPanel.H - 88);	
		        SharpDX.Vector2 startPoint3 = new SharpDX.Vector2(ChartPanel.X + 20, ChartPanel.Y+ChartPanel.H - 76);	
				SharpDX.Vector2 startPoint4 = new SharpDX.Vector2(ChartPanel.X + 20, ChartPanel.Y+ChartPanel.H - 64);		
				
				// construct the text format with desired font family and size
				SharpDX.DirectWrite.TextFormat textFormat1 = new SharpDX.DirectWrite.TextFormat(Core.Globals.DirectWriteFactory, "Arial", 12);
				
					
				// construct the text layout with desired text, text format, max width and height
				SharpDX.DirectWrite.TextLayout textLayout1 = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, "Wyckoff's Phase : " + WyckoffPhase.ToString() , textFormat1, ChartPanel.W, ChartPanel.H);
				SharpDX.DirectWrite.TextLayout textLayout2 = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, "Donchain Based VSA Signals : " + DCVSAPatternInWyckoffPhase.ToString(), textFormat1, ChartPanel.W, ChartPanel.H);
				SharpDX.DirectWrite.TextLayout textLayout3 = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, "Donchain Based Market Strength : " + DCBasedStrength.ToString(), textFormat1, ChartPanel.W, ChartPanel.H);
				SharpDX.DirectWrite.TextLayout textLayout4 = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, "Bollinger Based Price Movement : " + BolBasedPriceMovement.ToString(), textFormat1, ChartPanel.W, ChartPanel.H);
				
				
				// create a rectangle which will automatically resize to the width/height of the textLayout
				SharpDX.RectangleF rectangleF = new SharpDX.RectangleF(startPoint1.X-10, startPoint1.Y-10, 
					(Math.Max(Math.Max(textLayout1.Metrics.Width,textLayout2.Metrics.Width),Math.Max(textLayout3.Metrics.Width,textLayout4.Metrics.Width)))+20, (textLayout1.Metrics.Height*4)+10);		
				
					
					
				// define the brush used for the text and rectangle
				SharpDX.Direct2D1.SolidColorBrush customDXBrush = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, SharpDX.Color.AntiqueWhite);
				customDXBrush.Opacity = 0.6f;
				// Rectacngle  Background	
				
			
				if (dailyCheck == "N")
				{
					SharpDX.Direct2D1.SolidColorBrush areaBrushDx = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, SharpDX.Color.Salmon);	
					areaBrushDx.Opacity = 0.5f;
					// execute the render target draw rectangle with desired values
					RenderTarget.DrawRectangle(rectangleF, customDXBrush);
					RenderTarget.FillRectangle(rectangleF, areaBrushDx);					
					
				}
				else
				{
					SharpDX.Direct2D1.SolidColorBrush areaBrushDx = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, SharpDX.Color.DodgerBlue);						
					areaBrushDx.Opacity = 0.5f;
					// execute the render target draw rectangle with desired values
					RenderTarget.DrawRectangle(rectangleF, customDXBrush);
					RenderTarget.FillRectangle(rectangleF, areaBrushDx);	
					
				}
				
			
					

					
				// execute the render target text layout command with desired values
				RenderTarget.DrawTextLayout(startPoint1, textLayout1, customDXBrush);
				RenderTarget.DrawTextLayout(startPoint2, textLayout2, customDXBrush);
				RenderTarget.DrawTextLayout(startPoint3, textLayout3, customDXBrush);
				RenderTarget.DrawTextLayout(startPoint4, textLayout4, customDXBrush);			
				 

				// always dispose of textLayout, textFormat, or brush when finished
				textLayout1.Dispose();
				textLayout2.Dispose();
				textLayout3.Dispose();
				textLayout4.Dispose();
				textFormat1.Dispose();
				customDXBrush.Dispose();
				
			
		}	
		
       #region Properties
		
		[NinjaScriptProperty]
		[Range((int)WTIShared.Enums.WyckoffPhase.EarlyAccumulation, (int)WTIShared.Enums.WyckoffPhase.LateMarkDown)]
        [Display(ResourceType = typeof(Custom.Resource), Name = "Wyckoff's Phase", GroupName = "Higher Time Frame", Order = 1)]
        public WTIShared.Enums.WyckoffPhase WyckoffPhase
        { get; set; }		

		[NinjaScriptProperty]
		[Range((int)WTIShared.Enums.DCVSAPatternInWyckoffPhase.StrongTrend, (int)WTIShared.Enums.DCVSAPatternInWyckoffPhase.PassedTestOfDemand)]
        [Display(ResourceType = typeof(Custom.Resource), Name = "Donchain Based VSA Signals", GroupName = "Higher Time Frame", Order = 2)]
        public WTIShared.Enums.DCVSAPatternInWyckoffPhase DCVSAPatternInWyckoffPhase
        { get; set; }			

		[NinjaScriptProperty]
		[Range((int)WTIShared.Enums.DCBasedStrength.Bullish, (int)WTIShared.Enums.DCBasedStrength.Range)]
        [Display(ResourceType = typeof(Custom.Resource), Name = "Donchain Based Market Strength", GroupName = "Higher Time Frame", Order = 3)]
        public WTIShared.Enums.DCBasedStrength DCBasedStrength
        { get; set; }

		[NinjaScriptProperty]
		[Range((int)WTIShared.Enums.BolBasedPriceMovement.ApproachBelowTowardsMean, (int)WTIShared.Enums.BolBasedPriceMovement.OnMinus2SD)]
        [Display(ResourceType = typeof(Custom.Resource), Name = "Bollinger Based Price Movement", GroupName = "Higher Time Frame", Order = 4)]
        public WTIShared.Enums.BolBasedPriceMovement BolBasedPriceMovement
        { get; set; }	
		
		[NinjaScriptProperty]
		[Display(Name="Checked", Description="Checked all the params", Order=5, GroupName="Parameters")]
		public bool ChkdPoiints
		{ get; set; }

		
		#endregion		
	}
}


namespace WTIShared.Enums
{
	//Wyckoff's Phase
    public enum WyckoffPhase
    {
        EarlyAccumulation,
        MidOfAccumulation,
        LateAccumulation,
		EarlyMarkUp,
        MidOfMarkUp,
        LateMarkUp,
		EarlyDistribution,
        MidOfDistribution,
        LateDistribution,
		EarlyMarkDown,
        MidOfMarkDown,
        LateMarkDown
    }
	
	//Donchain Based VSA Pattern with-in a WyckoffPhase
    public enum DCVSAPatternInWyckoffPhase
    {
        StrongTrend,
		Trend,
		WeakTrend,
        PassedEndOfSupply,
        PassedTestOfSupply,
		PassedEndOfDemand,
        PassedTestOfDemand
    }	

	//Donchain Based Price Strength
    public enum DCBasedStrength
    {
        Bullish,
        Bearish,
        Range
    }	
	
	//Bollinger Based Price Movement
    public enum BolBasedPriceMovement
    {
        ApproachBelowTowardsMean,
        ApproachAboveTowardsMean,
		DeviatedAboveAwayFromMean,
		DeviatedBelowAwayFromMean,
		OnMean,
		CrossedAbovePlus2SD,
		CrossedBelowMinus2SD,
        OnPlus2SD,
		OnMinus2SD
    }	
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HFCTradingSystem.HFCPlannerVSASimpleCPR[] cacheHFCPlannerVSASimpleCPR;
		public HFCTradingSystem.HFCPlannerVSASimpleCPR HFCPlannerVSASimpleCPR(WTIShared.Enums.WyckoffPhase wyckoffPhase, WTIShared.Enums.DCVSAPatternInWyckoffPhase dCVSAPatternInWyckoffPhase, WTIShared.Enums.DCBasedStrength dCBasedStrength, WTIShared.Enums.BolBasedPriceMovement bolBasedPriceMovement, bool chkdPoiints)
		{
			return HFCPlannerVSASimpleCPR(Input, wyckoffPhase, dCVSAPatternInWyckoffPhase, dCBasedStrength, bolBasedPriceMovement, chkdPoiints);
		}

		public HFCTradingSystem.HFCPlannerVSASimpleCPR HFCPlannerVSASimpleCPR(ISeries<double> input, WTIShared.Enums.WyckoffPhase wyckoffPhase, WTIShared.Enums.DCVSAPatternInWyckoffPhase dCVSAPatternInWyckoffPhase, WTIShared.Enums.DCBasedStrength dCBasedStrength, WTIShared.Enums.BolBasedPriceMovement bolBasedPriceMovement, bool chkdPoiints)
		{
			if (cacheHFCPlannerVSASimpleCPR != null)
				for (int idx = 0; idx < cacheHFCPlannerVSASimpleCPR.Length; idx++)
					if (cacheHFCPlannerVSASimpleCPR[idx] != null && cacheHFCPlannerVSASimpleCPR[idx].WyckoffPhase == wyckoffPhase && cacheHFCPlannerVSASimpleCPR[idx].DCVSAPatternInWyckoffPhase == dCVSAPatternInWyckoffPhase && cacheHFCPlannerVSASimpleCPR[idx].DCBasedStrength == dCBasedStrength && cacheHFCPlannerVSASimpleCPR[idx].BolBasedPriceMovement == bolBasedPriceMovement && cacheHFCPlannerVSASimpleCPR[idx].ChkdPoiints == chkdPoiints && cacheHFCPlannerVSASimpleCPR[idx].EqualsInput(input))
						return cacheHFCPlannerVSASimpleCPR[idx];
			return CacheIndicator<HFCTradingSystem.HFCPlannerVSASimpleCPR>(new HFCTradingSystem.HFCPlannerVSASimpleCPR(){ WyckoffPhase = wyckoffPhase, DCVSAPatternInWyckoffPhase = dCVSAPatternInWyckoffPhase, DCBasedStrength = dCBasedStrength, BolBasedPriceMovement = bolBasedPriceMovement, ChkdPoiints = chkdPoiints }, input, ref cacheHFCPlannerVSASimpleCPR);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HFCTradingSystem.HFCPlannerVSASimpleCPR HFCPlannerVSASimpleCPR(WTIShared.Enums.WyckoffPhase wyckoffPhase, WTIShared.Enums.DCVSAPatternInWyckoffPhase dCVSAPatternInWyckoffPhase, WTIShared.Enums.DCBasedStrength dCBasedStrength, WTIShared.Enums.BolBasedPriceMovement bolBasedPriceMovement, bool chkdPoiints)
		{
			return indicator.HFCPlannerVSASimpleCPR(Input, wyckoffPhase, dCVSAPatternInWyckoffPhase, dCBasedStrength, bolBasedPriceMovement, chkdPoiints);
		}

		public Indicators.HFCTradingSystem.HFCPlannerVSASimpleCPR HFCPlannerVSASimpleCPR(ISeries<double> input , WTIShared.Enums.WyckoffPhase wyckoffPhase, WTIShared.Enums.DCVSAPatternInWyckoffPhase dCVSAPatternInWyckoffPhase, WTIShared.Enums.DCBasedStrength dCBasedStrength, WTIShared.Enums.BolBasedPriceMovement bolBasedPriceMovement, bool chkdPoiints)
		{
			return indicator.HFCPlannerVSASimpleCPR(input, wyckoffPhase, dCVSAPatternInWyckoffPhase, dCBasedStrength, bolBasedPriceMovement, chkdPoiints);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HFCTradingSystem.HFCPlannerVSASimpleCPR HFCPlannerVSASimpleCPR(WTIShared.Enums.WyckoffPhase wyckoffPhase, WTIShared.Enums.DCVSAPatternInWyckoffPhase dCVSAPatternInWyckoffPhase, WTIShared.Enums.DCBasedStrength dCBasedStrength, WTIShared.Enums.BolBasedPriceMovement bolBasedPriceMovement, bool chkdPoiints)
		{
			return indicator.HFCPlannerVSASimpleCPR(Input, wyckoffPhase, dCVSAPatternInWyckoffPhase, dCBasedStrength, bolBasedPriceMovement, chkdPoiints);
		}

		public Indicators.HFCTradingSystem.HFCPlannerVSASimpleCPR HFCPlannerVSASimpleCPR(ISeries<double> input , WTIShared.Enums.WyckoffPhase wyckoffPhase, WTIShared.Enums.DCVSAPatternInWyckoffPhase dCVSAPatternInWyckoffPhase, WTIShared.Enums.DCBasedStrength dCBasedStrength, WTIShared.Enums.BolBasedPriceMovement bolBasedPriceMovement, bool chkdPoiints)
		{
			return indicator.HFCPlannerVSASimpleCPR(input, wyckoffPhase, dCVSAPatternInWyckoffPhase, dCBasedStrength, bolBasedPriceMovement, chkdPoiints);
		}
	}
}

#endregion
