#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class HFCWeeklyVolatalityRange : Indicator
	{
		private SimpleFont errFont;
		private double varUpper, varLower, weeklyVol;
		private int weekDay;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "HFCWeeklyVolatalityRange";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				AnnualVolFromNSE					= 1;
				AddPlot(Brushes.ForestGreen, "PltWeeklyVolUp");
				AddPlot(Brushes.Tomato, "PltWeeklyVolDown");
			}
			else if (State == State.Configure)
			{
				AddDataSeries(BarsPeriodType.Week,1);
				
			}
			else if (State == State.DataLoaded)
			{
				if(BarsPeriod.BarsPeriodType != BarsPeriodType.Minute)
				{
					errFont = new SimpleFont("Courier New", 12) { Size = 30, Bold = true };
					Draw.TextFixed(this,"Error","Error : Select Only Minute Period Type for HFC Weekly Vol Range to Work!",TextPosition.BottomLeft,Brushes.Red,errFont,Brushes.Red,Brushes.Yellow,60);
					return;
				}

			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
			//Add your custom indicator logic here.
			if (CurrentBars[1] < 2)
				return;
			
			if (DateTime.Now.DayOfWeek.ToString() == "Monday")
			{
				weekDay = 0;
			} else if (DateTime.Now.DayOfWeek.ToString() == "Tuesday")
			{
				weekDay = 1;
			} else if (DateTime.Now.DayOfWeek.ToString() == "Wednesday")
			{
				weekDay = 2;
			} else if (DateTime.Now.DayOfWeek.ToString() == "Thursday")
			{
				weekDay = 3;
			} else if (DateTime.Now.DayOfWeek.ToString() == "Friday")
			{
				weekDay = 4;
			} else
			{
				weekDay = 0;
			}
				
			
			
			
			if(BarsPeriod.BarsPeriodType == BarsPeriodType.Minute && Time[0].Date >= DateTime.Now.AddDays(-1*weekDay).Date )
			{
				weeklyVol = ((AnnualVolFromNSE/Math.Sqrt(52))/100);
				varUpper = Closes[1][0]  + (Closes[1][0] * weeklyVol);
				varLower = Closes[1][0]  - (Closes[1][0] * weeklyVol);
				PltWeeklyVolUp[0] = varUpper;
				PltWeeklyVolDown[0] = varLower;
			}
			
			
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(1, double.MaxValue)]
		[Display(Name="AnnualVolFromNSE", Order=1, GroupName="Parameters")]
		public double AnnualVolFromNSE
		{ get; set; }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PltWeeklyVolUp
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PltWeeklyVolDown
		{
			get { return Values[1]; }
		}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HFCWeeklyVolatalityRange[] cacheHFCWeeklyVolatalityRange;
		public HFCWeeklyVolatalityRange HFCWeeklyVolatalityRange(double annualVolFromNSE)
		{
			return HFCWeeklyVolatalityRange(Input, annualVolFromNSE);
		}

		public HFCWeeklyVolatalityRange HFCWeeklyVolatalityRange(ISeries<double> input, double annualVolFromNSE)
		{
			if (cacheHFCWeeklyVolatalityRange != null)
				for (int idx = 0; idx < cacheHFCWeeklyVolatalityRange.Length; idx++)
					if (cacheHFCWeeklyVolatalityRange[idx] != null && cacheHFCWeeklyVolatalityRange[idx].AnnualVolFromNSE == annualVolFromNSE && cacheHFCWeeklyVolatalityRange[idx].EqualsInput(input))
						return cacheHFCWeeklyVolatalityRange[idx];
			return CacheIndicator<HFCWeeklyVolatalityRange>(new HFCWeeklyVolatalityRange(){ AnnualVolFromNSE = annualVolFromNSE }, input, ref cacheHFCWeeklyVolatalityRange);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HFCWeeklyVolatalityRange HFCWeeklyVolatalityRange(double annualVolFromNSE)
		{
			return indicator.HFCWeeklyVolatalityRange(Input, annualVolFromNSE);
		}

		public Indicators.HFCWeeklyVolatalityRange HFCWeeklyVolatalityRange(ISeries<double> input , double annualVolFromNSE)
		{
			return indicator.HFCWeeklyVolatalityRange(input, annualVolFromNSE);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HFCWeeklyVolatalityRange HFCWeeklyVolatalityRange(double annualVolFromNSE)
		{
			return indicator.HFCWeeklyVolatalityRange(Input, annualVolFromNSE);
		}

		public Indicators.HFCWeeklyVolatalityRange HFCWeeklyVolatalityRange(ISeries<double> input , double annualVolFromNSE)
		{
			return indicator.HFCWeeklyVolatalityRange(input, annualVolFromNSE);
		}
	}
}

#endregion
