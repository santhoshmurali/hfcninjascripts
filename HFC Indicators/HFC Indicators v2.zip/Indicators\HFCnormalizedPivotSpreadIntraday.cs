#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class HFCnormalizedPivotSpreadIntraday : Indicator
	{
		private double yesterS1,yesterR1,prevYesterS1,prevYesterR1,minS1,MaxR1;
		private double yesterH,yesterL,yesterC,pYesterH,pYesterL,pYesterC,yesterPP,pYesterPP;
		private double yesterTC,yesterBC,pYesterTC,pYesterBC;
		private double YesterDaySpreadPercent,PrevYesterDaySpreadPercent,CPRSpread,ConsolidatedSpreadPercent;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"With This We will be able to compare the pivot spreads in a normalized way";
				Name										= "HFCnormalizedPivotSpreadIntraday";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				
				IsAutoScale									= false;
				
				AddPlot(Brushes.LightSeaGreen, "PltYesterDaySpreadPercent");
				AddPlot(Brushes.DarkGreen, "PltPrevYesterDaySpreadPercent");
				AddPlot(Brushes.Brown, "PltConsolidatedSpreadPercent");
				AddPlot(Brushes.DeepPink, "PltCPRSpread");
				
				pYesterdaySpread = true;
				pPrevYesterdaySpread = false;
				pCombinedSpread = false;
				pCPRSpread = true;
			}
			else if (State == State.Configure)
			{
				AddDataSeries(BarsPeriodType.Day,1);
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
			if (CurrentBars[1]<3 || CurrentBars[0]<3)
				return;
			//Yesterday HLC
			yesterH = Highs[1][0];
			yesterL = Lows[1][0];
			yesterC = Closes[1][0];
			yesterPP = (yesterH + yesterL + yesterC)/3;
			yesterBC = (yesterH + yesterL)/2;
			yesterTC = (yesterPP - yesterBC)+yesterPP;
			yesterS1 = 2 * yesterPP - yesterH;
			yesterR1 = 2 * yesterPP - yesterL;
			YesterDaySpreadPercent = Math.Round(Math.Log(yesterR1/yesterS1),3)*100;
			CPRSpread = Math.Round(Math.Log(yesterTC/yesterBC),3)*100;
			
			//Previous Yesterday HLC
			pYesterH = Highs[1][1];
			pYesterL = Lows[1][1];
			pYesterC = Closes[1][1];
			pYesterPP = (pYesterH + pYesterL + pYesterC)/3;
			pYesterBC = (pYesterH + pYesterL)/2;
			pYesterTC = (pYesterH - pYesterBC)+pYesterH;			
			prevYesterS1 = 2 * pYesterPP - pYesterH;
			prevYesterR1 = 2 * pYesterPP - pYesterL;
			PrevYesterDaySpreadPercent = Math.Round(Math.Log(prevYesterR1/prevYesterS1),3)*100;
			
			//Consolidated Spread
			ConsolidatedSpreadPercent = Math.Round(Math.Log(Math.Max(yesterR1,prevYesterR1)/Math.Min(yesterS1,prevYesterS1)),3)*100;
			
			
			
			#region Yesterday's Pivot Spread
			if (pYesterdaySpread)
			{
			PltYesterDaySpreadPercent[0] = YesterDaySpreadPercent;
			}
			
			if(pPrevYesterdaySpread)
			{
			PltPrevYesterDaySpreadPercent[0] = PrevYesterDaySpreadPercent;
			}
			
			if(pCombinedSpread)
			{
			PltConsolidatedSpreadPercent[0] = ConsolidatedSpreadPercent;
			}
			
			if(pCPRSpread)
			{
			if (CPRSpread<0)
			{
				CPRSpread = -1*CPRSpread;
			}
			PltCPRSpread[0] = CPRSpread;
			}
			
			#endregion			
		}

		#region Properties

		[NinjaScriptProperty]
		[Display(Name="R1 - S1 Yesterday Spread", Order=1, GroupName="Display Spreads")]
		public bool pYesterdaySpread
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="R1 - S1 Previous Yesterday Spread", Order=2, GroupName="Display Spreads")]
		public bool pPrevYesterdaySpread
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="R1 - S1 Combined Spread", Order=3, GroupName="Display Spreads")]
		public bool pCombinedSpread
		{ get; set; }		

		[NinjaScriptProperty]
		[Display(Name="CPR Spread", Order=4, GroupName="Display Spreads")]
		public bool pCPRSpread
		{ get; set; }		
		
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PltYesterDaySpreadPercent
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PltPrevYesterDaySpreadPercent
		{
			get { return Values[1]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PltConsolidatedSpreadPercent
		{
			get { return Values[2]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PltCPRSpread
		{
			get { return Values[3]; }
		}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HFCnormalizedPivotSpreadIntraday[] cacheHFCnormalizedPivotSpreadIntraday;
		public HFCnormalizedPivotSpreadIntraday HFCnormalizedPivotSpreadIntraday(bool pYesterdaySpread, bool pPrevYesterdaySpread, bool pCombinedSpread, bool pCPRSpread)
		{
			return HFCnormalizedPivotSpreadIntraday(Input, pYesterdaySpread, pPrevYesterdaySpread, pCombinedSpread, pCPRSpread);
		}

		public HFCnormalizedPivotSpreadIntraday HFCnormalizedPivotSpreadIntraday(ISeries<double> input, bool pYesterdaySpread, bool pPrevYesterdaySpread, bool pCombinedSpread, bool pCPRSpread)
		{
			if (cacheHFCnormalizedPivotSpreadIntraday != null)
				for (int idx = 0; idx < cacheHFCnormalizedPivotSpreadIntraday.Length; idx++)
					if (cacheHFCnormalizedPivotSpreadIntraday[idx] != null && cacheHFCnormalizedPivotSpreadIntraday[idx].pYesterdaySpread == pYesterdaySpread && cacheHFCnormalizedPivotSpreadIntraday[idx].pPrevYesterdaySpread == pPrevYesterdaySpread && cacheHFCnormalizedPivotSpreadIntraday[idx].pCombinedSpread == pCombinedSpread && cacheHFCnormalizedPivotSpreadIntraday[idx].pCPRSpread == pCPRSpread && cacheHFCnormalizedPivotSpreadIntraday[idx].EqualsInput(input))
						return cacheHFCnormalizedPivotSpreadIntraday[idx];
			return CacheIndicator<HFCnormalizedPivotSpreadIntraday>(new HFCnormalizedPivotSpreadIntraday(){ pYesterdaySpread = pYesterdaySpread, pPrevYesterdaySpread = pPrevYesterdaySpread, pCombinedSpread = pCombinedSpread, pCPRSpread = pCPRSpread }, input, ref cacheHFCnormalizedPivotSpreadIntraday);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HFCnormalizedPivotSpreadIntraday HFCnormalizedPivotSpreadIntraday(bool pYesterdaySpread, bool pPrevYesterdaySpread, bool pCombinedSpread, bool pCPRSpread)
		{
			return indicator.HFCnormalizedPivotSpreadIntraday(Input, pYesterdaySpread, pPrevYesterdaySpread, pCombinedSpread, pCPRSpread);
		}

		public Indicators.HFCnormalizedPivotSpreadIntraday HFCnormalizedPivotSpreadIntraday(ISeries<double> input , bool pYesterdaySpread, bool pPrevYesterdaySpread, bool pCombinedSpread, bool pCPRSpread)
		{
			return indicator.HFCnormalizedPivotSpreadIntraday(input, pYesterdaySpread, pPrevYesterdaySpread, pCombinedSpread, pCPRSpread);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HFCnormalizedPivotSpreadIntraday HFCnormalizedPivotSpreadIntraday(bool pYesterdaySpread, bool pPrevYesterdaySpread, bool pCombinedSpread, bool pCPRSpread)
		{
			return indicator.HFCnormalizedPivotSpreadIntraday(Input, pYesterdaySpread, pPrevYesterdaySpread, pCombinedSpread, pCPRSpread);
		}

		public Indicators.HFCnormalizedPivotSpreadIntraday HFCnormalizedPivotSpreadIntraday(ISeries<double> input , bool pYesterdaySpread, bool pPrevYesterdaySpread, bool pCombinedSpread, bool pCPRSpread)
		{
			return indicator.HFCnormalizedPivotSpreadIntraday(input, pYesterdaySpread, pPrevYesterdaySpread, pCombinedSpread, pCPRSpread);
		}
	}
}

#endregion
