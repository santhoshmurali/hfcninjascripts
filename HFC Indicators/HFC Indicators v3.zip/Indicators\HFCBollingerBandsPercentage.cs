#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
// This Belongs to Harvest FinCrop. 
// Version : 1.0
// Developed By : Santhosh Murali [ santhoshmurali@gmail.com ]
// For Support Contact : Santhosh Murali
// Description : Bollinger Bands %B or Percent Bandwidth (%B) is an indicator derived from the standard Bollinger Bands
//              (BB) indicator. Bollinger Bands are a volatility indicator which creates a band of three lines which 
//               are plotted in relation to a security's price. The Middle Line is typically a 20 Day Simple Moving Average. 
//               The Upper and Lower Bands are typically 2 standard deviations above and below the SMA (Middle Line). 
//               What the %B indicator does is quantify or display where price is in relation to the bands. 
//               %B can be useful in identifying trends and trading signals.
namespace NinjaTrader.NinjaScript.Indicators
{
	public class HFCBollingerBandsPercentage : Indicator
	{
		private Bollinger myBol;
		private double myBolPercent;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Harvest FinCrop Bollinger Bands Percentage - Bollinger Bands %B or Percent Bandwidth (%B) is an indicator derived from the standard Bollinger Bands (BB) indicator. Bollinger Bands are a volatility indicator which creates a band of three lines which are plotted in relation to a security's price. The Middle Line is typically a 20 Day Simple Moving Average. The Upper and Lower Bands are typically 2 standard deviations above and below the SMA (Middle Line). What the %B indicator does is quantify or display where price is in relation to the bands. %B can be useful in identifying trends and trading signals.";
				Name										= "HFCBollingerBandsPercentage";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				HFCBBLength					= 20;
				HFCBBStdDev					= 2.0;
				AddPlot(Brushes.OliveDrab, "HFCBBPercent");
				AddLine(Brushes.Aqua, 1.0, "Upper");
				AddLine(Brushes.Aqua, 0.0, "Lower");
			}
			else if (State == State.Configure)
			{
			}
			else if (State == State.DataLoaded)
			{
				myBol = Bollinger(HFCBBStdDev,HFCBBLength);
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
			myBolPercent = (Input[0] - myBol.Lower[0])/(myBol.Upper[0] - myBol.Lower[0]);
			HFCBBPercent[0] = myBolPercent;
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="HFCBBLength", Description="Bollinger Bands Length", Order=1, GroupName="Parameters")]
		public int HFCBBLength
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1.0, double.MaxValue)]
		[Display(Name="HFCBBStdDev", Order=2, GroupName="Parameters")]
		public double HFCBBStdDev
		{ get; set; }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> HFCBBPercent
		{
			get { return Values[0]; }
		}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HFCBollingerBandsPercentage[] cacheHFCBollingerBandsPercentage;
		public HFCBollingerBandsPercentage HFCBollingerBandsPercentage(int hFCBBLength, double hFCBBStdDev)
		{
			return HFCBollingerBandsPercentage(Input, hFCBBLength, hFCBBStdDev);
		}

		public HFCBollingerBandsPercentage HFCBollingerBandsPercentage(ISeries<double> input, int hFCBBLength, double hFCBBStdDev)
		{
			if (cacheHFCBollingerBandsPercentage != null)
				for (int idx = 0; idx < cacheHFCBollingerBandsPercentage.Length; idx++)
					if (cacheHFCBollingerBandsPercentage[idx] != null && cacheHFCBollingerBandsPercentage[idx].HFCBBLength == hFCBBLength && cacheHFCBollingerBandsPercentage[idx].HFCBBStdDev == hFCBBStdDev && cacheHFCBollingerBandsPercentage[idx].EqualsInput(input))
						return cacheHFCBollingerBandsPercentage[idx];
			return CacheIndicator<HFCBollingerBandsPercentage>(new HFCBollingerBandsPercentage(){ HFCBBLength = hFCBBLength, HFCBBStdDev = hFCBBStdDev }, input, ref cacheHFCBollingerBandsPercentage);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HFCBollingerBandsPercentage HFCBollingerBandsPercentage(int hFCBBLength, double hFCBBStdDev)
		{
			return indicator.HFCBollingerBandsPercentage(Input, hFCBBLength, hFCBBStdDev);
		}

		public Indicators.HFCBollingerBandsPercentage HFCBollingerBandsPercentage(ISeries<double> input , int hFCBBLength, double hFCBBStdDev)
		{
			return indicator.HFCBollingerBandsPercentage(input, hFCBBLength, hFCBBStdDev);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HFCBollingerBandsPercentage HFCBollingerBandsPercentage(int hFCBBLength, double hFCBBStdDev)
		{
			return indicator.HFCBollingerBandsPercentage(Input, hFCBBLength, hFCBBStdDev);
		}

		public Indicators.HFCBollingerBandsPercentage HFCBollingerBandsPercentage(ISeries<double> input , int hFCBBLength, double hFCBBStdDev)
		{
			return indicator.HFCBollingerBandsPercentage(input, hFCBBLength, hFCBBStdDev);
		}
	}
}

#endregion
