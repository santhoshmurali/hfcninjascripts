#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class HFCMovingNarrowRange : Indicator
	{
		private int  NarrowCnt=0;
		private double l;
		private double currentRange;
		private int i;
		
		private Brush CtsmBackBrush;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"This will compare the range of current candle with given number of historical candle. if the current candle's range is low among the historical, it will highlight it.  this will explain contracting volatilty.";
				Name										= "HFCMovingNarrowRange";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				ClusterAsBg	=true;
				LookBack					= 7;
			}
			else if (State == State.Configure)
			{
			}
			else if (State == State.DataLoaded)
			{
				 CtsmBackBrush = new SolidColorBrush(Color.FromArgb(150,87,115,153));
				CtsmBackBrush.Freeze();
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
			if (CurrentBar <= LookBack)
				return;
			currentRange = High[0]-Low[0];
			i=0;
			NarrowCnt = 0;
			while (i<LookBack+1)
			{
				i=i+1;
				if(currentRange<(High[i]-Low[i]))
				{
					NarrowCnt=NarrowCnt+1;
				}
			}
			if(NarrowCnt==LookBack)
			{
				if (ClusterAsBg)
				{	
					BackBrush = CtsmBackBrush;
				}
				else
				{
					Draw.Diamond(this,"NR"+Time[0].ToString(),true,0,High[0]+(2*TickSize),Brushes.BlueViolet);
				}
			}

		}

		#region Properties
		[NinjaScriptProperty]
		[Range(2, int.MaxValue)]
		[Display(Name="LookBack", Order=1, GroupName="Parameters")]
		public int LookBack
		{ get; set; }
		
		
		[NinjaScriptProperty]
		[Display(Name="Show NR Cluster as Background", Description="Show Narrow Range Cluster as background", Order=2, GroupName="Parameters")]
		public bool ClusterAsBg
		{ get; set; }
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HFCMovingNarrowRange[] cacheHFCMovingNarrowRange;
		public HFCMovingNarrowRange HFCMovingNarrowRange(int lookBack, bool clusterAsBg)
		{
			return HFCMovingNarrowRange(Input, lookBack, clusterAsBg);
		}

		public HFCMovingNarrowRange HFCMovingNarrowRange(ISeries<double> input, int lookBack, bool clusterAsBg)
		{
			if (cacheHFCMovingNarrowRange != null)
				for (int idx = 0; idx < cacheHFCMovingNarrowRange.Length; idx++)
					if (cacheHFCMovingNarrowRange[idx] != null && cacheHFCMovingNarrowRange[idx].LookBack == lookBack && cacheHFCMovingNarrowRange[idx].ClusterAsBg == clusterAsBg && cacheHFCMovingNarrowRange[idx].EqualsInput(input))
						return cacheHFCMovingNarrowRange[idx];
			return CacheIndicator<HFCMovingNarrowRange>(new HFCMovingNarrowRange(){ LookBack = lookBack, ClusterAsBg = clusterAsBg }, input, ref cacheHFCMovingNarrowRange);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HFCMovingNarrowRange HFCMovingNarrowRange(int lookBack, bool clusterAsBg)
		{
			return indicator.HFCMovingNarrowRange(Input, lookBack, clusterAsBg);
		}

		public Indicators.HFCMovingNarrowRange HFCMovingNarrowRange(ISeries<double> input , int lookBack, bool clusterAsBg)
		{
			return indicator.HFCMovingNarrowRange(input, lookBack, clusterAsBg);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HFCMovingNarrowRange HFCMovingNarrowRange(int lookBack, bool clusterAsBg)
		{
			return indicator.HFCMovingNarrowRange(Input, lookBack, clusterAsBg);
		}

		public Indicators.HFCMovingNarrowRange HFCMovingNarrowRange(ISeries<double> input , int lookBack, bool clusterAsBg)
		{
			return indicator.HFCMovingNarrowRange(input, lookBack, clusterAsBg);
		}
	}
}

#endregion
