#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
// This Belongs to Harvest FinCrop. 
// Version : 1.0
// Module : VSA
// Developed By : Santhosh Murali [ santhoshmurali@gmail.com ]
// For Support Contact : Santhosh Murali
// Description : This Indictor will help in identifying Narrow range candles based on Threshold user provides.
// Date Developed : 13-05-2020

namespace NinjaTrader.NinjaScript.Indicators
{
	public class HFCNarrowCandleSpread : Indicator
	{
		public double varNarrowPrice;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Thwill will show narrow candle spread";
				Name										= "HFCNarrowCandleSpread";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				NarrowThreshold					= 0.01;
				IgnoreHighLow					= true;
				AColor					= Brushes.Orange;						
				//AddPlot(new Stroke(Brushes.DeepSkyBlue, 2), PlotStyle.Bar, "NarrowCandles");
		
			}
			else if (State == State.Configure)
			{
			}
			else if (State == State.DataLoaded)
			{
				
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
			if (CurrentBar < 2)
				return;
			varNarrowPrice =  ((((High[0]-Low[0])/(High[0]+Low[0])/2))*100);
			
			if (IgnoreHighLow)
			{
				varNarrowPrice =  Math.Sqrt(Math.Pow(((((Open[0]-Close[0])/(Open[0]+Close[0])/2))*100),2));		
			}
			
			if (varNarrowPrice<=NarrowThreshold)
			{
				Draw.TriangleDown(this,"NarrowCandle"+Time[0].ToString(),true,0,High[0]+TickSize,AColor);
			}
			else if (Calculate == Calculate.OnEachTick)
			{
				RemoveDrawObject("NarrowCandle"+Time[0].ToString());
			}
			
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(0.01, double.MaxValue)]
		[Display(Name="NarrowThreshold", Order=1, GroupName="Parameters")]
		public double NarrowThreshold
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="IgnoreHighLow", Order=2, GroupName="Parameters")]
		public bool IgnoreHighLow
		{ get; set; }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> NarrowCandles
		{
			get { return Values[0]; }
		}
		
		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="Arrow Color", Order=3, GroupName="Parameters")]
		public Brush AColor
		{ get; set; }

		[Browsable(false)]
		public string AColorSerializable
		{
			get { return Serialize.BrushToString(AColor); }
			set { AColor = Serialize.StringToBrush(value); }
		}	
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HFCNarrowCandleSpread[] cacheHFCNarrowCandleSpread;
		public HFCNarrowCandleSpread HFCNarrowCandleSpread(double narrowThreshold, bool ignoreHighLow, Brush aColor)
		{
			return HFCNarrowCandleSpread(Input, narrowThreshold, ignoreHighLow, aColor);
		}

		public HFCNarrowCandleSpread HFCNarrowCandleSpread(ISeries<double> input, double narrowThreshold, bool ignoreHighLow, Brush aColor)
		{
			if (cacheHFCNarrowCandleSpread != null)
				for (int idx = 0; idx < cacheHFCNarrowCandleSpread.Length; idx++)
					if (cacheHFCNarrowCandleSpread[idx] != null && cacheHFCNarrowCandleSpread[idx].NarrowThreshold == narrowThreshold && cacheHFCNarrowCandleSpread[idx].IgnoreHighLow == ignoreHighLow && cacheHFCNarrowCandleSpread[idx].AColor == aColor && cacheHFCNarrowCandleSpread[idx].EqualsInput(input))
						return cacheHFCNarrowCandleSpread[idx];
			return CacheIndicator<HFCNarrowCandleSpread>(new HFCNarrowCandleSpread(){ NarrowThreshold = narrowThreshold, IgnoreHighLow = ignoreHighLow, AColor = aColor }, input, ref cacheHFCNarrowCandleSpread);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HFCNarrowCandleSpread HFCNarrowCandleSpread(double narrowThreshold, bool ignoreHighLow, Brush aColor)
		{
			return indicator.HFCNarrowCandleSpread(Input, narrowThreshold, ignoreHighLow, aColor);
		}

		public Indicators.HFCNarrowCandleSpread HFCNarrowCandleSpread(ISeries<double> input , double narrowThreshold, bool ignoreHighLow, Brush aColor)
		{
			return indicator.HFCNarrowCandleSpread(input, narrowThreshold, ignoreHighLow, aColor);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HFCNarrowCandleSpread HFCNarrowCandleSpread(double narrowThreshold, bool ignoreHighLow, Brush aColor)
		{
			return indicator.HFCNarrowCandleSpread(Input, narrowThreshold, ignoreHighLow, aColor);
		}

		public Indicators.HFCNarrowCandleSpread HFCNarrowCandleSpread(ISeries<double> input , double narrowThreshold, bool ignoreHighLow, Brush aColor)
		{
			return indicator.HFCNarrowCandleSpread(input, narrowThreshold, ignoreHighLow, aColor);
		}
	}
}

#endregion
