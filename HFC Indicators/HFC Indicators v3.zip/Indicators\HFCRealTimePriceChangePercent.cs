#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class HFCRealTimePriceChangePercent : Indicator
	{
		private SimpleFont errFont;
		private double DayOpenHigh=0;
		private double DayOpenLow=0;
		private string CurrentDate = "";
		private string PrevDate="";
		private int DailyBarsCount = 0;
		private double DailySpan;
		private DateTime dt;
		private double DailyOpen, percentChange;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "HFCRealTimePriceChangePercent";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				IsAutoScale									= false;
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
			if (CurrentBar<2)
				return;
			PrevDate =  Time[1].ToString("MM-dd-yyyy").Substring(0,10);
			CurrentDate =  Time[0].ToString("MM-dd-yyyy").Substring(0,10);
			if ((PrevDate != CurrentDate) && (BarsPeriod.BarsPeriodType == BarsPeriodType.Minute))
			{
				
				DayOpenHigh = High[0];
				DayOpenLow = Low[0];
				DailyOpen = Open[0];
				dt = Time[0];
			}
			percentChange = Math.Round(Math.Log(Close[0]/DailyOpen)*100,2);
			if (percentChange >= 0)
			{
				Draw.Text(this,"PercentChnage",percentChange.ToString()+"%",-2,Close[0],Brushes.DarkGreen);
			}
			else
			{
				Draw.Text(this,"PercentChnage",percentChange.ToString()+"%",-2,Close[0],Brushes.DarkRed);
				
			}
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HFCRealTimePriceChangePercent[] cacheHFCRealTimePriceChangePercent;
		public HFCRealTimePriceChangePercent HFCRealTimePriceChangePercent()
		{
			return HFCRealTimePriceChangePercent(Input);
		}

		public HFCRealTimePriceChangePercent HFCRealTimePriceChangePercent(ISeries<double> input)
		{
			if (cacheHFCRealTimePriceChangePercent != null)
				for (int idx = 0; idx < cacheHFCRealTimePriceChangePercent.Length; idx++)
					if (cacheHFCRealTimePriceChangePercent[idx] != null &&  cacheHFCRealTimePriceChangePercent[idx].EqualsInput(input))
						return cacheHFCRealTimePriceChangePercent[idx];
			return CacheIndicator<HFCRealTimePriceChangePercent>(new HFCRealTimePriceChangePercent(), input, ref cacheHFCRealTimePriceChangePercent);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HFCRealTimePriceChangePercent HFCRealTimePriceChangePercent()
		{
			return indicator.HFCRealTimePriceChangePercent(Input);
		}

		public Indicators.HFCRealTimePriceChangePercent HFCRealTimePriceChangePercent(ISeries<double> input )
		{
			return indicator.HFCRealTimePriceChangePercent(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HFCRealTimePriceChangePercent HFCRealTimePriceChangePercent()
		{
			return indicator.HFCRealTimePriceChangePercent(Input);
		}

		public Indicators.HFCRealTimePriceChangePercent HFCRealTimePriceChangePercent(ISeries<double> input )
		{
			return indicator.HFCRealTimePriceChangePercent(input);
		}
	}
}

#endregion
