#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class HFCSimpleCPR : Indicator
	{
		private double varpp,varBottpmCentralPivot,varTopCentralPivot,varS1,varR1, varS2, varR2, varS3, varR3, varS4, varR4,h1,c1, l1;
		private SimpleFont errFont;
		private SimpleFont CPRPercentFont;
		
		private double varUpprSpan,varLowSpan,varCprSpan;
		
		private Brush brushR2,brushR3,brushR4;
		private Brush brushS2,brushS3,brushS4;
		
		private int dailyBarCount;
		private double vCPP_to_R1,vCPP_to_R2,vCPP_to_R3,vCPP_to_R4;
		private double vCPP_to_S1,vCPP_to_S2,vCPP_to_S3,vCPP_to_S4;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Simple Central Pivot Range";
				Name										= "HFCSimpleCPR";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				IsAutoScale									= false;
				
				Displacement								= 1;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				
				//Configure Brushes
				brushR2 = new SolidColorBrush(Color.FromArgb(190,243,114,44));
				brushR2.Freeze();

				brushR3 = new SolidColorBrush(Color.FromArgb(190,248,150,30));
				brushR3.Freeze();				
				
				brushR4 = new SolidColorBrush(Color.FromArgb(190,249,199,79));
				brushR4.Freeze();				

				brushS2 = new SolidColorBrush(Color.FromArgb(190,144,190,109));
				brushS2.Freeze();

				brushS3 = new SolidColorBrush(Color.FromArgb(190,67,190,139));
				brushS3.Freeze();				
				
				brushS4 = new SolidColorBrush(Color.FromArgb(190,87,117,144));
				brushS4.Freeze();	
				
				PSpan = true;
				
				AddPlot(new Stroke(Brushes.Goldenrod, 1), PlotStyle.Dot, "CprPP");
				
				AddPlot(new Stroke(Brushes.DarkCyan, 1), PlotStyle.Dot, "CprTopCentralPivot");
				
				AddPlot(new Stroke(Brushes.DarkCyan, 1), PlotStyle.Dot, "CprBottomCentralPivot");
				
				AddPlot(new Stroke(Brushes.OliveDrab, 1), PlotStyle.Hash, "CprS1");
				
				AddPlot(new Stroke(Brushes.Brown, 1), PlotStyle.Hash, "CprR1");
				
				AddPlot(new Stroke(Brushes.OliveDrab, 1), PlotStyle.Hash, "CprS2");
				
				AddPlot(new Stroke(Brushes.Brown, 1), PlotStyle.Hash, "CprR2");
								
				AddPlot(new Stroke(Brushes.OliveDrab, 1), PlotStyle.Hash, "CprS3");
				
				AddPlot(new Stroke(Brushes.Brown, 1), PlotStyle.Hash, "CprR3");
								
				AddPlot(new Stroke(Brushes.OliveDrab, 1), PlotStyle.Hash, "CprS4");
				
				AddPlot(new Stroke(Brushes.Brown, 1), PlotStyle.Hash, "CprR4");
				
				//Parameters for Setting Support and Resistance
				
				//CPR
				PPp = true;
				pTc = true;
				pBc = true;
				
				//R1S1
				pR1 = true;
				pS1 = true;
				
				//R2S2
				pR2 = false;
				pS2 = false;
				
				//R3S3
				pR3 = false;
				pS3 = false;
				
				//R4S4
				pR4 = false;
				pS4 = false;				

			}
			else if (State == State.Configure)
			{
			AddDataSeries(BarsPeriodType.Day,1);
			}
			
			else if (State == State.DataLoaded)
			{

				CPRPercentFont = new SimpleFont("Arial", 10) { Size = 10, Bold = true };
				if(BarsPeriod.BarsPeriodType != BarsPeriodType.Minute)
				{
					errFont = new SimpleFont("Courier New", 10) { Size = 10, Bold = true };
					Draw.TextFixed(this,"Error","Error : Select Only Minute Period Type for HFCSimpleCPR Range to Work!",TextPosition.BottomLeft,Brushes.Red,errFont,Brushes.Red,Brushes.Yellow,60);
					return;
				}
			}
			
		
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
			
			
			if (CurrentBars[1]<1 || CurrentBars[0] < 3)
				return;
			
			
			
			h1 = Highs[1][0];
			c1 = Closes[1][0];
			l1 = Lows[1][0];
			
			if(!BarsArray[0].IsFirstBarOfSession)
			{
				dailyBarCount = dailyBarCount + 1;
			}
			else
			{
				dailyBarCount = 0;
			}
			
			if(BarsPeriod.BarsPeriodType == BarsPeriodType.Minute)
			{

			varpp = (h1+l1+c1)/3;
			varBottpmCentralPivot = (h1 + l1)/2;
			varTopCentralPivot = (varpp - varBottpmCentralPivot)+varpp;
			
			
			varS1 = 2 * varpp - h1;
			varS1 = Math.Round(varS1) - Math.Round(varS1,1)>0?Math.Round(varS1,1)+.05:Math.Round(varS1,1);
				
			varR1 = 2 * varpp - l1;		
			varR1 = Math.Round(varR1) - Math.Round(varR1,1)>0?Math.Round(varR1,1)+.05:Math.Round(varR1,1);
				
			
			//S2 = pp-(h-l)	
			varS2 = varpp - (h1 - l1);
			varS2 = Math.Round(varS2) - Math.Round(varS2,1)>0?Math.Round(varS2,1)+.05:Math.Round(varS2,1);
			
			//R2 = pp + (h-l)
			varR2 = varpp + (h1 - l1);
			varR2 = Math.Round(varR2) - Math.Round(varR2,1)>0?Math.Round(varR2,1)+.05:Math.Round(varR2,1);
				
			//S3 = S1 - (h - l)
			varS3 = varS1 - (h1 - l1);	
			varS3 = Math.Round(varS3) - Math.Round(varS3,1)>0?Math.Round(varS3,1)+.05:Math.Round(varS3,1);
				
			//R3 = 	R1 + (h - l)
			varR3 = varR1 + (h1 - l1);
			varR3 = Math.Round(varR3) - Math.Round(varR3,1)>0?Math.Round(varR3,1)+.05:Math.Round(varR3,1);
				
			//S4 = S3 - (S1 - S2)
			varS4 = varS3 - (varS1 - varS2);	
			varS4 = Math.Round(varS4) - Math.Round(varS4,1)>0?Math.Round(varS4,1)+.05:Math.Round(varS4,1);
				
			//R4 = 	R3 + (r2 - r1)
			varR4 = varR3 + (varR2 - varR1);
			varR4 = Math.Round(varR4) - Math.Round(varR4,1)>0?Math.Round(varR4,1)+.05:Math.Round(varR4,1);
				
				if (PSpan)
				{
					//Percentage Calclulation	
					varUpprSpan = Math.Round(((varR1 - varpp)/(varR1-varS1))*100,2);
					varLowSpan = Math.Round(((varpp - varS1)/(varR1-varS1))*100,2);
					varCprSpan = Math.Round((Math.Log(varTopCentralPivot/varBottpmCentralPivot)*100),2);
					if (varCprSpan < 0)
					{
						varCprSpan = varCprSpan*-1;
					}
					//Draw.Text(this,Times[1][0].Date.ToString()+"U",varUpprSpan.ToString()+"%" + "\n",0,varR1+TickSize);
					Draw.Text(this,Times[1][0].Date.ToString()+"CPR",false,varCprSpan.ToString() + "%",0,varpp+TickSize,0,Brushes.Brown,CPRPercentFont,TextAlignment.Center,Brushes.Transparent,Brushes.Orange,50);
					//Draw.Text(this,Times[1][0].Date.ToString()+"L","\n" + varLowSpan.ToString()+"%",0,varS1-TickSize);
				
					
				}

				if (PPp)
				{
					CprPP[0] = varpp;
				}
				
				if (pTc)
				{
					CprTopCentralPivot[0] = varTopCentralPivot;
				}
				
				if (pBc)
				{
					CprBottomCentralPivot[0] = varBottpmCentralPivot;
				}
				
				if (pS1)
				{
					if(PSpan)
					{
						Draw.Text(this,Times[1][0].Date.ToString()+"L","\n" + varLowSpan.ToString()+"%",0,varS1-TickSize,Brushes.OliveDrab);
					}					
					vCPP_to_S1 = Math.Round(Math.Log(varpp/varS1)*100,2);
					Draw.Text(this,Times[1][0].Date.ToString()+"S1","\nS1 - "+vCPP_to_S1.ToString()+"%",dailyBarCount,varS1,Brushes.OliveDrab);
					CprS1[0] = varS1;
				}
				
				
				if (pR1)
				{
					if (PSpan)
					{
						Draw.Text(this,Times[1][0].Date.ToString()+"U",varUpprSpan.ToString()+"%" + "\n",0,varR1+TickSize, Brushes.Brown);
					}					
					vCPP_to_R1 = Math.Round(Math.Log(varR1/varpp)*100,2);
					Draw.Text(this,Times[1][0].Date.ToString()+"R1","R1 - "+vCPP_to_R1.ToString()+"%\n",dailyBarCount+2,varR1, Brushes.Brown);
					CprR1[0] = varR1;
					
				}
				
				if (pS2)
				{
					vCPP_to_S2 = Math.Round(Math.Log(varpp/varS2)*100,2);
					Draw.Text(this,Times[1][0].Date.ToString()+"S2","\nS2 - "+vCPP_to_S2.ToString()+"%",dailyBarCount+2,varS2,Brushes.OliveDrab);				
					CprS2[0] = varS2;
				}
				if (pR2)
				{
					vCPP_to_R2 = Math.Round(Math.Log(varR2/varpp)*100,2);
					Draw.Text(this,Times[1][0].Date.ToString()+"R2","R2 - "+vCPP_to_R2.ToString()+"%\n",dailyBarCount+2,varR2, Brushes.Brown);				
					CprR2[0] = varR2;
				}	
				
				if (pS3)
				{
					vCPP_to_S3 = Math.Round(Math.Log(varpp/varS3)*100,2);
					Draw.Text(this,Times[1][0].Date.ToString()+"S3","\nS3 - "+vCPP_to_S3.ToString()+"%",dailyBarCount+2,varS3,Brushes.OliveDrab);
					CprS3[0] = varS3;
				}
				if (pR3)
				{
					vCPP_to_R3 = Math.Round(Math.Log(varR3/varpp)*100,2);
					Draw.Text(this,Times[1][0].Date.ToString()+"R3","R3 - "+vCPP_to_R3.ToString()+"%\n",dailyBarCount+2,varR3, Brushes.Brown);								
					CprR3[0] = varR3;
				}
				
				if (pS4)
				{
					vCPP_to_S4 = Math.Round(Math.Log(varpp/varS4)*100,2);
					Draw.Text(this,Times[1][0].Date.ToString()+"S4","\nS4 - "+vCPP_to_S4.ToString()+"%",dailyBarCount+2,varS4,Brushes.OliveDrab);				
					CprS4[0] = varS4;
				}
				if (pR4)
				{
					vCPP_to_R4 = Math.Round(Math.Log(varR4/varpp)*100,2);
					Draw.Text(this,Times[1][0].Date.ToString()+"R4","R4 - "+vCPP_to_R4.ToString()+"%\n",dailyBarCount+2,varR4, Brushes.Brown);					
					CprR4[0] = varR4;
				}
			
			}
		}

		#region Properties
		
		[NinjaScriptProperty]
		[Display(Name="Display Span %", Order=1, GroupName="Display Spans")]
		public bool PSpan
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="PP", Order=1, GroupName="CPR")]
		public bool PPp
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="TC", Order=2, GroupName="CPR")]
		public bool pTc
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="BC", Order=3, GroupName="CPR")]
		public bool pBc
		{ get; set; }		
		
		
		[NinjaScriptProperty]
		[Display(Name="R1", Order=1, GroupName="Resistance Pivot Points")]
		public bool pR1
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="R2", Order=2, GroupName="Resistance Pivot Points")]
		public bool pR2
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="R3", Order=3, GroupName="Resistance Pivot Points")]
		public bool pR3
		{ get; set; }		
		
		[NinjaScriptProperty]
		[Display(Name="R4", Order=4, GroupName="Resistance Pivot Points")]
		public bool pR4
		{ get; set; }				
		
		[NinjaScriptProperty]
		[Display(Name="S1", Order=1, GroupName="Support Pivot Points")]
		public bool pS1
		{ get; set; }						

		[NinjaScriptProperty]
		[Display(Name="S2", Order=2, GroupName="Support Pivot Points")]
		public bool pS2
		{ get; set; }			

		[NinjaScriptProperty]
		[Display(Name="S3", Order=3, GroupName="Support Pivot Points")]
		public bool pS3
		{ get; set; }						

		[NinjaScriptProperty]
		[Display(Name="S4", Order=4, GroupName="Support Pivot Points")]
		public bool pS4
		{ get; set; }			
		
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> CprPP
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> CprTopCentralPivot
		{
			get { return Values[1]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> CprBottomCentralPivot
		{
			get { return Values[2]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> CprS1
		{
			get { return Values[3]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> CprR1
		{
			get { return Values[4]; }
		}
		

		
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> CprS2
		{
			get { return Values[5]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> CprR2
		{
			get { return Values[6]; }
		}		
		

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> CprS3
		{
			get { return Values[7]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> CprR3
		{
			get { return Values[8]; }
		}				


		[Browsable(false)]
		[XmlIgnore]
		public Series<double> CprS4
		{
			get { return Values[9]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> CprR4
		{
			get { return Values[10]; }
		}						
		
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HFCSimpleCPR[] cacheHFCSimpleCPR;
		public HFCSimpleCPR HFCSimpleCPR(bool pSpan, bool pPp, bool pTc, bool pBc, bool pR1, bool pR2, bool pR3, bool pR4, bool pS1, bool pS2, bool pS3, bool pS4)
		{
			return HFCSimpleCPR(Input, pSpan, pPp, pTc, pBc, pR1, pR2, pR3, pR4, pS1, pS2, pS3, pS4);
		}

		public HFCSimpleCPR HFCSimpleCPR(ISeries<double> input, bool pSpan, bool pPp, bool pTc, bool pBc, bool pR1, bool pR2, bool pR3, bool pR4, bool pS1, bool pS2, bool pS3, bool pS4)
		{
			if (cacheHFCSimpleCPR != null)
				for (int idx = 0; idx < cacheHFCSimpleCPR.Length; idx++)
					if (cacheHFCSimpleCPR[idx] != null && cacheHFCSimpleCPR[idx].PSpan == pSpan && cacheHFCSimpleCPR[idx].PPp == pPp && cacheHFCSimpleCPR[idx].pTc == pTc && cacheHFCSimpleCPR[idx].pBc == pBc && cacheHFCSimpleCPR[idx].pR1 == pR1 && cacheHFCSimpleCPR[idx].pR2 == pR2 && cacheHFCSimpleCPR[idx].pR3 == pR3 && cacheHFCSimpleCPR[idx].pR4 == pR4 && cacheHFCSimpleCPR[idx].pS1 == pS1 && cacheHFCSimpleCPR[idx].pS2 == pS2 && cacheHFCSimpleCPR[idx].pS3 == pS3 && cacheHFCSimpleCPR[idx].pS4 == pS4 && cacheHFCSimpleCPR[idx].EqualsInput(input))
						return cacheHFCSimpleCPR[idx];
			return CacheIndicator<HFCSimpleCPR>(new HFCSimpleCPR(){ PSpan = pSpan, PPp = pPp, pTc = pTc, pBc = pBc, pR1 = pR1, pR2 = pR2, pR3 = pR3, pR4 = pR4, pS1 = pS1, pS2 = pS2, pS3 = pS3, pS4 = pS4 }, input, ref cacheHFCSimpleCPR);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HFCSimpleCPR HFCSimpleCPR(bool pSpan, bool pPp, bool pTc, bool pBc, bool pR1, bool pR2, bool pR3, bool pR4, bool pS1, bool pS2, bool pS3, bool pS4)
		{
			return indicator.HFCSimpleCPR(Input, pSpan, pPp, pTc, pBc, pR1, pR2, pR3, pR4, pS1, pS2, pS3, pS4);
		}

		public Indicators.HFCSimpleCPR HFCSimpleCPR(ISeries<double> input , bool pSpan, bool pPp, bool pTc, bool pBc, bool pR1, bool pR2, bool pR3, bool pR4, bool pS1, bool pS2, bool pS3, bool pS4)
		{
			return indicator.HFCSimpleCPR(input, pSpan, pPp, pTc, pBc, pR1, pR2, pR3, pR4, pS1, pS2, pS3, pS4);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HFCSimpleCPR HFCSimpleCPR(bool pSpan, bool pPp, bool pTc, bool pBc, bool pR1, bool pR2, bool pR3, bool pR4, bool pS1, bool pS2, bool pS3, bool pS4)
		{
			return indicator.HFCSimpleCPR(Input, pSpan, pPp, pTc, pBc, pR1, pR2, pR3, pR4, pS1, pS2, pS3, pS4);
		}

		public Indicators.HFCSimpleCPR HFCSimpleCPR(ISeries<double> input , bool pSpan, bool pPp, bool pTc, bool pBc, bool pR1, bool pR2, bool pR3, bool pR4, bool pS1, bool pS2, bool pS3, bool pS4)
		{
			return indicator.HFCSimpleCPR(input, pSpan, pPp, pTc, pBc, pR1, pR2, pR3, pR4, pS1, pS2, pS3, pS4);
		}
	}
}

#endregion
