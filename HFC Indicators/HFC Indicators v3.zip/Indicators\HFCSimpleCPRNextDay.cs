#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class HFCSimpleCPRNextDay : Indicator
	{
		private double varpp,varBottpmCentralPivot,varTopCentralPivot,varS1,varR1, varS2, varR2, varS3, varR3, varS4, varR4;
		private double h1,l1,c1;
		private SimpleFont CPRPercentFont;
		private SimpleFont errFont;
		private double varUpprSpan,varLowSpan,varCprSpan;
		private DateTime dateBegin;
		
		private Brush brushPP, brushTC, brushR1,brushR2,brushR3,brushR4;
		private Brush brushBC, brushS1,brushS2,brushS3,brushS4;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Pivot Based Simple CPr which will draw lines for next day and we can prepare for next day";
				Name										= "HFCSimpleCPRNextDay";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				IsAutoScale									= false;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				
				//Configure Brushes
				brushPP = new SolidColorBrush(Color.FromArgb(190,255,255,255));
				brushPP.Freeze();

				brushTC = new SolidColorBrush(Color.FromArgb(190,184,242,230));
				brushTC.Freeze();				
				
				brushBC = new SolidColorBrush(Color.FromArgb(190,184,242,230));
				brushBC.Freeze();				

				brushS1 = new SolidColorBrush(Color.FromArgb(190,128,185,24));
				brushS1.Freeze();

				brushR1 = new SolidColorBrush(Color.FromArgb(190,218,58,52));
				brushR1.Freeze();	
				
				brushR2 = new SolidColorBrush(Color.FromArgb(160,243,114,44));
				brushR2.Freeze();

				brushR3 = new SolidColorBrush(Color.FromArgb(160,248,150,30));
				brushR3.Freeze();				
				
				brushR4 = new SolidColorBrush(Color.FromArgb(160,249,199,79));
				brushR4.Freeze();				

				brushS2 = new SolidColorBrush(Color.FromArgb(160,144,190,109));
				brushS2.Freeze();

				brushS3 = new SolidColorBrush(Color.FromArgb(160,67,190,139));
				brushS3.Freeze();				
				
				brushS4 = new SolidColorBrush(Color.FromArgb(160,87,117,144));
				brushS4.Freeze();	
				
				PSpan = true;
				
     			//Parameters for Setting Support and Resistance
				//R1S1
				pR1 = true;
				pS1 = true;
				
				//R2S2
				pR2 = false;
				pS2 = false;
				
				//R3S3
				pR3 = false;
				pS3 = false;
				
				//R4S4
				pR4 = false;
				pS4 = false;	
				
				
			}
			else if (State == State.Configure)
			{
				AddDataSeries(Data.BarsPeriodType.Day, 1);
			}
			else if (State == State.DataLoaded)
			{
				CPRPercentFont = new SimpleFont("Arial", 12) { Size = 12, Bold = true };
				if(BarsPeriod.BarsPeriodType != BarsPeriodType.Minute)
				{
					errFont = new SimpleFont("Courier New", 12) { Size = 30, Bold = true };
					Draw.TextFixed(this,"Error","Error : Select Only Minute Period Type for HFCSimpleCPR Range to Work!",TextPosition.BottomLeft,Brushes.Red,errFont,Brushes.Red,Brushes.Yellow,60);
					return;
				}
    				
					
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
			if ((BarsArray[1].Count - CurrentBars[1]) != 1)
			{
				return;
			}
			
			if (BarsArray[0].IsLastBarOfSession)
			{
			if (h1 != Highs[1][0])
				h1 = Math.Round(Highs[1][0],2);
			if (l1 != Lows[1][0])
				l1 = Math.Round(Lows[1][0],2);
			if (c1 != Closes[1][0])
				c1 = Math.Round(Closes[1][0],2);			
			
				
			varpp = (h1+l1+c1)/3;
			varBottpmCentralPivot = (h1 + l1)/2;
			varTopCentralPivot = (varpp - varBottpmCentralPivot)+varpp;
			
			
			varS1 = 2 * varpp - h1;
			varR1 = 2 * varpp - l1;		
			
			//S2 = pp-(h-l)	
			varS2 = varpp - (h1 - l1);
			
			//R2 = pp + (h-l)
			varR2 = varpp + (h1 - l1);
				
			//S3 = S1 - (h - l)
			varS3 = varS1 - (h1 - l1);	
				
			//R3 = 	R1 + (h - l)
			varR3 = varR1 + (h1 - l1);
				
			//S4 = S3 - (S1 - S2)
			varS4 = varS3 - (varS1 - varS2);	
				
			//R4 = 	R4 + (r2 - r1)
			varR4 = varR3 + (varR2 - varR1);
				if (PSpan)
				{
					//Percentage Calclulation	
					varUpprSpan = Math.Round(((varR1 - varpp)/(varR1-varS1))*100,2);
					varLowSpan = Math.Round(((varpp - varS1)/(varR1-varS1))*100,2);
					varCprSpan = Math.Round((Math.Log(varTopCentralPivot/varBottpmCentralPivot)*100),2);
					if (varCprSpan < 0)
					{
						varCprSpan = varCprSpan*-1;
					}
					Draw.Text(this,Times[1][0].Date.ToString()+"U",varUpprSpan.ToString()+"%" + "\n",0,varR1+TickSize);
					Draw.Text(this,Times[1][0].Date.ToString()+"CPR",false,varCprSpan.ToString() + "%",0,varpp+TickSize,0,Brushes.White,CPRPercentFont,TextAlignment.Center,Brushes.Gray,Brushes.Crimson,50);
					Draw.Text(this,Times[1][0].Date.ToString()+"L","\n" + varLowSpan.ToString()+"%",0,varS1-TickSize);
				}			

				
			Draw.HorizontalLine(this,varpp+"varppnxt",varpp,brushPP);
			Draw.HorizontalLine(this,varpp+"varBottpmCentralPivot",varBottpmCentralPivot,brushTC);
			Draw.HorizontalLine(this,varpp+"varTopCentralPivot",varTopCentralPivot,brushBC);				
			
			if (pS1)
			{
				Draw.HorizontalLine(this,varS1+"varS1",varS1,brushS1);
			}
			if (pR1)
			{
				Draw.HorizontalLine(this,varR1+"varR1",varR1,brushR1);
			}
			
			if (pS2)
			{
				Draw.HorizontalLine(this,varS2+"varS2",varS2,brushS2);
			}
			if (pR2)
			{
				Draw.HorizontalLine(this,varR2+"varR2",varR2,brushR2);
			}	
			
			if (pS3)
			{
				Draw.HorizontalLine(this,varS3+"varS3",varS3,brushS3);
			}
			if (pR3)
			{
				Draw.HorizontalLine(this,varR3+"varR3",varR3,brushR3);
			}
			
			if (pS4)
			{
				Draw.HorizontalLine(this,varS4+"varS4",varS4,brushS4);
			}
			if (pR4)
			{
				Draw.HorizontalLine(this,varR4+"varR4",varR4,brushR4);
			}
				
				
			}

		}
		
		#region Property
		[NinjaScriptProperty]
		[Display(Name="Display Span %", Order=1, GroupName="Display Spans")]
		public bool PSpan
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="R1", Order=1, GroupName="Resistance Pivot Points")]
		public bool pR1
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="R2", Order=2, GroupName="Resistance Pivot Points")]
		public bool pR2
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="R3", Order=3, GroupName="Resistance Pivot Points")]
		public bool pR3
		{ get; set; }		
		
		[NinjaScriptProperty]
		[Display(Name="R4", Order=4, GroupName="Resistance Pivot Points")]
		public bool pR4
		{ get; set; }				
		
		[NinjaScriptProperty]
		[Display(Name="S1", Order=1, GroupName="Support Pivot Points")]
		public bool pS1
		{ get; set; }						

		[NinjaScriptProperty]
		[Display(Name="S2", Order=2, GroupName="Support Pivot Points")]
		public bool pS2
		{ get; set; }			

		[NinjaScriptProperty]
		[Display(Name="S3", Order=3, GroupName="Support Pivot Points")]
		public bool pS3
		{ get; set; }						

		[NinjaScriptProperty]
		[Display(Name="S4", Order=4, GroupName="Support Pivot Points")]
		public bool pS4
		{ get; set; }		

		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HFCSimpleCPRNextDay[] cacheHFCSimpleCPRNextDay;
		public HFCSimpleCPRNextDay HFCSimpleCPRNextDay(bool pSpan, bool pR1, bool pR2, bool pR3, bool pR4, bool pS1, bool pS2, bool pS3, bool pS4)
		{
			return HFCSimpleCPRNextDay(Input, pSpan, pR1, pR2, pR3, pR4, pS1, pS2, pS3, pS4);
		}

		public HFCSimpleCPRNextDay HFCSimpleCPRNextDay(ISeries<double> input, bool pSpan, bool pR1, bool pR2, bool pR3, bool pR4, bool pS1, bool pS2, bool pS3, bool pS4)
		{
			if (cacheHFCSimpleCPRNextDay != null)
				for (int idx = 0; idx < cacheHFCSimpleCPRNextDay.Length; idx++)
					if (cacheHFCSimpleCPRNextDay[idx] != null && cacheHFCSimpleCPRNextDay[idx].PSpan == pSpan && cacheHFCSimpleCPRNextDay[idx].pR1 == pR1 && cacheHFCSimpleCPRNextDay[idx].pR2 == pR2 && cacheHFCSimpleCPRNextDay[idx].pR3 == pR3 && cacheHFCSimpleCPRNextDay[idx].pR4 == pR4 && cacheHFCSimpleCPRNextDay[idx].pS1 == pS1 && cacheHFCSimpleCPRNextDay[idx].pS2 == pS2 && cacheHFCSimpleCPRNextDay[idx].pS3 == pS3 && cacheHFCSimpleCPRNextDay[idx].pS4 == pS4 && cacheHFCSimpleCPRNextDay[idx].EqualsInput(input))
						return cacheHFCSimpleCPRNextDay[idx];
			return CacheIndicator<HFCSimpleCPRNextDay>(new HFCSimpleCPRNextDay(){ PSpan = pSpan, pR1 = pR1, pR2 = pR2, pR3 = pR3, pR4 = pR4, pS1 = pS1, pS2 = pS2, pS3 = pS3, pS4 = pS4 }, input, ref cacheHFCSimpleCPRNextDay);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HFCSimpleCPRNextDay HFCSimpleCPRNextDay(bool pSpan, bool pR1, bool pR2, bool pR3, bool pR4, bool pS1, bool pS2, bool pS3, bool pS4)
		{
			return indicator.HFCSimpleCPRNextDay(Input, pSpan, pR1, pR2, pR3, pR4, pS1, pS2, pS3, pS4);
		}

		public Indicators.HFCSimpleCPRNextDay HFCSimpleCPRNextDay(ISeries<double> input , bool pSpan, bool pR1, bool pR2, bool pR3, bool pR4, bool pS1, bool pS2, bool pS3, bool pS4)
		{
			return indicator.HFCSimpleCPRNextDay(input, pSpan, pR1, pR2, pR3, pR4, pS1, pS2, pS3, pS4);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HFCSimpleCPRNextDay HFCSimpleCPRNextDay(bool pSpan, bool pR1, bool pR2, bool pR3, bool pR4, bool pS1, bool pS2, bool pS3, bool pS4)
		{
			return indicator.HFCSimpleCPRNextDay(Input, pSpan, pR1, pR2, pR3, pR4, pS1, pS2, pS3, pS4);
		}

		public Indicators.HFCSimpleCPRNextDay HFCSimpleCPRNextDay(ISeries<double> input , bool pSpan, bool pR1, bool pR2, bool pR3, bool pR4, bool pS1, bool pS2, bool pS3, bool pS4)
		{
			return indicator.HFCSimpleCPRNextDay(input, pSpan, pR1, pR2, pR3, pR4, pS1, pS2, pS3, pS4);
		}
	}
}

#endregion
