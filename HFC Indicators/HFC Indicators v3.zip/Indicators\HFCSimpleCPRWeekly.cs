#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class HFCSimpleCPRWeekly : Indicator
	{
		private double varpp,varBottpmCentralPivot,varTopCentralPivot,varS1,varR1, varS2, varR2, varS3, varR3, varS4, varR4,h1,c1, l1;
		private SimpleFont errFont;
		private SimpleFont CPRPercentFont;
		private int weekDay;
		private double varUpprSpan,varLowSpan,varCprSpan, tempWeeklyPP;
		private int WeeklyBarsCount = 0;
		private bool sameWeelyPP;
		private double tempBarsCount = 0;
		
		
		private Brush brushR2,brushR3,brushR4;
		private Brush brushS2,brushS3,brushS4;
		
		private int WeeklyBarCount;
		private double vCPP_to_R1,vCPP_to_R2,vCPP_to_R3,vCPP_to_R4;
		private double vCPP_to_S1,vCPP_to_S2,vCPP_to_S3,vCPP_to_S4;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Simple Central Pivot Range - Weekly";
				Name										= "HFCSimpleCPRWeekly";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				Displacement								= 1;
				IsSuspendedWhileInactive					= true;
				IsAutoScale									= false;
				
				WeeklyBarsCount = 0;
				sameWeelyPP = false;
				tempWeeklyPP = 0;
				varpp = 0;
				
				//Configure Brushes
				brushR2 = new SolidColorBrush(Color.FromArgb(190,243,114,44));
				brushR2.Freeze();

				brushR3 = new SolidColorBrush(Color.FromArgb(190,248,150,30));
				brushR3.Freeze();				
				
				brushR4 = new SolidColorBrush(Color.FromArgb(190,249,199,79));
				brushR4.Freeze();				

				brushS2 = new SolidColorBrush(Color.FromArgb(190,144,190,109));
				brushS2.Freeze();

				brushS3 = new SolidColorBrush(Color.FromArgb(190,67,190,139));
				brushS3.Freeze();				
				
				brushS4 = new SolidColorBrush(Color.FromArgb(190,87,117,144));
				brushS4.Freeze();	
				
				PSpan = true;
				
				AddPlot(new Stroke(Brushes.Goldenrod, 1), PlotStyle.Dot, "CprPP");
				
				AddPlot(new Stroke(Brushes.DarkCyan, 1), PlotStyle.Dot, "CprTopCentralPivot");
				
				AddPlot(new Stroke(Brushes.DarkCyan, 1), PlotStyle.Dot, "CprBottomCentralPivot");
				
				AddPlot(new Stroke(Brushes.OliveDrab, 1), PlotStyle.Hash, "CprS1");
				
				AddPlot(new Stroke(Brushes.Brown, 1), PlotStyle.Hash, "CprR1");
				
				AddPlot(new Stroke(Brushes.OliveDrab, 1), PlotStyle.Hash, "CprS2");
				
				AddPlot(new Stroke(Brushes.Brown, 1), PlotStyle.Hash, "CprR2");
								
				AddPlot(new Stroke(Brushes.OliveDrab, 1), PlotStyle.Hash, "CprS3");
				
				AddPlot(new Stroke(Brushes.Brown, 1), PlotStyle.Hash, "CprR3");
								
				AddPlot(new Stroke(Brushes.OliveDrab, 1), PlotStyle.Hash, "CprS4");
				
				AddPlot(new Stroke(Brushes.Brown, 1), PlotStyle.Hash, "CprR4");
				
				//Parameters for Setting Support and Resistance
				//CPR
				PPp = true;
				pTc = true;
				pBc = true;				
				
				//R1S1
				pR1 = true;
				pS1 = true;
				
				//R2S2
				pR2 = false;
				pS2 = false;
				
				//R3S3
				pR3 = false;
				pS3 = false;
				
				//R4S4
				pR4 = false;
				pS4 = false;
			}
			else if (State == State.Configure)
			{
				AddDataSeries(BarsPeriodType.Week,1);
			}

			else if (State == State.DataLoaded)
			{

				CPRPercentFont = new SimpleFont("Arial", 12) { Size = 12, Bold = true };
				/*if(BarsPeriod.BarsPeriodType != BarsPeriodType.Minute)
				{
					errFont = new SimpleFont("Courier New", 12) { Size = 30, Bold = true };
					Draw.TextFixed(this,"Error","Error : Select Only Minute Period Type for HFCSimpleCPR Range to Work!",TextPosition.BottomLeft,Brushes.Red,errFont,Brushes.Red,Brushes.Yellow,60);
					return;
				}*/
			}
		}

		protected override void OnBarUpdate()
		{
		//Add your custom indicator logic here.
			
			
			if (CurrentBars[1]<1 || CurrentBars[0]<3 || CurrentBars[0] == tempBarsCount)
				return;
			
			tempBarsCount = CurrentBars[0];
			h1 = Highs[1][0];
			c1 = Closes[1][0];
			l1 = Lows[1][0];

			tempWeeklyPP = 	varpp;
			

				
			varpp = (h1+l1+c1)/3;
			varBottpmCentralPivot = (h1 + l1)/2;
			varTopCentralPivot = (varpp - varBottpmCentralPivot)+varpp;
			
			if (tempWeeklyPP == varpp)
			{
				WeeklyBarsCount = WeeklyBarsCount+1;
			}
			else
			{
				WeeklyBarsCount = 0;
			}
			
			
			
			varS1 = 2 * varpp - h1;
			varS1 = Math.Round(varS1) - Math.Round(varS1,1)>0?Math.Round(varS1,1)+.05:Math.Round(varS1,1);
				
			varR1 = 2 * varpp - l1;		
			varR1 = Math.Round(varR1) - Math.Round(varR1,1)>0?Math.Round(varR1,1)+.05:Math.Round(varR1,1);
				
			
			//S2 = pp-(h-l)	
			varS2 = varpp - (h1 - l1);
			varS2 = Math.Round(varS2) - Math.Round(varS2,1)>0?Math.Round(varS2,1)+.05:Math.Round(varS2,1);
			
			//R2 = pp + (h-l)
			varR2 = varpp + (h1 - l1);
			varR2 = Math.Round(varR2) - Math.Round(varR2,1)>0?Math.Round(varR2,1)+.05:Math.Round(varR2,1);
				
			//S3 = S1 - (h - l)
			varS3 = varS1 - (h1 - l1);	
			varS3 = Math.Round(varS3) - Math.Round(varS3,1)>0?Math.Round(varS3,1)+.05:Math.Round(varS3,1);
				
			//R3 = 	R1 + (h - l)
			varR3 = varR1 + (h1 - l1);
			varR3 = Math.Round(varR3) - Math.Round(varR3,1)>0?Math.Round(varR3,1)+.05:Math.Round(varR3,1);
				
			//S4 = S3 - (S1 - S2)
			varS4 = varS3 - (varS1 - varS2);	
			varS4 = Math.Round(varS4) - Math.Round(varS4,1)>0?Math.Round(varS4,1)+.05:Math.Round(varS4,1);
				
			//R4 = 	R3 + (r2 - r1)
			varR4 = varR3 + (varR2 - varR1);
			varR4 = Math.Round(varR4) - Math.Round(varR4,1)>0?Math.Round(varR4,1)+.05:Math.Round(varR4,1);			
				
				
				if (PSpan)
				{
					//Percentage Calclulation	
					varUpprSpan = Math.Round(((varR1 - varpp)/(varR1-varS1))*100,2);
					varLowSpan = Math.Round(((varpp - varS1)/(varR1-varS1))*100,2);
					varCprSpan = Math.Round((Math.Log(varTopCentralPivot/varBottpmCentralPivot)*100),2);
					if (varCprSpan < 0)
					{
						varCprSpan = varCprSpan*-1;
					}
					//Draw.Text(this,Times[1][0].Date.ToString()+"U",varUpprSpan.ToString()+"%" + "\n",0,varR1+TickSize);
					Draw.Text(this,Times[1][0].Date.ToString()+"CPR",false,varCprSpan.ToString() + "%",0,varpp+TickSize,0,Brushes.White,CPRPercentFont,TextAlignment.Center,Brushes.Transparent,Brushes.DeepPink,50);
					//Draw.Text(this,Times[1][0].Date.ToString()+"L","\n" + varLowSpan.ToString()+"%",0,varS1-TickSize);
					Draw.Rectangle(this,"PivotWeeklyRect" + Times[1][0].ToString(),false,WeeklyBarsCount,varTopCentralPivot,0,	varBottpmCentralPivot,Brushes.Transparent, Brushes.RoyalBlue,20);
				
					
				}

				
			if (PPp)
				{
					CprPP[0] = varpp;
				}
				
				if (pTc)
				{
					CprTopCentralPivot[0] = varTopCentralPivot;
				}
				
				if (pBc)
				{
					CprBottomCentralPivot[0] = varBottpmCentralPivot;
		
				}
				
				if (pS1)
				{
					if(PSpan)
					{
						Draw.Text(this,Times[1][0].Date.ToString()+"L","\n" + varLowSpan.ToString()+"%",0,varS1-TickSize,Brushes.OliveDrab);
					}
					CprS1[0] = varS1;
				}
				
				
				if (pR1)
				{
					if (PSpan)
					{
						Draw.Text(this,Times[1][0].Date.ToString()+"U",varUpprSpan.ToString()+"%" + "\n",0,varR1+TickSize,Brushes.Brown);
					}
					CprR1[0] = varR1;
					
				}
				
				if (pS2)
				{
					CprS2[0] = varS2;
				}
				if (pR2)
				{
					CprR2[0] = varR2;
				}	
				
				if (pS3)
				{
					CprS3[0] = varS3;
				}
				if (pR3)
				{
					CprR3[0] = varR3;
				}
				
				if (pS4)
				{
					CprS4[0] = varS4;
				}
				if (pR4)
				{
					CprR4[0] = varR4;
				}
			
		}

		#region Properties
		
		[NinjaScriptProperty]
		[Display(Name="Display Span %", Order=1, GroupName="Display Spans")]
		public bool PSpan
		{ get; set; }
		

		[NinjaScriptProperty]
		[Display(Name="PP", Order=1, GroupName="CPR")]
		public bool PPp
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="TC", Order=2, GroupName="CPR")]
		public bool pTc
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="BC", Order=3, GroupName="CPR")]
		public bool pBc
		{ get; set; }		
				
		
		[NinjaScriptProperty]
		[Display(Name="R1", Order=1, GroupName="Resistance Pivot Points")]
		public bool pR1
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="R2", Order=2, GroupName="Resistance Pivot Points")]
		public bool pR2
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="R3", Order=3, GroupName="Resistance Pivot Points")]
		public bool pR3
		{ get; set; }		
		
		[NinjaScriptProperty]
		[Display(Name="R4", Order=4, GroupName="Resistance Pivot Points")]
		public bool pR4
		{ get; set; }				
		
		[NinjaScriptProperty]
		[Display(Name="S1", Order=1, GroupName="Support Pivot Points")]
		public bool pS1
		{ get; set; }						

		[NinjaScriptProperty]
		[Display(Name="S2", Order=2, GroupName="Support Pivot Points")]
		public bool pS2
		{ get; set; }			

		[NinjaScriptProperty]
		[Display(Name="S3", Order=3, GroupName="Support Pivot Points")]
		public bool pS3
		{ get; set; }						

		[NinjaScriptProperty]
		[Display(Name="S4", Order=4, GroupName="Support Pivot Points")]
		public bool pS4
		{ get; set; }			
		
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> CprPP
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> CprTopCentralPivot
		{
			get { return Values[1]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> CprBottomCentralPivot
		{
			get { return Values[2]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> CprS1
		{
			get { return Values[3]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> CprR1
		{
			get { return Values[4]; }
		}
		

		
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> CprS2
		{
			get { return Values[5]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> CprR2
		{
			get { return Values[6]; }
		}		
		

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> CprS3
		{
			get { return Values[7]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> CprR3
		{
			get { return Values[8]; }
		}				


		[Browsable(false)]
		[XmlIgnore]
		public Series<double> CprS4
		{
			get { return Values[9]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> CprR4
		{
			get { return Values[10]; }
		}						
		
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HFCSimpleCPRWeekly[] cacheHFCSimpleCPRWeekly;
		public HFCSimpleCPRWeekly HFCSimpleCPRWeekly(bool pSpan, bool pPp, bool pTc, bool pBc, bool pR1, bool pR2, bool pR3, bool pR4, bool pS1, bool pS2, bool pS3, bool pS4)
		{
			return HFCSimpleCPRWeekly(Input, pSpan, pPp, pTc, pBc, pR1, pR2, pR3, pR4, pS1, pS2, pS3, pS4);
		}

		public HFCSimpleCPRWeekly HFCSimpleCPRWeekly(ISeries<double> input, bool pSpan, bool pPp, bool pTc, bool pBc, bool pR1, bool pR2, bool pR3, bool pR4, bool pS1, bool pS2, bool pS3, bool pS4)
		{
			if (cacheHFCSimpleCPRWeekly != null)
				for (int idx = 0; idx < cacheHFCSimpleCPRWeekly.Length; idx++)
					if (cacheHFCSimpleCPRWeekly[idx] != null && cacheHFCSimpleCPRWeekly[idx].PSpan == pSpan && cacheHFCSimpleCPRWeekly[idx].PPp == pPp && cacheHFCSimpleCPRWeekly[idx].pTc == pTc && cacheHFCSimpleCPRWeekly[idx].pBc == pBc && cacheHFCSimpleCPRWeekly[idx].pR1 == pR1 && cacheHFCSimpleCPRWeekly[idx].pR2 == pR2 && cacheHFCSimpleCPRWeekly[idx].pR3 == pR3 && cacheHFCSimpleCPRWeekly[idx].pR4 == pR4 && cacheHFCSimpleCPRWeekly[idx].pS1 == pS1 && cacheHFCSimpleCPRWeekly[idx].pS2 == pS2 && cacheHFCSimpleCPRWeekly[idx].pS3 == pS3 && cacheHFCSimpleCPRWeekly[idx].pS4 == pS4 && cacheHFCSimpleCPRWeekly[idx].EqualsInput(input))
						return cacheHFCSimpleCPRWeekly[idx];
			return CacheIndicator<HFCSimpleCPRWeekly>(new HFCSimpleCPRWeekly(){ PSpan = pSpan, PPp = pPp, pTc = pTc, pBc = pBc, pR1 = pR1, pR2 = pR2, pR3 = pR3, pR4 = pR4, pS1 = pS1, pS2 = pS2, pS3 = pS3, pS4 = pS4 }, input, ref cacheHFCSimpleCPRWeekly);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HFCSimpleCPRWeekly HFCSimpleCPRWeekly(bool pSpan, bool pPp, bool pTc, bool pBc, bool pR1, bool pR2, bool pR3, bool pR4, bool pS1, bool pS2, bool pS3, bool pS4)
		{
			return indicator.HFCSimpleCPRWeekly(Input, pSpan, pPp, pTc, pBc, pR1, pR2, pR3, pR4, pS1, pS2, pS3, pS4);
		}

		public Indicators.HFCSimpleCPRWeekly HFCSimpleCPRWeekly(ISeries<double> input , bool pSpan, bool pPp, bool pTc, bool pBc, bool pR1, bool pR2, bool pR3, bool pR4, bool pS1, bool pS2, bool pS3, bool pS4)
		{
			return indicator.HFCSimpleCPRWeekly(input, pSpan, pPp, pTc, pBc, pR1, pR2, pR3, pR4, pS1, pS2, pS3, pS4);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HFCSimpleCPRWeekly HFCSimpleCPRWeekly(bool pSpan, bool pPp, bool pTc, bool pBc, bool pR1, bool pR2, bool pR3, bool pR4, bool pS1, bool pS2, bool pS3, bool pS4)
		{
			return indicator.HFCSimpleCPRWeekly(Input, pSpan, pPp, pTc, pBc, pR1, pR2, pR3, pR4, pS1, pS2, pS3, pS4);
		}

		public Indicators.HFCSimpleCPRWeekly HFCSimpleCPRWeekly(ISeries<double> input , bool pSpan, bool pPp, bool pTc, bool pBc, bool pR1, bool pR2, bool pR3, bool pR4, bool pS1, bool pS2, bool pS3, bool pS4)
		{
			return indicator.HFCSimpleCPRWeekly(input, pSpan, pPp, pTc, pBc, pR1, pR2, pR3, pR4, pS1, pS2, pS3, pS4);
		}
	}
}

#endregion
