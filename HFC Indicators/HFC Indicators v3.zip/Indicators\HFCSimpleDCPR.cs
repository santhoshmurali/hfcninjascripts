#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class HFCSimpleDCPR : Indicator
	{
		private double vPP,vTC,vBC;
		private double hh,ll,cc;
		
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"DevelopingCPR";
				Name										= "HFCSimpleDCPR";
				Calculate									= Calculate.OnEachTick;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				
				AddPlot(Brushes.Red, "DCPRTC");
				AddPlot(Brushes.Red, "DCPRBC");
				AddPlot(Brushes.DeepSkyBlue, "DCPRPP");
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
			if (CurrentBar < 2)
				return;
			
			if (Bars.IsFirstBarOfSession)
			{
				hh = High[0];
				ll = Low[0];
			}
			
			hh = High[0]>hh ? High[0] : hh;
			ll = Low[0]<ll ? Low[0] : ll;
			
			
			vPP = (hh+ll+Close[0])/3;
			vBC = (hh + ll )/2;
			vTC = (vPP - vBC)+vPP;
			
			DCPRTC[0] = vTC;
			DCPRBC[0] = vBC;
			DCPRPP[0] = vPP;
			

			
			
		}
		
	

		#region Properties

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> DCPRTC
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> DCPRBC
		{
			get { return Values[1]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> DCPRPP
		{
			get { return Values[2]; }
		}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HFCSimpleDCPR[] cacheHFCSimpleDCPR;
		public HFCSimpleDCPR HFCSimpleDCPR()
		{
			return HFCSimpleDCPR(Input);
		}

		public HFCSimpleDCPR HFCSimpleDCPR(ISeries<double> input)
		{
			if (cacheHFCSimpleDCPR != null)
				for (int idx = 0; idx < cacheHFCSimpleDCPR.Length; idx++)
					if (cacheHFCSimpleDCPR[idx] != null &&  cacheHFCSimpleDCPR[idx].EqualsInput(input))
						return cacheHFCSimpleDCPR[idx];
			return CacheIndicator<HFCSimpleDCPR>(new HFCSimpleDCPR(), input, ref cacheHFCSimpleDCPR);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HFCSimpleDCPR HFCSimpleDCPR()
		{
			return indicator.HFCSimpleDCPR(Input);
		}

		public Indicators.HFCSimpleDCPR HFCSimpleDCPR(ISeries<double> input )
		{
			return indicator.HFCSimpleDCPR(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HFCSimpleDCPR HFCSimpleDCPR()
		{
			return indicator.HFCSimpleDCPR(Input);
		}

		public Indicators.HFCSimpleDCPR HFCSimpleDCPR(ISeries<double> input )
		{
			return indicator.HFCSimpleDCPR(input);
		}
	}
}

#endregion
