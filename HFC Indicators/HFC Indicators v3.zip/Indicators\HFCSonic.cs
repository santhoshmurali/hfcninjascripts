#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class HFCSonic : Indicator
	{
		private HFCSMMA mySMMA;
		private HeikenAshi8 myHeikenAshi8;
		private bool enterShort = true;
		private bool enterLong = true;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"This is HeikenAshi and SMMA based indicator. Ruls for trigger are as follows. For Calls, previous HeikenAshi should have crossed above 9 SMMA (9 is configurable) and current candle should open in green, then enter. Rule 2, if Previous HA candle is red and current is green and above 9 Smma. Excatly opposite is for Put";
				Name										= "HFCSonic";
				Calculate									= Calculate.OnEachTick;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				SMMAPeriod					= 9;
				AddPlot(Brushes.Chocolate, "SonicEntry");
			}
			else if (State == State.Configure)
			{
				mySMMA = HFCSMMA(HeikenAshi8(Input).HAOpen,SMMAPeriod);
				myHeikenAshi8 = HeikenAshi8();
				enterShort = true;
				enterLong = true;
			}
			else if (State == State.DataLoaded)
			{
				
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
			if(CurrentBar<2)
				return;
			string cossed = "";
			string varenter = "";
			
			// Entering Short
			if (mySMMA[0] < myHeikenAshi8.HAOpen[1] && mySMMA[0] > myHeikenAshi8.HAClose[1])
			{
				cossed = "Below";
				
				if(myHeikenAshi8.HAHigh[0]<mySMMA[0] && enterShort == true)
				{
					enterShort = false;
					enterLong = true;
					varenter = "ShortEntered";
				}
				
			}
			
			//Entering long
			if (mySMMA[0] > myHeikenAshi8.HAOpen[1] && mySMMA[0] < myHeikenAshi8.HAClose[1])
			{
				cossed = "Above";
				
				if(myHeikenAshi8.HALow[0]>mySMMA[0] && enterLong == true)
				{
					enterLong = false;
					enterShort = true;
					varenter = "LongEntered";
				}
				
			}
			
			
			
			Print("Time :" + Time[0].ToString() +"     HAopen " + myHeikenAshi8.HAOpen[1].ToString() + ": SMMA " + mySMMA[0].ToString() + "  -->" + cossed + "  --> " + varenter);
			varenter = "";
			
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="SMMAPeriod", Order=1, GroupName="Parameters")]
		public int SMMAPeriod
		{ get; set; }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> SonicEntry
		{
			get { return Values[0]; }
		}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HFCSonic[] cacheHFCSonic;
		public HFCSonic HFCSonic(int sMMAPeriod)
		{
			return HFCSonic(Input, sMMAPeriod);
		}

		public HFCSonic HFCSonic(ISeries<double> input, int sMMAPeriod)
		{
			if (cacheHFCSonic != null)
				for (int idx = 0; idx < cacheHFCSonic.Length; idx++)
					if (cacheHFCSonic[idx] != null && cacheHFCSonic[idx].SMMAPeriod == sMMAPeriod && cacheHFCSonic[idx].EqualsInput(input))
						return cacheHFCSonic[idx];
			return CacheIndicator<HFCSonic>(new HFCSonic(){ SMMAPeriod = sMMAPeriod }, input, ref cacheHFCSonic);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HFCSonic HFCSonic(int sMMAPeriod)
		{
			return indicator.HFCSonic(Input, sMMAPeriod);
		}

		public Indicators.HFCSonic HFCSonic(ISeries<double> input , int sMMAPeriod)
		{
			return indicator.HFCSonic(input, sMMAPeriod);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HFCSonic HFCSonic(int sMMAPeriod)
		{
			return indicator.HFCSonic(Input, sMMAPeriod);
		}

		public Indicators.HFCSonic HFCSonic(ISeries<double> input , int sMMAPeriod)
		{
			return indicator.HFCSonic(input, sMMAPeriod);
		}
	}
}

#endregion
