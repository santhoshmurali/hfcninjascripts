#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.HFCTradingSystem
{
	public class HFCNextDayPivotsInfo : Indicator
	{
		private double vPP,vTC,vBC;
		private double hh,ll,cc;
		private double CPRSqueeze,R1,R2,R3,R4,S1,S2,S3,S4;
		
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"This will display next day Pivots";
				Name										= "HFCNextDayPivotsInfo";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
			
			if (CurrentBar < 2)
				return;
			
			if (Bars.IsFirstBarOfSession)
			{
				hh = High[0];
				ll = Low[0];
			}
			
			hh = High[0]>hh ? High[0] : hh;
			ll = Low[0]<ll ? Low[0] : ll;
			
			
			vPP = (hh+ll+Close[0])/3;
			vBC = (hh + ll )/2;
			vTC = (vPP - vBC)+vPP;
			
			CPRSqueeze = Math.Round((Math.Abs(vTC - vBC)/vPP)*100,2);
			
			
			S1 = Math.Round(2 * vPP - hh,2);
			S1 = Math.Round(S1) - Math.Round(S1,1)>0?Math.Round(S1,1)+.05:Math.Round(S1,1);
			R1 = Math.Round(2 * vPP - ll,2);		
			R1 = Math.Round(R1) - Math.Round(R1,1)>0?Math.Round(R1,1)+.05:Math.Round(R1,1);
			
			//S2 = pp-(h-l)	
			S2 = Math.Round(vPP - (hh - ll),2);
			S2 = Math.Round(S2) - Math.Round(S2,1)>0?Math.Round(S2,1)+.05:Math.Round(S2,1);
			
			//R2 = pp + (h-l)
			R2 = Math.Round(vPP + (hh - ll),2);
			R2 = Math.Round(R2) - Math.Round(R2,1)>0?Math.Round(R2,1)+.05:Math.Round(R2,1);
			
			//S3 = S1 - (h - l)
			S3 = Math.Round(S1 - (hh - ll),2);	
			S3 = Math.Round(S3) - Math.Round(S3,1)>0?Math.Round(S3,1)+.05:Math.Round(S3,1);
			
			//R3 = 	R1 + (h - l)
			R3 = Math.Round(R1 + (hh - ll),2);
			R3 = Math.Round(R3) - Math.Round(R3,1)>0?Math.Round(R3,1)+.05:Math.Round(R3,1);
			
			//S4 = S3 - (S1 - S2)
			S4 = Math.Round(S3 - (S1 - S2),2);	
			S4 = Math.Round(S4) - Math.Round(S4,1)>0?Math.Round(S4,1)+.05:Math.Round(S4,1);
				
			//R4 = 	R3 + (r2 - r1)
			R4 = R3 + (R2 - R1);
			R4 = Math.Round(R4) - Math.Round(R4,1)>0?Math.Round(R4,1)+.05:Math.Round(R4,1);
		}
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
				// This sample should be used along side the help guide educational resource on this topic:
				// http://www.ninjatrader.com/support/helpGuides/nt8/en-us/?using_sharpdx_for_custom_chart_rendering.htm

				// Default plotting in base class. Uncomment if indicators holds at least one plot
				// in this case we would expect NOT to see the SMA plot we have as well in this sample script
				//base.OnRender(chartControl, chartScale);
					
				// define the point for the text to render
				SharpDX.Vector2 startPoint1 = new SharpDX.Vector2(ChartPanel.X + 500, ChartPanel.Y+ChartPanel.H - 30);	
				SharpDX.Vector2 startPoint2 = new SharpDX.Vector2(ChartPanel.X + 920, ChartPanel.Y+ChartPanel.H - 30);
				SharpDX.Vector2 startPoint3 = new SharpDX.Vector2(ChartPanel.X + 780, ChartPanel.Y+ChartPanel.H - 30);

				
				// construct the text format with desired font family and size
				SharpDX.DirectWrite.TextFormat textFormat1 = new SharpDX.DirectWrite.TextFormat(Core.Globals.DirectWriteFactory, "Arial", 10);
				
					
				// construct the text layout with desired text, text format, max width and height
				SharpDX.DirectWrite.TextLayout textLayout1 = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, "R4 - " + R4.ToString() + " | R3 - "+R3.ToString() + " | R2 - "+R2.ToString() + " | R1 - " + R1.ToString(), textFormat1, ChartPanel.W, ChartPanel.H);
				SharpDX.DirectWrite.TextLayout textLayout2 = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, "S4 - " + S4.ToString() + " | S3 - "+S3.ToString() + " | S2 - "+S2.ToString() + " | S1 - " + S1.ToString(), textFormat1, ChartPanel.W, ChartPanel.H);
				SharpDX.DirectWrite.TextLayout textLayout3 = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, "CPR Spread % = " + CPRSqueeze.ToString() + " %", textFormat1, ChartPanel.W, ChartPanel.H);
				
				
				
				// create a rectangle which will automatically resize to the width/height of the textLayout
				SharpDX.RectangleF rectangleF1 = new SharpDX.RectangleF(startPoint1.X-5, startPoint1.Y-5,	(textLayout1.Metrics.Width)+10, (textLayout1.Metrics.Height)+10);		
				SharpDX.RectangleF rectangleF2 = new SharpDX.RectangleF(startPoint2.X-5, startPoint2.Y-5,	(textLayout2.Metrics.Width)+10, (textLayout2.Metrics.Height)+10);		
				SharpDX.RectangleF rectangleF3 = new SharpDX.RectangleF(startPoint3.X-5, startPoint3.Y-5,	(textLayout3.Metrics.Width)+10, (textLayout3.Metrics.Height)+10);		
				
					
					
				// define the brush used for the text and rectangle
				SharpDX.Direct2D1.SolidColorBrush customDXBrush = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, SharpDX.Color.DarkBlue);
				customDXBrush.Opacity = 0.6f;
			
				SharpDX.Direct2D1.SolidColorBrush customDXBrushWhite = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, SharpDX.Color.White);
						
				
				// Rectacngle  Background	
				SharpDX.Direct2D1.SolidColorBrush areaBrushDx1 = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, SharpDX.Color.PeachPuff);						
					areaBrushDx1.Opacity = 0.4f;
				
				SharpDX.Direct2D1.SolidColorBrush areaBrushDx2 = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, SharpDX.Color.DodgerBlue);						
					areaBrushDx2.Opacity = 0.4f;
			
				SharpDX.Direct2D1.SolidColorBrush areaBrushDx3 = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, SharpDX.Color.Black);						
					areaBrushDx3.Opacity = 0.6f;
				
				RenderTarget.DrawRectangle(rectangleF1, customDXBrush);
				RenderTarget.FillRectangle(rectangleF1, areaBrushDx1);
			
				RenderTarget.DrawRectangle(rectangleF2, customDXBrush);
				RenderTarget.FillRectangle(rectangleF2, areaBrushDx2);
			
				RenderTarget.DrawRectangle(rectangleF3, customDXBrushWhite);
				RenderTarget.FillRectangle(rectangleF3, areaBrushDx3);
					

					
				// execute the render target text layout command with desired values
				RenderTarget.DrawTextLayout(startPoint1, textLayout1, customDXBrush);
				RenderTarget.DrawTextLayout(startPoint2, textLayout2, customDXBrush);
				RenderTarget.DrawTextLayout(startPoint3, textLayout3, customDXBrushWhite);
		
				 

				// always dispose of textLayout, textFormat, or brush when finished
				textLayout1.Dispose();
				textLayout2.Dispose();
				textLayout3.Dispose();
				areaBrushDx1.Dispose();
				areaBrushDx2.Dispose();
				areaBrushDx3.Dispose();
				customDXBrush.Dispose();
				customDXBrushWhite.Dispose();
				
			
		}			
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HFCTradingSystem.HFCNextDayPivotsInfo[] cacheHFCNextDayPivotsInfo;
		public HFCTradingSystem.HFCNextDayPivotsInfo HFCNextDayPivotsInfo()
		{
			return HFCNextDayPivotsInfo(Input);
		}

		public HFCTradingSystem.HFCNextDayPivotsInfo HFCNextDayPivotsInfo(ISeries<double> input)
		{
			if (cacheHFCNextDayPivotsInfo != null)
				for (int idx = 0; idx < cacheHFCNextDayPivotsInfo.Length; idx++)
					if (cacheHFCNextDayPivotsInfo[idx] != null &&  cacheHFCNextDayPivotsInfo[idx].EqualsInput(input))
						return cacheHFCNextDayPivotsInfo[idx];
			return CacheIndicator<HFCTradingSystem.HFCNextDayPivotsInfo>(new HFCTradingSystem.HFCNextDayPivotsInfo(), input, ref cacheHFCNextDayPivotsInfo);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HFCTradingSystem.HFCNextDayPivotsInfo HFCNextDayPivotsInfo()
		{
			return indicator.HFCNextDayPivotsInfo(Input);
		}

		public Indicators.HFCTradingSystem.HFCNextDayPivotsInfo HFCNextDayPivotsInfo(ISeries<double> input )
		{
			return indicator.HFCNextDayPivotsInfo(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HFCTradingSystem.HFCNextDayPivotsInfo HFCNextDayPivotsInfo()
		{
			return indicator.HFCNextDayPivotsInfo(Input);
		}

		public Indicators.HFCTradingSystem.HFCNextDayPivotsInfo HFCNextDayPivotsInfo(ISeries<double> input )
		{
			return indicator.HFCNextDayPivotsInfo(input);
		}
	}
}

#endregion
