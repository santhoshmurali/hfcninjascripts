#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it.
// This Belongs to Harvest FinCrop. 
// Version : 1.0
// Developed By : Santhosh Murali [ santhoshmurali@gmail.com ]
// For Support Contact : Santhosh Murali
// Description : Bollinger Bands Width serve as a way to quantitatively measure the width between the Upper and Lower Bands of Bollinger bands
namespace NinjaTrader.NinjaScript.Indicators
{
	public class HFCBollingerBandWidth : Indicator
	{
		
		private Series<double> BBUp, BBDown, BBMiddle, BBWidth;
		
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Harvest FinCorps Bollinger Band Width : Bollinger Bands Width serve as a way to quantitatively measure the width between the Upper and Lower Bands of Bollinger bands";
				Name										= "HFCBollingerBandWidth";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				LookBackRange					= 14;
				StandardDeviation					= 2;
				AddPlot(new Stroke(Brushes.Orange, 2), PlotStyle.Bar, "BBWidthBar");
			}
			else if (State == State.Configure)
			{
				BBUp = new Series<double>(this,MaximumBarsLookBack.Infinite);
				BBDown = new Series<double>(this,MaximumBarsLookBack.Infinite);
				BBMiddle = new Series<double>(this,MaximumBarsLookBack.Infinite);
				BBWidth = new Series<double>(this,MaximumBarsLookBack.Infinite);
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
			if(CurrentBar<=LookBackRange)
				return;
			BBUp[0] = Bollinger(StandardDeviation,LookBackRange).Upper[0];
			BBDown[0] = Bollinger(StandardDeviation,LookBackRange).Lower[0];
			BBMiddle[0] = Bollinger(StandardDeviation,LookBackRange).Middle[0];
			
			
			BBWidth[0] = (BBUp[0] - BBDown[0])/BBMiddle[0];
			
			BBWidthBar[0] = BBWidth[0];
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="LookBackRange", Description="Look Back for Average", Order=1, GroupName="Parameters")]
		public int LookBackRange
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="StandardDeviation", Description="standard deviation", Order=2, GroupName="Parameters")]
		public int StandardDeviation
		{ get; set; }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> BBWidthBar
		{
			get { return Values[0]; }
		}

		
	
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HFCBollingerBandWidth[] cacheHFCBollingerBandWidth;
		public HFCBollingerBandWidth HFCBollingerBandWidth(int lookBackRange, int standardDeviation)
		{
			return HFCBollingerBandWidth(Input, lookBackRange, standardDeviation);
		}

		public HFCBollingerBandWidth HFCBollingerBandWidth(ISeries<double> input, int lookBackRange, int standardDeviation)
		{
			if (cacheHFCBollingerBandWidth != null)
				for (int idx = 0; idx < cacheHFCBollingerBandWidth.Length; idx++)
					if (cacheHFCBollingerBandWidth[idx] != null && cacheHFCBollingerBandWidth[idx].LookBackRange == lookBackRange && cacheHFCBollingerBandWidth[idx].StandardDeviation == standardDeviation && cacheHFCBollingerBandWidth[idx].EqualsInput(input))
						return cacheHFCBollingerBandWidth[idx];
			return CacheIndicator<HFCBollingerBandWidth>(new HFCBollingerBandWidth(){ LookBackRange = lookBackRange, StandardDeviation = standardDeviation }, input, ref cacheHFCBollingerBandWidth);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HFCBollingerBandWidth HFCBollingerBandWidth(int lookBackRange, int standardDeviation)
		{
			return indicator.HFCBollingerBandWidth(Input, lookBackRange, standardDeviation);
		}

		public Indicators.HFCBollingerBandWidth HFCBollingerBandWidth(ISeries<double> input , int lookBackRange, int standardDeviation)
		{
			return indicator.HFCBollingerBandWidth(input, lookBackRange, standardDeviation);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HFCBollingerBandWidth HFCBollingerBandWidth(int lookBackRange, int standardDeviation)
		{
			return indicator.HFCBollingerBandWidth(Input, lookBackRange, standardDeviation);
		}

		public Indicators.HFCBollingerBandWidth HFCBollingerBandWidth(ISeries<double> input , int lookBackRange, int standardDeviation)
		{
			return indicator.HFCBollingerBandWidth(input, lookBackRange, standardDeviation);
		}
	}
}

#endregion
