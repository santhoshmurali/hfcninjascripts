#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class HFCDayOpenRange : Indicator
	{
		private SimpleFont errFont;
		private double DayOpenHigh=0;
		private double DayOpenLow=0;
		private string CurrentDate = "";
		private string PrevDate="";
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Used for Day Range Breakout Strategy";
				Name										= "HFCDayOpenRange";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				ConsiderNextCandle					= false;
				HColor = Brushes.YellowGreen;
				LColor = Brushes.Peru;
			}
			else if (State == State.Configure)
			{
				AddPlot(HColor,"DayOpenUpper");
				AddPlot(LColor,"DayOpenLower");
	
			}
			else if (State == State.DataLoaded)
			{
				errFont = new SimpleFont("Courier New", 12) { Size = 30, Bold = true };
				if (BarsPeriod.BarsPeriodType != BarsPeriodType.Minute)
				{
					Draw.TextFixed(this,"Error","Error : Select Minute Period Type for Daily Open Range Plots to Work!",TextPosition.BottomLeft,Brushes.Red,errFont,Brushes.Red,Brushes.Yellow,60);
					return;
				}
 			}
		}

		protected override void OnBarUpdate()
		{
			if (CurrentBar<2)
				return;
			//Add your custom indicator logic here.
			PrevDate =  Time[1].ToString("MM-dd-yyyy").Substring(0,10);
			CurrentDate =  Time[0].ToString("MM-dd-yyyy").Substring(0,10);
			if ((PrevDate != CurrentDate) && (BarsPeriod.BarsPeriodType == BarsPeriodType.Minute))
			{
				DayOpenHigh = High[0];
				DayOpenLow = Low[0];
				
			}
			DayOpenUpper[0] = DayOpenHigh;
			DayOpenLower[0] = DayOpenLow;
		}

		#region Properties
		[NinjaScriptProperty]
		[Display(Name="ConsiderNextCandle", Order=1, GroupName="Parameters")]
		public bool ConsiderNextCandle
		{ get; set; }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> DayOpenUpper
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> DayOpenLower
		{
			get { return Values[1]; }
		}
		
		
		//Color set-up
	    [NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="Day open Candle High", Order=1, GroupName="Color Set-Up")]
		public Brush HColor
		{ get; set; }

		[Browsable(false)]
		public string HColorSerializable
		{
			get { return Serialize.BrushToString(HColor); }
			set { HColor = Serialize.StringToBrush(value); }
		}
		
		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="Day open Candle Low", Order=2, GroupName="Color Set-Up")]
		public Brush LColor
		{ get; set; }

		[Browsable(false)]
		public string LColorSerializable
		{
			get { return Serialize.BrushToString(LColor); }
			set { LColor = Serialize.StringToBrush(value); }
		}
		
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HFCDayOpenRange[] cacheHFCDayOpenRange;
		public HFCDayOpenRange HFCDayOpenRange(bool considerNextCandle, Brush hColor, Brush lColor)
		{
			return HFCDayOpenRange(Input, considerNextCandle, hColor, lColor);
		}

		public HFCDayOpenRange HFCDayOpenRange(ISeries<double> input, bool considerNextCandle, Brush hColor, Brush lColor)
		{
			if (cacheHFCDayOpenRange != null)
				for (int idx = 0; idx < cacheHFCDayOpenRange.Length; idx++)
					if (cacheHFCDayOpenRange[idx] != null && cacheHFCDayOpenRange[idx].ConsiderNextCandle == considerNextCandle && cacheHFCDayOpenRange[idx].HColor == hColor && cacheHFCDayOpenRange[idx].LColor == lColor && cacheHFCDayOpenRange[idx].EqualsInput(input))
						return cacheHFCDayOpenRange[idx];
			return CacheIndicator<HFCDayOpenRange>(new HFCDayOpenRange(){ ConsiderNextCandle = considerNextCandle, HColor = hColor, LColor = lColor }, input, ref cacheHFCDayOpenRange);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HFCDayOpenRange HFCDayOpenRange(bool considerNextCandle, Brush hColor, Brush lColor)
		{
			return indicator.HFCDayOpenRange(Input, considerNextCandle, hColor, lColor);
		}

		public Indicators.HFCDayOpenRange HFCDayOpenRange(ISeries<double> input , bool considerNextCandle, Brush hColor, Brush lColor)
		{
			return indicator.HFCDayOpenRange(input, considerNextCandle, hColor, lColor);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HFCDayOpenRange HFCDayOpenRange(bool considerNextCandle, Brush hColor, Brush lColor)
		{
			return indicator.HFCDayOpenRange(Input, considerNextCandle, hColor, lColor);
		}

		public Indicators.HFCDayOpenRange HFCDayOpenRange(ISeries<double> input , bool considerNextCandle, Brush hColor, Brush lColor)
		{
			return indicator.HFCDayOpenRange(input, considerNextCandle, hColor, lColor);
		}
	}
}

#endregion
