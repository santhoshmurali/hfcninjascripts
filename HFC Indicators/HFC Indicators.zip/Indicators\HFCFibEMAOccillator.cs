#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class HFCFibEMAOccillator : Indicator
	{
		private HFCFibMoivingAverage myHFCFibMoivingAverage;
		
		
		private double varFibOccilator ;
		private double varDibOccilatorDenom;
		private double varRealFactor;
		
		private double FIBMAOccilator; // if you need a plot deactivate and uncomment addplot and use that in code instead.
		
		private double Nume;
		private double Denom;
		private Brush UpColor = Brushes.Green;
		private Brush UpColorOL = Brushes.DarkGreen;
		private Brush DownColor = Brushes.Red;
		private Brush DownColorOL = Brushes.DarkRed;
		private Brush NoTrendColor = Brushes.Gray;
		private bool UpTrend = false;
		private bool DownTrend = false;
		private bool NoTrend = false;
		
		private double vPut = 0;
		private double vCall = 0;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Harvest FinCrop Propritery Indicator : This Gives if Market is flat or trneding";
				Name										= "HFCFibEMAOccillator";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				Threshold					= 0.95;
				//AddPlot(Brushes.Turquoise, "FIBMAOccilator");
				
				vMultiplier = 50;
	
			}
			else if (State == State.Configure)
			{
				myHFCFibMoivingAverage = HFCFibMoivingAverage();
				
				
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
			if (CurrentBar < 2)
				return;
			vPut = Close[0] - (Close[0]%vMultiplier);
			vCall = vPut + vMultiplier;
			
			Nume = Math.Min(myHFCFibMoivingAverage.MA38[0],myHFCFibMoivingAverage.MA9[0]);
			Denom = Math.Max(myHFCFibMoivingAverage.MA38[0],myHFCFibMoivingAverage.MA9[0]);
			
			//varDibOccilatorDenom = Math.Abs((myHFCFibMoivingAverage.MA62[0])-(myHFCFibMoivingAverage.MA9[0])) < 1 ? 1 : Math.Abs((myHFCFibMoivingAverage.MA62[0])-(myHFCFibMoivingAverage.MA9[0]));
			//varFibOccilator = 1.0/varDibOccilatorDenom;
			
			varRealFactor = Convert.ToDouble(((Nume/Denom)*100))-(Math.Truncate(((Nume/Denom)*100)));
			Print(vPut);
			
			//FIBMAOccilator[0] = varRealFactor;
			FIBMAOccilator = varRealFactor;
			
			
			if (FIBMAOccilator >= Threshold )
			{
				NoTrend = true;
				DownTrend = false;
				UpTrend = false;
			}
			else if  (FIBMAOccilator < Threshold && (myHFCFibMoivingAverage.MA38[0] <= myHFCFibMoivingAverage.MA38[1] ))
			{
				NoTrend = false;
				DownTrend = true;
				UpTrend = false;
			}
			else if  (FIBMAOccilator <= Threshold && (myHFCFibMoivingAverage.MA38[0] > myHFCFibMoivingAverage.MA38[1] ))
			{
				NoTrend = false;
				DownTrend = false;
				UpTrend = true;
			}
			
			if (NoTrend)
			{
				BarBrushes[0] = NoTrendColor;
				Draw.TextFixed(this,"Options","Just Wait for the opportunity",TextPosition.BottomLeft);
				Draw.Text(this,"OptionRealTime","Waiting... ",-5,Low[0],Brushes.Gray);
			}
			if (UpTrend)
			{
				BarBrushes[0] = UpColor;
				CandleOutlineBrushes[0] = UpColorOL;
				Draw.TextFixed(this,"Options","Buy Call Option - Strike Price --> "+vCall.ToString(),TextPosition.BottomLeft);
				Draw.Text(this,"OptionRealTime","Buy Call @ "+vCall.ToString(),-5,High[0],Brushes.Green);
			}
			if (DownTrend)
			{
				BarBrushes[0] = DownColor;
				CandleOutlineBrushes[0] = DownColorOL;
				Draw.TextFixed(this,"Options","Buy Put Option - Strike Price --> "+vPut.ToString(),TextPosition.BottomLeft);
				Draw.Text(this,"OptionRealTime","Buy Put @ "+vPut.ToString(),-5,Low[0],Brushes.Red);
			}
			
				
			
			
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(0.01, double.MaxValue)]
		[Display(Name="Threshold", Order=1, GroupName="Parameters")]
		public double Threshold
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Strike Price Multiplier", Order=2, GroupName="Parameters")]
		public int vMultiplier
		{ get; set; }		

		
		/*[Browsable(false)]
		[XmlIgnore]
		public Series<double> FIBMAOccilator
		{
			get { return Values[0]; }
		}*/
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HFCFibEMAOccillator[] cacheHFCFibEMAOccillator;
		public HFCFibEMAOccillator HFCFibEMAOccillator(double threshold, int vMultiplier)
		{
			return HFCFibEMAOccillator(Input, threshold, vMultiplier);
		}

		public HFCFibEMAOccillator HFCFibEMAOccillator(ISeries<double> input, double threshold, int vMultiplier)
		{
			if (cacheHFCFibEMAOccillator != null)
				for (int idx = 0; idx < cacheHFCFibEMAOccillator.Length; idx++)
					if (cacheHFCFibEMAOccillator[idx] != null && cacheHFCFibEMAOccillator[idx].Threshold == threshold && cacheHFCFibEMAOccillator[idx].vMultiplier == vMultiplier && cacheHFCFibEMAOccillator[idx].EqualsInput(input))
						return cacheHFCFibEMAOccillator[idx];
			return CacheIndicator<HFCFibEMAOccillator>(new HFCFibEMAOccillator(){ Threshold = threshold, vMultiplier = vMultiplier }, input, ref cacheHFCFibEMAOccillator);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HFCFibEMAOccillator HFCFibEMAOccillator(double threshold, int vMultiplier)
		{
			return indicator.HFCFibEMAOccillator(Input, threshold, vMultiplier);
		}

		public Indicators.HFCFibEMAOccillator HFCFibEMAOccillator(ISeries<double> input , double threshold, int vMultiplier)
		{
			return indicator.HFCFibEMAOccillator(input, threshold, vMultiplier);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HFCFibEMAOccillator HFCFibEMAOccillator(double threshold, int vMultiplier)
		{
			return indicator.HFCFibEMAOccillator(Input, threshold, vMultiplier);
		}

		public Indicators.HFCFibEMAOccillator HFCFibEMAOccillator(ISeries<double> input , double threshold, int vMultiplier)
		{
			return indicator.HFCFibEMAOccillator(input, threshold, vMultiplier);
		}
	}
}

#endregion
