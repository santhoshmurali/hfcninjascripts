#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
// This Belongs to Harvest FinCrop. 
// Version : 1.0
// Developed By : Santhosh Murali [ santhoshmurali@gmail.com ]
// For Support Contact : Santhosh Murali
// Description : This Plots EMA based on Ronded Fibbonaci Numbers 62,38,24,15 & 9. We can use it as crossover indicator for Entry and Exit.
namespace NinjaTrader.NinjaScript.Indicators
{
	public class HFCFibMoivingAverage : Indicator
	{
		private EMA myEMA62;
		private EMA myEMA38;
		private EMA myEMA24;
		private EMA myEMA15;
		private EMA myEMA9;
		//private EMA myEMASum;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Harvest FinCrop's Propritery Indicator : This Plots EMA based on Ronded Fibbonaci Numbers 62,38,24,15 & 9. We can use it as crossover indicator for Entry and Exit.";
				Name										= "HFCFibMoivingAverage";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				AddPlot(Brushes.Crimson, "MA62");
				AddPlot(Brushes.DarkOrange, "MA38");
				AddPlot(Brushes.MediumTurquoise, "MA24");
				AddPlot(Brushes.GreenYellow, "MA15");
				AddPlot(Brushes.Yellow, "MA9");
				AddPlot(new Stroke(Brushes.Lime, 1), PlotStyle.Dot, "MAFibAvg");
			}
			else if (State == State.Configure)
			{
				myEMA62 = EMA(Input,62);
				myEMA38 = EMA(Input,38);
				myEMA24 = EMA(Input,24);
				myEMA15 = EMA(Input,15);
				myEMA9 = EMA(Input,9);
				//myEMASum = EMA(Input,148);
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
			if(CurrentBar < 2)
				return;
			MA62[0] = myEMA62[0];
			MA38[0] = myEMA38[0];
			MA24[0] = myEMA24[0];
			MA15[0] = myEMA15[0];
			MA9[0] = myEMA9[0];
			MAFibAvg[0] = (MA62[0]+MA38[0]+MA24[0]+MA15[0]+MA9[0])/5;
		}

		#region Properties

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> MA62
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> MA38
		{
			get { return Values[1]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> MA24
		{
			get { return Values[2]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> MA15
		{
			get { return Values[3]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> MA9
		{
			get { return Values[4]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> MAFibAvg
		{
			get { return Values[5]; }
		}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HFCFibMoivingAverage[] cacheHFCFibMoivingAverage;
		public HFCFibMoivingAverage HFCFibMoivingAverage()
		{
			return HFCFibMoivingAverage(Input);
		}

		public HFCFibMoivingAverage HFCFibMoivingAverage(ISeries<double> input)
		{
			if (cacheHFCFibMoivingAverage != null)
				for (int idx = 0; idx < cacheHFCFibMoivingAverage.Length; idx++)
					if (cacheHFCFibMoivingAverage[idx] != null &&  cacheHFCFibMoivingAverage[idx].EqualsInput(input))
						return cacheHFCFibMoivingAverage[idx];
			return CacheIndicator<HFCFibMoivingAverage>(new HFCFibMoivingAverage(), input, ref cacheHFCFibMoivingAverage);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HFCFibMoivingAverage HFCFibMoivingAverage()
		{
			return indicator.HFCFibMoivingAverage(Input);
		}

		public Indicators.HFCFibMoivingAverage HFCFibMoivingAverage(ISeries<double> input )
		{
			return indicator.HFCFibMoivingAverage(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HFCFibMoivingAverage HFCFibMoivingAverage()
		{
			return indicator.HFCFibMoivingAverage(Input);
		}

		public Indicators.HFCFibMoivingAverage HFCFibMoivingAverage(ISeries<double> input )
		{
			return indicator.HFCFibMoivingAverage(input);
		}
	}
}

#endregion
