#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class HFCMAHighLowIndex : Indicator
	{
		private SMA mySMAHigh;
		private SMA mySMALow;
		
		private double MAIndexVal;
			
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"This Shrinks the MovingAverage of High and Low with in 0 and 1";
				Name										= "HFCMAHighLowIndex";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				Length					= 14;
				MAIndexVal				= 0.0;
				
				AddPlot(Brushes.Chartreuse, "MAIndex");
			}
			else if (State == State.Configure)
			{
				mySMAHigh = SMA(High,Length);
				mySMALow = SMA(Low,Length);
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
			if (CurrentBar<Length)
				return;
			MAIndexVal = 1-(1/(mySMAHigh[0]-mySMALow[0]));
			MAIndex[Length] = MAIndexVal;
			
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(2, int.MaxValue)]
		[Display(Name="Length", Order=1, GroupName="Parameters")]
		public int Length
		{ get; set; }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> MAIndex
		{
			get { return Values[0]; }
		}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HFCMAHighLowIndex[] cacheHFCMAHighLowIndex;
		public HFCMAHighLowIndex HFCMAHighLowIndex(int length)
		{
			return HFCMAHighLowIndex(Input, length);
		}

		public HFCMAHighLowIndex HFCMAHighLowIndex(ISeries<double> input, int length)
		{
			if (cacheHFCMAHighLowIndex != null)
				for (int idx = 0; idx < cacheHFCMAHighLowIndex.Length; idx++)
					if (cacheHFCMAHighLowIndex[idx] != null && cacheHFCMAHighLowIndex[idx].Length == length && cacheHFCMAHighLowIndex[idx].EqualsInput(input))
						return cacheHFCMAHighLowIndex[idx];
			return CacheIndicator<HFCMAHighLowIndex>(new HFCMAHighLowIndex(){ Length = length }, input, ref cacheHFCMAHighLowIndex);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HFCMAHighLowIndex HFCMAHighLowIndex(int length)
		{
			return indicator.HFCMAHighLowIndex(Input, length);
		}

		public Indicators.HFCMAHighLowIndex HFCMAHighLowIndex(ISeries<double> input , int length)
		{
			return indicator.HFCMAHighLowIndex(input, length);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HFCMAHighLowIndex HFCMAHighLowIndex(int length)
		{
			return indicator.HFCMAHighLowIndex(Input, length);
		}

		public Indicators.HFCMAHighLowIndex HFCMAHighLowIndex(ISeries<double> input , int length)
		{
			return indicator.HFCMAHighLowIndex(input, length);
		}
	}
}

#endregion
