#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class HFCRangeFinder : Indicator
	{
		private MAX myMaxHigh;
		private MIN myMinLow;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Diffrences between Previous Highs for Short and Lows for Long";
				Name										= "HFCRangeFinder";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				Length					= 14;
				AddPlot(Brushes.MediumSpringGreen, "RangePlotHigh");
				AddPlot(Brushes.Orange, "RangePlotLow");
			}
			else if (State == State.Configure)
			{
				myMaxHigh = MAX(High,Length);
				myMinLow = MIN(Low,Length);
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
			if (CurrentBar < 3)
			{
				
			}
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Length", Order=1, GroupName="Parameters")]
		public int Length
		{ get; set; }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> RangePlotHigh
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> RangePlotLow
		{
			get { return Values[1]; }
		}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HFCRangeFinder[] cacheHFCRangeFinder;
		public HFCRangeFinder HFCRangeFinder(int length)
		{
			return HFCRangeFinder(Input, length);
		}

		public HFCRangeFinder HFCRangeFinder(ISeries<double> input, int length)
		{
			if (cacheHFCRangeFinder != null)
				for (int idx = 0; idx < cacheHFCRangeFinder.Length; idx++)
					if (cacheHFCRangeFinder[idx] != null && cacheHFCRangeFinder[idx].Length == length && cacheHFCRangeFinder[idx].EqualsInput(input))
						return cacheHFCRangeFinder[idx];
			return CacheIndicator<HFCRangeFinder>(new HFCRangeFinder(){ Length = length }, input, ref cacheHFCRangeFinder);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HFCRangeFinder HFCRangeFinder(int length)
		{
			return indicator.HFCRangeFinder(Input, length);
		}

		public Indicators.HFCRangeFinder HFCRangeFinder(ISeries<double> input , int length)
		{
			return indicator.HFCRangeFinder(input, length);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HFCRangeFinder HFCRangeFinder(int length)
		{
			return indicator.HFCRangeFinder(Input, length);
		}

		public Indicators.HFCRangeFinder HFCRangeFinder(ISeries<double> input , int length)
		{
			return indicator.HFCRangeFinder(input, length);
		}
	}
}

#endregion
