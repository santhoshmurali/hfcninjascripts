#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
// This Belongs to Harvest FinCrop. 
// Version : 1.0
// Module : VSA
// Developed By : Santhosh Murali [ santhoshmurali@gmail.com ]
// For Support Contact : Santhosh Murali
// Description : This calculate the intensity of the current volume w.r.t average of historical volume. We will be able to set a Threshold through which we can filter higher volume candles.
// Date Developed : 13-05-2020


namespace NinjaTrader.NinjaScript.Indicators
{
	public class HFCRelativeVolumeIndicator : Indicator
	{
		private VOLMA myVOLMA;
		private VolumeUpDown myVolumeUpDown;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Current volume/(average volume)";
				Name										= "HFCRelativeVolumeIndicator";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				VarVolMA					= 20;
				varThreshold				= 1;
				ShowLowVol	= true;
				AddPlot(new Stroke(Brushes.SeaGreen, 2), PlotStyle.Bar, "PltRelVolUp");
				AddPlot(new Stroke(Brushes.Firebrick, 2), PlotStyle.Bar, "PltRelVolDown");
			}
			else if (State == State.Configure)
			{
				
			}
			else if (State == State.DataLoaded)
			{
				myVOLMA = VOLMA(VarVolMA);
				myVolumeUpDown = VolumeUpDown();
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
			
			if (CurrentBar < 2)
				return;
			double relVOl = Volume[0]/myVOLMA[0];
			if (relVOl>=varThreshold)
			{
				if (myVolumeUpDown.UpVolume[0]>0)
				{
					PltRelVolUp[0] = relVOl;
					
				}
				else
				{
					
					PltRelVolDown[0] = relVOl;
				}
			}
			else if (ShowLowVol)
			{
				if (myVolumeUpDown.UpVolume[0]>0)
					{
						PltRelVolUp[0] = -1*relVOl;
					}
					else
					{
						PltRelVolDown[0] = -1*relVOl;
					}
			}
				
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="VarVolMA", Order=1, GroupName="Parameters")]
		public int VarVolMA
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(0.01, double.MaxValue)]
		[Display(Name="Threshold", Order=1, GroupName="Parameters")]
		public double varThreshold
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="Show Low Volume", Order=2, GroupName="Parameters")]
		public bool ShowLowVol
		{ get; set; }


		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PltRelVolUp
		{
			get { return Values[0]; }
		}
		
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PltRelVolDown
		{
			get { return Values[1]; }
		}		
		
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HFCRelativeVolumeIndicator[] cacheHFCRelativeVolumeIndicator;
		public HFCRelativeVolumeIndicator HFCRelativeVolumeIndicator(int varVolMA, double varThreshold, bool showLowVol)
		{
			return HFCRelativeVolumeIndicator(Input, varVolMA, varThreshold, showLowVol);
		}

		public HFCRelativeVolumeIndicator HFCRelativeVolumeIndicator(ISeries<double> input, int varVolMA, double varThreshold, bool showLowVol)
		{
			if (cacheHFCRelativeVolumeIndicator != null)
				for (int idx = 0; idx < cacheHFCRelativeVolumeIndicator.Length; idx++)
					if (cacheHFCRelativeVolumeIndicator[idx] != null && cacheHFCRelativeVolumeIndicator[idx].VarVolMA == varVolMA && cacheHFCRelativeVolumeIndicator[idx].varThreshold == varThreshold && cacheHFCRelativeVolumeIndicator[idx].ShowLowVol == showLowVol && cacheHFCRelativeVolumeIndicator[idx].EqualsInput(input))
						return cacheHFCRelativeVolumeIndicator[idx];
			return CacheIndicator<HFCRelativeVolumeIndicator>(new HFCRelativeVolumeIndicator(){ VarVolMA = varVolMA, varThreshold = varThreshold, ShowLowVol = showLowVol }, input, ref cacheHFCRelativeVolumeIndicator);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HFCRelativeVolumeIndicator HFCRelativeVolumeIndicator(int varVolMA, double varThreshold, bool showLowVol)
		{
			return indicator.HFCRelativeVolumeIndicator(Input, varVolMA, varThreshold, showLowVol);
		}

		public Indicators.HFCRelativeVolumeIndicator HFCRelativeVolumeIndicator(ISeries<double> input , int varVolMA, double varThreshold, bool showLowVol)
		{
			return indicator.HFCRelativeVolumeIndicator(input, varVolMA, varThreshold, showLowVol);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HFCRelativeVolumeIndicator HFCRelativeVolumeIndicator(int varVolMA, double varThreshold, bool showLowVol)
		{
			return indicator.HFCRelativeVolumeIndicator(Input, varVolMA, varThreshold, showLowVol);
		}

		public Indicators.HFCRelativeVolumeIndicator HFCRelativeVolumeIndicator(ISeries<double> input , int varVolMA, double varThreshold, bool showLowVol)
		{
			return indicator.HFCRelativeVolumeIndicator(input, varVolMA, varThreshold, showLowVol);
		}
	}
}

#endregion
