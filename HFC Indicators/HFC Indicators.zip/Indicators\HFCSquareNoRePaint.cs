#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class HFCSquareNoRePaint : Indicator
	{
		private SimpleFont errFont;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Plots Square Lines without Repaint";
				Name										= "HFCSquareNoRePaint";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				Weight					= 1;
			}
			else if (State == State.Configure)
			{
				AddDataSeries(BarsPeriodType.Day,1);	
			}
			else if (State == State.DataLoaded)
			{
				if(BarsPeriod.BarsPeriodType != BarsPeriodType.Minute)
				{
					errFont = new SimpleFont("Courier New", 12) { Size = 30, Bold = true };
					Draw.TextFixed(this,"Error","Error : Select Only Minute Period Type for HFC Square to Work!",TextPosition.BottomLeft,Brushes.Red,errFont,Brushes.Red,Brushes.Yellow,60);
					return;
				}

			}			
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
			if (CurrentBar < 8)
				return;
			
			if(BarsPeriod.BarsPeriodType == BarsPeriodType.Minute)
			{
			double Multiplier = (Closes[1][0]/1000 < 0.1) ? 0.01 : 0.1;	
			
			
			double BasePrice = Closes[1][0];
			double RBasePrice = Math.Sqrt(BasePrice);
			Draw.HorizontalLine(this,"GANN0",Math.Pow(RBasePrice,2),Brushes.WhiteSmoke);
			
			double GANN_1 = RBasePrice + (Weight * Multiplier);
			Draw.HorizontalLine(this,"GANN1",Math.Pow(GANN_1,2),Brushes.Red);
			double GANN_1m = RBasePrice - (Weight * Multiplier);
			Draw.HorizontalLine(this,"GANN1m",Math.Pow(GANN_1m,2),Brushes.Green);

			double GANN_2 = RBasePrice + (2 * Weight * Multiplier);
			Draw.HorizontalLine(this,"GANN2",Math.Pow(GANN_2,2),Brushes.OrangeRed);
			double GANN_2m = RBasePrice - (2 * Weight * Multiplier);
			Draw.HorizontalLine(this,"GANN2m",Math.Pow(GANN_2m,2),Brushes.LimeGreen);
			
			double GANN_3 = RBasePrice + (3 * Weight * Multiplier);
			Draw.HorizontalLine(this,"GANN3",Math.Pow(GANN_3,2),Brushes.Orange);
			double GANN_3m = RBasePrice - (3 * Weight * Multiplier);
			Draw.HorizontalLine(this,"GANN3m",Math.Pow(GANN_3m,2),Brushes.GreenYellow);
			
			double GANN_4 = RBasePrice + (4 * Weight * Multiplier);
			Draw.HorizontalLine(this,"GANN4",Math.Pow(GANN_4,2),Brushes.IndianRed);
			double GANN_4m = RBasePrice - (4 * Weight * Multiplier);
			Draw.HorizontalLine(this,"GANN4m",Math.Pow(GANN_4m,2),Brushes.OliveDrab);
			
			double GANN_5 = RBasePrice + (5 * Weight * Multiplier);
			Draw.HorizontalLine(this,"GANN5",Math.Pow(GANN_5,2),Brushes.Salmon);
			double GANN_5m = RBasePrice - (5 * Weight * Multiplier);
			Draw.HorizontalLine(this,"GANN5m",Math.Pow(GANN_5m,2),Brushes.Olive);
			}
			else
			{
				return;
			}				
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(1, double.MaxValue)]
		[Display(Name="Weight", Order=1, GroupName="Parameters")]
		public double Weight
		{ get; set; }
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HFCSquareNoRePaint[] cacheHFCSquareNoRePaint;
		public HFCSquareNoRePaint HFCSquareNoRePaint(double weight)
		{
			return HFCSquareNoRePaint(Input, weight);
		}

		public HFCSquareNoRePaint HFCSquareNoRePaint(ISeries<double> input, double weight)
		{
			if (cacheHFCSquareNoRePaint != null)
				for (int idx = 0; idx < cacheHFCSquareNoRePaint.Length; idx++)
					if (cacheHFCSquareNoRePaint[idx] != null && cacheHFCSquareNoRePaint[idx].Weight == weight && cacheHFCSquareNoRePaint[idx].EqualsInput(input))
						return cacheHFCSquareNoRePaint[idx];
			return CacheIndicator<HFCSquareNoRePaint>(new HFCSquareNoRePaint(){ Weight = weight }, input, ref cacheHFCSquareNoRePaint);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HFCSquareNoRePaint HFCSquareNoRePaint(double weight)
		{
			return indicator.HFCSquareNoRePaint(Input, weight);
		}

		public Indicators.HFCSquareNoRePaint HFCSquareNoRePaint(ISeries<double> input , double weight)
		{
			return indicator.HFCSquareNoRePaint(input, weight);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HFCSquareNoRePaint HFCSquareNoRePaint(double weight)
		{
			return indicator.HFCSquareNoRePaint(Input, weight);
		}

		public Indicators.HFCSquareNoRePaint HFCSquareNoRePaint(ISeries<double> input , double weight)
		{
			return indicator.HFCSquareNoRePaint(input, weight);
		}
	}
}

#endregion
