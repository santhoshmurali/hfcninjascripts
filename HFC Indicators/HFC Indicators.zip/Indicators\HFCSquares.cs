#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class HFCSquares : Indicator
	{
		private SimpleFont errFont;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"This will Plot Line is Nearest Square Values";
				Name										= "HFCSquares";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				Weight					= 1;
				AddPlot(Brushes.Gainsboro,"GANN0");
				
				AddPlot(Brushes.Red, "GANN1");
				AddPlot(Brushes.Green, "GANN1m");

      			AddPlot(Brushes.OrangeRed, "GANN2");
				AddPlot(Brushes.LimeGreen, "GANN2m");

				AddPlot(Brushes.Orange, "GANN3");
				AddPlot(Brushes.GreenYellow, "GANN3m");

				AddPlot(Brushes.IndianRed, "GANN4");
				AddPlot(Brushes.OliveDrab, "GANN4m");
				
				AddPlot(Brushes.Salmon, "GANN5");
				AddPlot(Brushes.Olive, "GANN5m");
			}
			else if (State == State.Configure)
			{
				AddDataSeries(BarsPeriodType.Day,1);	
			}
			else if (State == State.DataLoaded)
			{
				if(BarsPeriod.BarsPeriodType != BarsPeriodType.Minute)
				{
					errFont = new SimpleFont("Courier New", 12) { Size = 30, Bold = true };
					Draw.TextFixed(this,"Error","Error : Select Only Minute Period Type for HFC Square to Work!",TextPosition.BottomLeft,Brushes.Red,errFont,Brushes.Red,Brushes.Yellow,60);
					return;
				}

			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
			if (CurrentBar < 10)
				return;
			
			if(BarsPeriod.BarsPeriodType == BarsPeriodType.Minute)
			{
			double Multiplier = (Closes[1][0]/1000 < 0.1) ? 0.01 : 0.1;	
			
			
			double BasePrice = Closes[1][0];
			double RBasePrice = Math.Sqrt(BasePrice);
			GANN0[0] = Math.Pow(RBasePrice,2);
			
			double GANN_1 = RBasePrice + (Weight * Multiplier);
			GANN1[0] = Math.Pow(GANN_1,2);
			double GANN_1m = RBasePrice - (Weight * Multiplier);
			GANN1m[0] = Math.Pow(GANN_1m,2);			

			double GANN_2 = RBasePrice + (2 * Weight * Multiplier);
			GANN2[0] = Math.Pow(GANN_2,2);
			double GANN_2m = RBasePrice - (2 * Weight * Multiplier);
			GANN2m[0] = Math.Pow(GANN_2m,2);
			
			double GANN_3 = RBasePrice + (3 * Weight * Multiplier);
			GANN3[0] = Math.Pow(GANN_3,2);
			double GANN_3m = RBasePrice - (3 * Weight * Multiplier);
			GANN3m[0] = Math.Pow(GANN_3m,2);
			
			double GANN_4 = RBasePrice + (4 * Weight * Multiplier);
			GANN4[0] = Math.Pow(GANN_4,2);
			double GANN_4m = RBasePrice - (4 * Weight * Multiplier);
			GANN4m[0] = Math.Pow(GANN_4m,2);			
			
			double GANN_5 = RBasePrice + (5 * Weight * Multiplier);
			GANN5[0] = Math.Pow(GANN_5,2);
			double GANN_5m = RBasePrice - (5 * Weight * Multiplier);
			GANN5m[0] = Math.Pow(GANN_5m,2);	
			}
			else
			{
				return;
			}


		}

		#region Properties
		[NinjaScriptProperty]
		[Range(0.001, double.MaxValue)]
		[Display(Name="Weight", Description="Weight to be Applied", Order=1, GroupName="Parameters")]
		public double Weight
		{ get; set; }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> GANN0
		{
			get { return Values[0]; }
		}		


		[Browsable(false)]
		[XmlIgnore]
		public Series<double> GANN1
		{
			get { return Values[1]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> GANN1m
		{
			get { return Values[2]; }
		}

		
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> GANN2
		{
			get { return Values[3]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> GANN2m
		{
			get { return Values[4]; }
		}
		
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> GANN3
		{
			get { return Values[5]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> GANN3m
		{
			get { return Values[6]; }
		}
		
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> GANN4
		{
			get { return Values[7]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> GANN4m
		{
			get { return Values[8]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> GANN5
		{
			get { return Values[9]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> GANN5m
		{
			get { return Values[10]; }
		}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HFCSquares[] cacheHFCSquares;
		public HFCSquares HFCSquares(double weight)
		{
			return HFCSquares(Input, weight);
		}

		public HFCSquares HFCSquares(ISeries<double> input, double weight)
		{
			if (cacheHFCSquares != null)
				for (int idx = 0; idx < cacheHFCSquares.Length; idx++)
					if (cacheHFCSquares[idx] != null && cacheHFCSquares[idx].Weight == weight && cacheHFCSquares[idx].EqualsInput(input))
						return cacheHFCSquares[idx];
			return CacheIndicator<HFCSquares>(new HFCSquares(){ Weight = weight }, input, ref cacheHFCSquares);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HFCSquares HFCSquares(double weight)
		{
			return indicator.HFCSquares(Input, weight);
		}

		public Indicators.HFCSquares HFCSquares(ISeries<double> input , double weight)
		{
			return indicator.HFCSquares(input, weight);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HFCSquares HFCSquares(double weight)
		{
			return indicator.HFCSquares(Input, weight);
		}

		public Indicators.HFCSquares HFCSquares(ISeries<double> input , double weight)
		{
			return indicator.HFCSquares(input, weight);
		}
	}
}

#endregion
