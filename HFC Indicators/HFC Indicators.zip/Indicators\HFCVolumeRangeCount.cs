#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
// This Belongs to Harvest FinCrop. 
// Version : 1.0
// Module : VSA
// Developed By : Santhosh Murali [ santhoshmurali@gmail.com ]
// For Support Contact : Santhosh Murali
// Description : This will basically count the number of Up volumes and Down volumes in the past 'n' candles and plot the graph Accordingly. On top of it, user can apply SMA for UpCount and Down count for smoothened view.
// Date Developed : 13-05-2020

namespace NinjaTrader.NinjaScript.Indicators
{
	public class HFCVolumeRangeCount : Indicator
	{
		private VolumeUpDown myVolUpDown;
		private int UpVolNumber;
		private int DownVolNumber;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"No. of Bull Volume Bars for N-Period, No. of Bear Volume Bars for N-Period, Avg. Bull Volume Bars for N-Period, Avg. Bear Volume Bars for N-Period";
				Name										= "HFCVolumeRangeCount";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				
				NumberOfBarsToLookBack					= 15;
				AddPlot(Brushes.LightGreen, "PlUpCount");
				AddPlot(Brushes.Salmon, "PlDownCount");
				//AddPlot(Brushes.DarkSeaGreen, "PlAvgUpCnt");
				//AddPlot(Brushes.RosyBrown, "PlAvgDownCount");
				//AddPlot(new Stroke(Brushes.DarkSeaGreen, 2), PlotStyle.Line, "PlAvgUpCnt");
				//AddPlot(new Stroke(Brushes.RosyBrown, 2), PlotStyle.Line, "PlAvgDownCount");
			}
			else if (State == State.Configure)
			{
				UpVolNumber = 0;
				DownVolNumber = 0;
			}
			else if (State == State.DataLoaded)
			{
				myVolUpDown = VolumeUpDown();
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
				if (CurrentBar < NumberOfBarsToLookBack+1)
				return;
				for (int i=1;i<=NumberOfBarsToLookBack;i++)
				{
					if (myVolUpDown.UpVolume[i]>0)
					{
						UpVolNumber+=1;
					}
					else if (myVolUpDown.DownVolume[i]>0)
					{
						DownVolNumber+=1;
					}
				}
				PlUpCount[0] = UpVolNumber;
				PlDownCount[0] = DownVolNumber;	
     			UpVolNumber=0;
				DownVolNumber=0;
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Number Of Bars To Look Back", Order=1, GroupName="Parameters")]
		public int NumberOfBarsToLookBack
		{ get; set; }
		

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PlUpCount
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PlDownCount
		{
			get { return Values[1]; }
		}

		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HFCVolumeRangeCount[] cacheHFCVolumeRangeCount;
		public HFCVolumeRangeCount HFCVolumeRangeCount(int numberOfBarsToLookBack)
		{
			return HFCVolumeRangeCount(Input, numberOfBarsToLookBack);
		}

		public HFCVolumeRangeCount HFCVolumeRangeCount(ISeries<double> input, int numberOfBarsToLookBack)
		{
			if (cacheHFCVolumeRangeCount != null)
				for (int idx = 0; idx < cacheHFCVolumeRangeCount.Length; idx++)
					if (cacheHFCVolumeRangeCount[idx] != null && cacheHFCVolumeRangeCount[idx].NumberOfBarsToLookBack == numberOfBarsToLookBack && cacheHFCVolumeRangeCount[idx].EqualsInput(input))
						return cacheHFCVolumeRangeCount[idx];
			return CacheIndicator<HFCVolumeRangeCount>(new HFCVolumeRangeCount(){ NumberOfBarsToLookBack = numberOfBarsToLookBack }, input, ref cacheHFCVolumeRangeCount);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HFCVolumeRangeCount HFCVolumeRangeCount(int numberOfBarsToLookBack)
		{
			return indicator.HFCVolumeRangeCount(Input, numberOfBarsToLookBack);
		}

		public Indicators.HFCVolumeRangeCount HFCVolumeRangeCount(ISeries<double> input , int numberOfBarsToLookBack)
		{
			return indicator.HFCVolumeRangeCount(input, numberOfBarsToLookBack);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HFCVolumeRangeCount HFCVolumeRangeCount(int numberOfBarsToLookBack)
		{
			return indicator.HFCVolumeRangeCount(Input, numberOfBarsToLookBack);
		}

		public Indicators.HFCVolumeRangeCount HFCVolumeRangeCount(ISeries<double> input , int numberOfBarsToLookBack)
		{
			return indicator.HFCVolumeRangeCount(input, numberOfBarsToLookBack);
		}
	}
}

#endregion
