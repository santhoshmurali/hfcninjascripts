#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using System.Runtime;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class HFCVolumeUpDownStrength : Indicator
	{
		private VolumeUpDown myVolumeUpDown;
		private int vIdx;
	
		private double AggVolUp,AggVolDown;
		
		#region AggrigateLogVariables
			private double LogDiff,AvgUp,AvgDown,LogAdjusted;
			
			private double non_zeroUp_volume_count;
			private double non_zeroDown_volume_count;
			
			private int UpIdx, DownIdx=0;
			private Series<double> myUpArray;
			private Series<double> myDownArray;
			
			private double UpVariance, DownVariance, UpStdDev, DownStdDev;
		
			private double StdDevAdjustedAverage;
		#endregion
		
		#region Weights Variables
			private double varH;
			private double varWights;
		
			private double varSpreadChange;
		#endregion
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Using this Indicator will let us know whether Volume on UP Bars or having strength or the down bars. This can we consumed 4 different formats. ";
				Name										= "HFCVolumeUpDownStrength";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				PLookBack					= 14;
				PLog					= false;
				Pdiff					= false;
				PSpreadWings			= true;
				
				AddLine(new Stroke(Brushes.SlateBlue,1),0,"Marker");
				
				#region Plot declaration 
				AddPlot(new Stroke(Brushes.ForestGreen, 2), PlotStyle.Bar, "PltAggUp");
				AddPlot(new Stroke(Brushes.Firebrick, 2), PlotStyle.Bar, "PltAggDown");
				AddPlot(Brushes.Yellow, "PltAggDiff");
				#endregion

			}
			else if (State == State.Configure)
			{
				
				
			}
			else if (State == State.DataLoaded)
			{
				myVolumeUpDown = VolumeUpDown();
				myUpArray = new Series<double>(this);
				myDownArray = new Series<double>(this);
				
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
				if (CurrentBar < PLookBack+1)
				return;			
				myUpArray = new Series<double>(this);
				myDownArray = new Series<double>(this);
				
				#region Code for Normal Aggregate				
				if (pType.ToString() == "NormalAggrigate")
				{
						for (vIdx = 0 ; vIdx < PLookBack; vIdx++) // you always calculate AggVolUp and AggVolDowm irrespective of Scale type.
						{
							AggVolUp = myVolumeUpDown.UpVolume[vIdx]+AggVolUp;
							AggVolDown = (myVolumeUpDown.DownVolume[vIdx]+AggVolDown);
							// Counts the Non-zero up and down volume for calculating actual average. otherwise, 0s will skew the average values.That is also reason why we are not using MA;
							if (myVolumeUpDown.UpVolume[vIdx] > 0 && myVolumeUpDown.DownVolume[vIdx] == 0)
							{
								non_zeroUp_volume_count = non_zeroUp_volume_count + 1;
								myUpArray[UpIdx] = myVolumeUpDown.UpVolume[vIdx];
								UpIdx = UpIdx + 1;
							} 
							else if (myVolumeUpDown.UpVolume[vIdx] == 0 && myVolumeUpDown.DownVolume[vIdx] > 0)
							{
								non_zeroDown_volume_count = non_zeroDown_volume_count + 1;
								myDownArray[DownIdx] = myVolumeUpDown.DownVolume[vIdx];
								DownIdx = DownIdx + 1;
							}
						}
				}
				#endregion
				
				#region Code for Weighted Aggregate
				if (pType.ToString() == "AscendingWeightsAggregate")
				{

					varH = PLookBack;
					for (vIdx = 0 ; vIdx < PLookBack; vIdx++) // you always calculate AggVolUp and AggVolDowm irrespective of Scale type.
						{
							varWights = 1-(1/(1+(Math.Pow(Math.E,varH))));
							varH=varH/2;
							AggVolUp = (varWights*(myVolumeUpDown.UpVolume[vIdx]))+AggVolUp;
							AggVolDown =(varWights*(myVolumeUpDown.DownVolume[vIdx])+AggVolDown);
							// Counts the Non-zero up and down volume for calculating actual average. otherwise, 0s will skew the average values.That is also reason why we are not using MA;
							if (myVolumeUpDown.UpVolume[vIdx] > 0 && myVolumeUpDown.DownVolume[vIdx] == 0)
							{
								non_zeroUp_volume_count = non_zeroUp_volume_count + 1;
								myUpArray[UpIdx] = myVolumeUpDown.UpVolume[vIdx];
								UpIdx = UpIdx + 1;
							} 
							else if (myVolumeUpDown.UpVolume[vIdx] == 0 && myVolumeUpDown.DownVolume[vIdx] > 0)
							{
								non_zeroDown_volume_count = non_zeroDown_volume_count + 1;
								myDownArray[DownIdx] = myVolumeUpDown.DownVolume[vIdx];
								DownIdx = DownIdx + 1;
							}
						}
				}
				#endregion

				#region Price Change Weighted Aggregate
				if (pType.ToString() == "ChangeWeightedAggregate")
				{
					for (vIdx = 0 ; vIdx < PLookBack; vIdx++) // you always calculate AggVolUp and AggVolDowm irrespective of Scale type.
						{
							// Counts the Non-zero up and down volume for calculating actual average. otherwise, 0s will skew the average values.That is also reason why we are not using MA;
							if (myVolumeUpDown.UpVolume[vIdx] > 0 && myVolumeUpDown.DownVolume[vIdx] == 0)
							{
								AggVolUp = ((Close[vIdx]-Open[vIdx])*(myVolumeUpDown.UpVolume[vIdx]))+AggVolUp;
								non_zeroUp_volume_count = non_zeroUp_volume_count + 1;
								myUpArray[UpIdx] = myVolumeUpDown.UpVolume[vIdx];
								UpIdx = UpIdx + 1;
							} 
							else if (myVolumeUpDown.UpVolume[vIdx] == 0 && myVolumeUpDown.DownVolume[vIdx] > 0)
							{
								AggVolDown = ((Open[vIdx]-Close[vIdx])*(myVolumeUpDown.DownVolume[vIdx]))+AggVolDown;
								non_zeroDown_volume_count = non_zeroDown_volume_count + 1;
								myDownArray[DownIdx] = myVolumeUpDown.DownVolume[vIdx];
								DownIdx = DownIdx + 1;
							}
						}
				}
				#endregion				
				
				#region Spread Change Weighted Aggregate
				if (pType.ToString() == "SpreadWeightedAggregate")
				{
					for (vIdx = 0 ; vIdx < PLookBack; vIdx++) // you always calculate AggVolUp and AggVolDowm irrespective of Scale type.
						{
							varSpreadChange = High[0]-Low[0];
							AggVolUp = (varSpreadChange*(myVolumeUpDown.UpVolume[vIdx]))+AggVolUp;
							AggVolDown =(varSpreadChange*(myVolumeUpDown.DownVolume[vIdx])+AggVolDown);
							
							// Counts the Non-zero up and down volume for calculating actual average. otherwise, 0s will skew the average values.That is also reason why we are not using MA;
							if (myVolumeUpDown.UpVolume[vIdx] > 0 && myVolumeUpDown.DownVolume[vIdx] == 0)
							{
								non_zeroUp_volume_count = non_zeroUp_volume_count + 1;
								myUpArray[UpIdx] = myVolumeUpDown.UpVolume[vIdx];
								UpIdx = UpIdx + 1;
							} 
							else if (myVolumeUpDown.UpVolume[vIdx] == 0 && myVolumeUpDown.DownVolume[vIdx] > 0)
							{
								non_zeroDown_volume_count = non_zeroDown_volume_count + 1;
								myDownArray[DownIdx] = myVolumeUpDown.DownVolume[vIdx];
								DownIdx = DownIdx + 1;
							}
						}
				}
				#endregion					
			
				#region Log Adjusted Calculaiton
				if (PLog)
				{	
					// There are times when Average volume is 0, at that time if we take Log, in either case neumarator or denomintor is 0, it will throw "infinity error", so we are limiting to a 
					// Closest minimum integer value to 0, which 1, so that we can avoid inifinity error.
					if (AggVolDown == 0 )
					{
						AggVolDown = 1;
					}
					if (AggVolUp == 0 )
					{
						AggVolUp = 1; 
					}
					
					LogDiff = Math.Log(AggVolUp/AggVolDown,10);
					
					// As we are defaulting 0 to 1 for both neumerator and denominator to avoid log error, this might lead to exceptionaly large Log value, so we are limiting the log value between -1 and 1. 
					if (LogDiff >1)
					{
						LogDiff = 1;
					}
					else if(LogDiff<-1)
					{
						LogDiff = -1;
					}
					
					
					// Average Values
					
					AvgUp = AggVolUp/non_zeroUp_volume_count;
					AvgDown = AggVolDown/non_zeroDown_volume_count;
					
					//Code to Find Standard Variance, there are multiple challenges. Consider the situation below.
					// total volumes bars are 7
					// up is 6
					// down is 1
					// how will you find sd of 1 value, it will be 0, in later part of the program this will throw div by zero error. so we have to keep minimum
					// if there is only one value or 2 same value default the sd to 0.5
					
					// Upvariance
					UpVariance = 0.0;
					if (UpIdx<=1 )
					{
						UpVariance=Math.Pow(myUpArray[0],2);
					}
					else if (UpIdx==2 && myUpArray[0]==myUpArray[1])
					{
						UpVariance=Math.Pow(myUpArray[0],2)/2;
					}
					else
					{
						for(int k = 0; k<UpIdx;k++)
							{
								UpVariance = UpVariance + Math.Pow((myUpArray[k]-AvgUp),2);
							}
						UpVariance = UpVariance/(UpIdx-1);
					}

					//DownVariance
					DownVariance = 0.0;
					if (DownIdx<=1)
					{
						DownVariance=Math.Pow(myDownArray[0],2);
					}
					else if (DownIdx==2 && myDownArray[0]==myDownArray[1])
					{
						DownVariance=Math.Pow(myDownArray[0],2)/2;
					}
					else
					{
						for(int k = 0; k<DownIdx;k++)
							{
								DownVariance = DownVariance + Math.Pow((myDownArray[k]-AvgUp),2);
							}	
						DownVariance = DownVariance/(DownIdx-1);
					}
					
					
					//Up standard deviation
					UpStdDev = Math.Round(Math.Sqrt(UpVariance),2);
					
					//Down standard deviation
					DownStdDev = Math.Round(Math.Sqrt(DownVariance),2);
					
					//Average Adjusted
					StdDevAdjustedAverage = (AvgUp+AvgDown)/(Math.Sqrt(UpStdDev*DownStdDev));
					
					//Log Adjusted
					LogAdjusted = (LogDiff/StdDevAdjustedAverage);
					
				}
				#endregion		
						
				
			#region Display Plots	
			if (!PLog) // If Log is not selected, Show Scalar
			{
				if (!(Pdiff))
				{ //This will show only the difference when Scalar is selected
						
						PltAggUp[0] = AggVolUp;
						// This will Plot the grapgh on the negative scale for coparison. else, we can see one overlaps other. Which ever volume spill out, that has the strength.
						if (PSpreadWings)
						{
							PltAggDown[0] = AggVolDown*-1;
							
						}
						else 
						{
							PltAggDown[0] = AggVolDown;
						}
				}
				else
				{
					PltAggDiff[0] = AggVolUp - AggVolDown;
				}
			}
			else // If log is selected
			{
				if (Math.Round(LogAdjusted,4) > 0)
				{  
					PltAggUp[0] = Math.Round(LogAdjusted,4);
				}
				else
				{
					PltAggDown[0] = Math.Round(LogAdjusted,4);
				}

			}
			#endregion
			
			
			AggVolUp = 0;
			AggVolDown = 0;		
			non_zeroUp_volume_count = 0;
			non_zeroDown_volume_count = 0;
			UpIdx = 0;
			DownIdx = 0;
			myUpArray.Reset();
			myDownArray.Reset();
			
			//GC.Collect();
			
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(2, int.MaxValue)]
		[Display(Name="Look Back", Description="Look back period", Order=1, GroupName="Parameters")]
		public int PLookBack
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="Spread Wings", Order=2, GroupName="Parameters")]
		public bool PSpreadWings
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="Log Scale", Order=3, GroupName="Parameters")]
		public bool PLog
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="Show Only Difference (Overrides Spreadwings)", Order=4, GroupName="Parameters")]
		public bool Pdiff
		{ get; set; }
		
		//Custom Indicator
		[NinjaScriptProperty]
		[Range((int)WTIShared.Enums.pTypes.NormalAggrigate, (int)WTIShared.Enums.pTypes.SpreadWeightedAggregate)]
        [Display(ResourceType = typeof(Custom.Resource), Name = "Calculation Type", GroupName = "Parameters", Order = 3)]
        public WTIShared.Enums.pTypes pType
        { get; set; }
		
		
	
		//Plots
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PltAggUp
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PltAggDown
		{
			get { return Values[1]; }
		}
		
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PltAggDiff
		{
			get { return Values[2]; }
		}

		
		#endregion

	}
}

//Newly Inserted
namespace WTIShared.Enums
{
    public enum pTypes
    {
        NormalAggrigate,
        AscendingWeightsAggregate,
        ChangeWeightedAggregate,
		SpreadWeightedAggregate
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HFCVolumeUpDownStrength[] cacheHFCVolumeUpDownStrength;
		public HFCVolumeUpDownStrength HFCVolumeUpDownStrength(int pLookBack, bool pSpreadWings, bool pLog, bool pdiff, WTIShared.Enums.pTypes pType)
		{
			return HFCVolumeUpDownStrength(Input, pLookBack, pSpreadWings, pLog, pdiff, pType);
		}

		public HFCVolumeUpDownStrength HFCVolumeUpDownStrength(ISeries<double> input, int pLookBack, bool pSpreadWings, bool pLog, bool pdiff, WTIShared.Enums.pTypes pType)
		{
			if (cacheHFCVolumeUpDownStrength != null)
				for (int idx = 0; idx < cacheHFCVolumeUpDownStrength.Length; idx++)
					if (cacheHFCVolumeUpDownStrength[idx] != null && cacheHFCVolumeUpDownStrength[idx].PLookBack == pLookBack && cacheHFCVolumeUpDownStrength[idx].PSpreadWings == pSpreadWings && cacheHFCVolumeUpDownStrength[idx].PLog == pLog && cacheHFCVolumeUpDownStrength[idx].Pdiff == pdiff && cacheHFCVolumeUpDownStrength[idx].pType == pType && cacheHFCVolumeUpDownStrength[idx].EqualsInput(input))
						return cacheHFCVolumeUpDownStrength[idx];
			return CacheIndicator<HFCVolumeUpDownStrength>(new HFCVolumeUpDownStrength(){ PLookBack = pLookBack, PSpreadWings = pSpreadWings, PLog = pLog, Pdiff = pdiff, pType = pType }, input, ref cacheHFCVolumeUpDownStrength);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HFCVolumeUpDownStrength HFCVolumeUpDownStrength(int pLookBack, bool pSpreadWings, bool pLog, bool pdiff, WTIShared.Enums.pTypes pType)
		{
			return indicator.HFCVolumeUpDownStrength(Input, pLookBack, pSpreadWings, pLog, pdiff, pType);
		}

		public Indicators.HFCVolumeUpDownStrength HFCVolumeUpDownStrength(ISeries<double> input , int pLookBack, bool pSpreadWings, bool pLog, bool pdiff, WTIShared.Enums.pTypes pType)
		{
			return indicator.HFCVolumeUpDownStrength(input, pLookBack, pSpreadWings, pLog, pdiff, pType);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HFCVolumeUpDownStrength HFCVolumeUpDownStrength(int pLookBack, bool pSpreadWings, bool pLog, bool pdiff, WTIShared.Enums.pTypes pType)
		{
			return indicator.HFCVolumeUpDownStrength(Input, pLookBack, pSpreadWings, pLog, pdiff, pType);
		}

		public Indicators.HFCVolumeUpDownStrength HFCVolumeUpDownStrength(ISeries<double> input , int pLookBack, bool pSpreadWings, bool pLog, bool pdiff, WTIShared.Enums.pTypes pType)
		{
			return indicator.HFCVolumeUpDownStrength(input, pLookBack, pSpreadWings, pLog, pdiff, pType);
		}
	}
}

#endregion
