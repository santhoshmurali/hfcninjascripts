#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
// This Belongs to Harvest FinCrop. 
// Version : 1.0
// Developed By : Santhosh Murali [ santhoshmurali@gmail.com ]
// For Support Contact : Santhosh Murali
// Description : This indicator Uses Custom Developed Harvest FinCrop's Bollinger Bands Percentage. 
//					- It plots Red, when Bollinger Bands Percentage (BB%) touches over bought (>100%) and reverses.It Continues to Plot "Red" untill Bollinger Band Percentge breaches Over Sold (<0%). 
//					- It starts to plot Blue, When BB% Touches and reverses Over Sold (<0%) and Continues to plot Blue, untill it reaches Overbought BB% (>100%)
//                  - Overlay Green Dotted Line indicates Threshold limits we cen enter long. This is based on BB% value. By default We have set as 0.7 maximum for Long.
//                  - Overlay Red Dotted Line indicates Threshold limits we cen enter Short. This is based on BB% value. By default We have set as 0.3 Minimum for Short.


namespace NinjaTrader.NinjaScript.Indicators
{
	public class HFCBollingerTrendCycle : Indicator
	{
		private HFCBollingerBandsPercentage myHFCBollingerBandsPercentage;
		private double XtrimStdDevLong;
		private double XtrimStdDevShort;
		private double XtrimStdDev;
		private double TrendCycle;	
		
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"This indicator Uses Custom Developed Harvest FinCrop's Bollinger Bands Percentage. This indicates Reversals in BB%.";
				Name										= "HFCBollingerTrendCycle";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Left;
				
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				Length					= 20;
				StdDev					= 2.0;
				XtrimStdDev	 			= 0;
				XtrimStdDevLong			= 0.0;
				XtrimStdDevShort		= 0.0;
				LongThreshold			= 0.7;
				ShortThreshold			= 0.3;
				AddPlot(Brushes.DodgerBlue, "HFCXtrimStdDevLong");
				AddPlot(Brushes.Coral, "HFCXtrimStdDevShort");
				AddPlot(new Stroke(Brushes.BlueViolet),PlotStyle.Line,"HFCTrendCycle");
			}
			else if (State == State.Configure)
			{
			}
			else if (State == State.DataLoaded)
			{
				myHFCBollingerBandsPercentage = HFCBollingerBandsPercentage(Length,StdDev);
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
			if (CurrentBar < 3)
				return;
			// Test if Bollinger Bands % Is Above 1 and is a spike. It sets XtrimStdDev to a Positive Number
			if (myHFCBollingerBandsPercentage.HFCBBPercent[1] > 1 && myHFCBollingerBandsPercentage.HFCBBPercent[1] > myHFCBollingerBandsPercentage.HFCBBPercent[0] && myHFCBollingerBandsPercentage.HFCBBPercent[1] > myHFCBollingerBandsPercentage.HFCBBPercent[2] )
			   {
					Draw.Dot(this,Time[0].ToString(),true,0,Close[0],Brushes.Aqua);
					XtrimStdDev = myHFCBollingerBandsPercentage.HFCBBPercent[1];
				    //TrendCycle = Close[0];
			   }
			
			// Test if Bollinger Bands % Is Below 0 and is a Dip.It sets XtrimStdDev to a Negative Number
			if (myHFCBollingerBandsPercentage.HFCBBPercent[1] < 0 && myHFCBollingerBandsPercentage.HFCBBPercent[1] < myHFCBollingerBandsPercentage.HFCBBPercent[0] && myHFCBollingerBandsPercentage.HFCBBPercent[1] < myHFCBollingerBandsPercentage.HFCBBPercent[2])
				{
					Draw.Dot(this,Time[0].ToString(),true,0,Close[0],Brushes.Red);	
					//TrendCycle = Close[0];
					XtrimStdDev = myHFCBollingerBandsPercentage.HFCBBPercent[1];
				}
			TrendCycle = (XtrimStdDev>=0) ? -1 : 1; // We are switching the Sign because, when XtrimStdDev, 
													//It means that We have rached Over Bought and chances are
													//that trend may revrese and vise versa.
			
			// Which means Long Possibility.
			if (TrendCycle == 1)
			{
				Draw.Line(this,Time[0].ToString(),true,1,Low[1],0,Low[0],Brushes.Blue,DashStyleHelper.Solid,2);
				// This will ensure we are not entering during short reversal.
				if (myHFCBollingerBandsPercentage.HFCBBPercent[0] <= LongThreshold)
				{
					Draw.Line(this,"Long"+Time[0].ToString(),true,1,Low[1]-(Low[1]*.003),0,Low[0]-(Low[1]*.003),Brushes.LawnGreen,DashStyleHelper.Dash,3);
					XtrimStdDevLong = myHFCBollingerBandsPercentage.HFCBBPercent[0];
				}
				else
				{
					XtrimStdDevLong = 0.0;
				}
			}
			else
			// Which means Short Possibility.
			{
				Draw.Line(this,Time[0].ToString(),true,1,High[1],0,High[0],Brushes.Red,DashStyleHelper.Solid,2);
				// This will ensure we are not entering during Long reversal.
				if (myHFCBollingerBandsPercentage.HFCBBPercent[0] >= ShortThreshold)
				{
					Draw.Line(this,"Short"+Time[0].ToString(),true,1,High[1]+(High[1]*.003),0,High[0]+(High[1]*.003),Brushes.Coral,DashStyleHelper.Dash,3);
					XtrimStdDevShort = myHFCBollingerBandsPercentage.HFCBBPercent[0];
				}
				else
				{
					XtrimStdDevShort = 0.0;
				}
			}
			// Plotting
			HFCTrendCycle[0] = TrendCycle;
			HFCXtrimStdDevLong[0] = XtrimStdDevLong;
			HFCXtrimStdDevShort[0] = XtrimStdDevShort;
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Length", Order=1, GroupName="Parameters")]
		public int Length
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1.0, double.MaxValue)]
		[Display(Name="StdDev", Order=2, GroupName="Parameters")]
		public double StdDev
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(0.0, 1.0)]
		[Display(Name="Long Threshold", Order=1, GroupName="Parameters")]
		public double LongThreshold
		{ get; set; }		

		[NinjaScriptProperty]
		[Range(0.0, 1.0)]
		[Display(Name="Short Threshold", Order=1, GroupName="Parameters")]
		public double ShortThreshold
		{ get; set; }		
		
		
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> HFCXtrimStdDevLong
		{
			get { return Values[0]; }
		}
		
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> HFCXtrimStdDevShort
		{
			get { return Values[1]; }
		}
		
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> HFCTrendCycle
		{
			get { return Values[2]; }
		}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HFCBollingerTrendCycle[] cacheHFCBollingerTrendCycle;
		public HFCBollingerTrendCycle HFCBollingerTrendCycle(int length, double stdDev, double longThreshold, double shortThreshold)
		{
			return HFCBollingerTrendCycle(Input, length, stdDev, longThreshold, shortThreshold);
		}

		public HFCBollingerTrendCycle HFCBollingerTrendCycle(ISeries<double> input, int length, double stdDev, double longThreshold, double shortThreshold)
		{
			if (cacheHFCBollingerTrendCycle != null)
				for (int idx = 0; idx < cacheHFCBollingerTrendCycle.Length; idx++)
					if (cacheHFCBollingerTrendCycle[idx] != null && cacheHFCBollingerTrendCycle[idx].Length == length && cacheHFCBollingerTrendCycle[idx].StdDev == stdDev && cacheHFCBollingerTrendCycle[idx].LongThreshold == longThreshold && cacheHFCBollingerTrendCycle[idx].ShortThreshold == shortThreshold && cacheHFCBollingerTrendCycle[idx].EqualsInput(input))
						return cacheHFCBollingerTrendCycle[idx];
			return CacheIndicator<HFCBollingerTrendCycle>(new HFCBollingerTrendCycle(){ Length = length, StdDev = stdDev, LongThreshold = longThreshold, ShortThreshold = shortThreshold }, input, ref cacheHFCBollingerTrendCycle);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HFCBollingerTrendCycle HFCBollingerTrendCycle(int length, double stdDev, double longThreshold, double shortThreshold)
		{
			return indicator.HFCBollingerTrendCycle(Input, length, stdDev, longThreshold, shortThreshold);
		}

		public Indicators.HFCBollingerTrendCycle HFCBollingerTrendCycle(ISeries<double> input , int length, double stdDev, double longThreshold, double shortThreshold)
		{
			return indicator.HFCBollingerTrendCycle(input, length, stdDev, longThreshold, shortThreshold);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HFCBollingerTrendCycle HFCBollingerTrendCycle(int length, double stdDev, double longThreshold, double shortThreshold)
		{
			return indicator.HFCBollingerTrendCycle(Input, length, stdDev, longThreshold, shortThreshold);
		}

		public Indicators.HFCBollingerTrendCycle HFCBollingerTrendCycle(ISeries<double> input , int length, double stdDev, double longThreshold, double shortThreshold)
		{
			return indicator.HFCBollingerTrendCycle(input, length, stdDev, longThreshold, shortThreshold);
		}
	}
}

#endregion
