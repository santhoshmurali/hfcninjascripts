#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class EngeyoKumaranBullish : Strategy
	{
		private EMA myEMA;
		private CurrentDayOHL  myCurrentDayOHL;
		
		private bool UpTrend;
		private bool FirstCross;
		
		private int hours;
		private int minutes;		
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Based on Range Breakout";
				Name										= "EngeyoKumaranBullish";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				Length					= 1;
				
				FirstCross = false;
				UpTrend = false;
				
				hours = 0;
				minutes = 0;				
			}
			else if (State == State.Configure)
			{
				myEMA = EMA(Length);
				myCurrentDayOHL = CurrentDayOHL();
			}
			else if (State == State.DataLoaded)
			{
				AddChartIndicator(myEMA);
				AddChartIndicator(myCurrentDayOHL);
				
			}
		}

		protected override void OnBarUpdate()
		{
			hours = Int16.Parse(Time[0].ToString().Substring(11,2));
			minutes = Int16.Parse(Time[0].ToString().Substring(14,2));
			//Add your custom strategy logic here.
			if(CurrentBar<BarsRequiredToTrade)
				return;
			
			/*if (CrossAbove(Close,myEMA,1))
			{
				UpTrend = true;
				FirstCross=false;
			}
			
			if (CrossBelow(Close,myEMA,1))
			{
				UpTrend = false;
				
			}*/
			if (Close[1]>myEMA.Value[1])
			{
				UpTrend = true;
			}
			else
			{
				UpTrend = false;
			}
			
			if(UpTrend)
			{
				Print(Close[1] + " --- " + myCurrentDayOHL.CurrentOpen[0] + " --- " + (Close[1] > myCurrentDayOHL.CurrentOpen[1]) );
				if ((Close[1] > myCurrentDayOHL.CurrentOpen[1]) && !(FirstCross))
				{
					EnterLong();
					FirstCross=true;
				}
				if ((Close[1] < myCurrentDayOHL.CurrentOpen[1]) && (FirstCross))
				{
					FirstCross=false;
					ExitLong();
				}
				if (hours == 15 && minutes>=15)
				{
					FirstCross=false;
					ExitLong();
				}
			}
			
			
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Length", Order=1, GroupName="Parameters")]
		public int Length
		{ get; set; }
		#endregion

	}
}
