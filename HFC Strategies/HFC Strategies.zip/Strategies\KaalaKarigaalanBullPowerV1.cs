#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
// This is the property of Harvest FinCrop. 
// Version : 1.0
// Strategy Design By : Arun Murali [ arunmurali@hotmail.com ]
// Developed By : Santhosh Murali [ santhoshmurali@gmail.com ]
// For Support Contact : Arun Murali or Santhosh Murali
// Description : This is Long Only Strategy which will be powerful when Market is trading Bullish. It is tested Mainly on NIFTY50. Please Refer the doucument in cloud for More Information [tbd].
//				Intution
//					LONG
//						1. While Market is trading below Above Range (MotherMovingAverage) MA of High prices (We have Considered 100 as default), it is assumed that market is in Up Trend.
//								(Trend is Considered as Long untill price breaches MA of Low Prices)
//						2. When Market is in Uptrend as per step 1, Then we should start looking for Long Positions.
//						3. Entry is based on ADXs (DMs) DiPlus (Di+) and DiMinus(Di-) crossovers.
//						4. When Di+ crosses above Di-, Enter Long. Here We should Ignore Ist Signal in UpTrend and Enter only in Second Crossover.
//						5. When Di- Crosses Below 10.00 Threshold or Di+ Crosses Above 40 Threshold then Exit.
//						6. Stop Loss Technique, If Price is tradig below MA(20) [Which can be modified] and Crosses below the 1.5 times of difference  Mother Moving Average High and low. 
//			Strength :  It catches almost all Major Up trends, and little room for incorrect signals and even if it gives false signal, loss is limited.
//						Ignores impulsive signals diring Market Opening.
//			Weakness :  Some of the Major Down Trends are Missed.
//
// Tested In:
//			1. NIFTY 50.
// Tested Time Frame :
//			1. 3 min
namespace NinjaTrader.NinjaScript.Strategies
{
	public class KaalaKarigaalanBullPowerV1 : Strategy
	{
		private SMA mySMAL;
		private SMA mySMAH;
		private SMA mySMASL;
		private DM myDM;
		//private HFCFibInSquares myHFCFibInSquares;
		
		private double smaHighPlus;
		private bool UpTrend;
		private string SignalName;
		private int NumberOfDMplusCrossAboves;
		private int hours;
		private int minutes;		
		private double SqrFibPrice;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Kaala Karigaalan Bullish Power, Gives signal during UpTrend. It might not give many Signals, but whenever it gives, it gives the Best.";
				Name										= "KaalaKarigaalanBullPowerV1";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				
				//Entry Params
				MotherMovingAverage					= 50;
				DMILength = 14;
				
				//Exit Params
				DIMinusTheshold = 10;
				DIPlusTheshold = 40;
				
				//SL Params
				HLMulti = 1.5;
				SLMALength = 20;
				
				//Variables
				UpTrend = false;
				SignalName = "";
				smaHighPlus = 0.0;
				NumberOfDMplusCrossAboves = 0; // This will help in filtering out first cross overs.
				hours = 0;
				minutes = 0;
				
				SqrFibPrice = 1;
			}
			else if (State == State.Configure)
			{
				mySMAL = SMA(Low,MotherMovingAverage);
				mySMAH = SMA(High,MotherMovingAverage);
				mySMASL = SMA(SLMALength);
				myDM = DM(DMILength);
				//myRSI = RSI(RSILength,RSILength);
				//myHFCFibInSquares = HFCFibInSquares(SqrFibPrice);
				
				AddPlot(Brushes.BlueViolet,"MAHighPlus");				
			}
			else if (State == State.DataLoaded)
			{
				AddChartIndicator(mySMAL);
				AddChartIndicator(mySMAH);
				AddChartIndicator(myDM);
				AddChartIndicator(mySMASL);
				//AddChartIndicator(myHFCFibInSquares);
			
				
				mySMAL.Plots[0].Brush = Brushes.Orange;
				mySMAH.Plots[0].Brush = Brushes.OrangeRed;
			}			
		}

		protected override void OnBarUpdate()
		{
			// Gets the Hours and Minutes which is used to filter the entry later
			hours = Int16.Parse(Time[0].ToString().Substring(11,2));
			minutes = Int16.Parse(Time[0].ToString().Substring(14,2));
			
			if (CurrentBar < BarsRequiredToTrade)
				return;

			
			
			//Captures all Downtrend
			if (CrossAbove(Close,mySMAH,1))
			{
				UpTrend = true;
				
				Draw.Dot(this,"UpTrend" + Time[0].ToString(),true,0,High[0],Brushes.BlueViolet);
			}
			
			if (CrossBelow(Close,mySMAL,1))
			{
				UpTrend = false;
				
				NumberOfDMplusCrossAboves = 0;
			}
			
			//myHFCFibInSquares = HFCFibInSquares(SqrFibPrice);
			// Sets High-Low Difference Multiplier
			smaHighPlus = mySMAH[0] + ((mySMAH[0] - mySMAL[0])*HLMulti);
			MAHighPlus[0] = smaHighPlus;
			
			
			// Code for Entry, Exit and SL
			if (UpTrend)
			{
			    //Entry
				if (CrossAbove(myDM.DiPlus,myDM.DiMinus,1) )
				{
					if (/*NumberOfDMplusCrossAboves != 0 &&*/ (hours>=9 && minutes > 30 ))
					{
						SignalName = "EnterLong"+Time[0].ToString();	
						EnterLong(SignalName);	
					}
					NumberOfDMplusCrossAboves=NumberOfDMplusCrossAboves + 1;
				}
				
				//Exit
				if (CrossBelow(myDM.DiMinus,DIPlusTheshold,1) || CrossAbove(myDM.DiPlus,DIMinusTheshold,1))
				{
					Draw.Dot(this,"ExitLong" + Time[0].ToString(),true,0,High[0],Brushes.OrangeRed);
					ExitLong(SignalName);
					SignalName = "";					
				}
				
				//Stop Loss
				if (Close[1] < mySMASL[1] && CrossBelow(Close,MAHighPlus,1))
				{
					Draw.Dot(this,"StopLoss" + Time[0].ToString(),true,0,High[0],Brushes.Red);
					ExitLong(SignalName);
					SignalName = "";
				}
			}
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(50, int.MaxValue)]
		[Display(Name="Trend Decider MA Length", Description="Trend Decider", Order=1, GroupName="Entry Parameters")]
		public int MotherMovingAverage
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="DMI Length", Order=2, GroupName="Entry Parameters")]
		public int DMILength
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(1, 100)]
		[Display(Name="DI Negative Threshold", Description="Trend Decider", Order=3, GroupName="Exit Parameters")]
		public int DIMinusTheshold
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, 100)]
		[Display(Name="DI Positive Threshold", Order=4, GroupName="Exit Parameters")]
		public int DIPlusTheshold
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(0.1, 5.0)]
		[Display(Name="High-Low Difference Multiplier", Description="Trend Decider", Order=5, GroupName="Stop-Loss Parameters")]
		public double HLMulti
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, 100)]
		[Display(Name="SL Moving Average Length", Order=6, GroupName="Stop-Loss Parameters")]
		public int SLMALength
		{ get; set; }		
				
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> MAHighPlus
		{
			get { return Values[0]; }
		}		
		#endregion
	}
}
