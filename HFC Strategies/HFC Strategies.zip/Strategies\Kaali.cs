#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
// This is the property of Harvest FinCrop. 
// Version : 1.0
// Strategy Design By : Arun Murali [ arunmurali@hotmail.com ]
// Developed By : Santhosh Murali [ santhoshmurali@gmail.com ]
// For Support Contact : Arun Murali or Santhosh Murali
// Description : Tested only on Banknify.
//				Intution
//					LONG
//						1. When Bollinger Bands % (BB%) Goes from Negative to Above 0 (Basically, Crosses above 0)
//						2. And, While BB% is ranging between 0 and 0.7 (Configurable)
//						3. And, when Price Closes above Donchain Channel's Median line.
//						Enter LONG
//						1. When Price Closes Above Bollinger Bands +2 StdDev (Configurable),
//						Exit LONG
//
//					SHORT
//						1. When Bollinger Bands % (BB%) Goes from Above to Below 1 (Basically, Crosses below 1)
//						2. And, While BB% is ranging between 1 and 0.3 (Configurable)
//						3. And, when Price Closes below Donchain Channel's Median line.
//						Enter SHORT
//						1. When Price Closes Below Bollinger Bands -2 StdDev (Configurable),
//						Cover SHORT
//
//                  Strength : 1. Best for Intraday Trading.
//							   2. Continous Signals (Long and Short)
//							   3. Signifiacnt move is captured even in counter move.
//					Weakness : 1. Price tends to move in opposite direction from Strategi'es Signal and returns back to meet the signal provided by the Strategy. 
//							      This may be a limitaion for the people who have little capital as this might hit their SL.
//							
//					Important Note : We are Using HFCBollingerTrendCycle extensively. This indicator is designed exlusively for this strategy.
//					The Intution behind this Strategy can be understood in refrerence to HFCBollingerTrendCycle Indicator.
//
// Tested In:
//			1. BankNifty
// Tested Time Frame :
//			1. 3 min
namespace NinjaTrader.NinjaScript.Strategies.CustomStrategy
{
	public class Kaali : Strategy
	{
		private HFCBollingerTrendCycle myHFCBollingerTrendCycle;
		private DonchianChannel myDonchianChannel;
		private Bollinger myBollinger;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"For Long, When BB% breaks Configured Standard Deviation (oversold line)and bounces back to Normal Zone, We will wait till price cross median line of Donchain indicator, then Enter, and when price hits the  over bought BB%, then exit. same in opposite for short.";
				Name										= "Kaali";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				BBPLength					= 20;
				BBPStandardDeviation					= 2;
				DonChainLength					= 20;
				BBLength					= 20;
				BBStandardDeviation					= 2;
				LongThreshold				= 0.7;
				ShortThreshold				= 0.3;
				AddPlot(Brushes.Orange, "HFCMyPlot");
			}
			else if (State == State.Configure)
			{
			}
			else if (State == State.DataLoaded)
			{
				myHFCBollingerTrendCycle = HFCBollingerTrendCycle(BBPLength,BBPStandardDeviation,LongThreshold,ShortThreshold);
				myBollinger = Bollinger(BBStandardDeviation,BBLength);
				myDonchianChannel =  DonchianChannel(DonChainLength);
				
				//AddChartIndicator(myHFCBollingerTrendCycle);
				//AddChartIndicator(myBollinger);
				//AddChartIndicator(myDonchianChannel);
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom strategy logic here.
			if (CurrentBar < BarsRequiredToTrade)
				return;
			//Long
			 
			if (myHFCBollingerTrendCycle.HFCTrendCycle[0] == 1 && myHFCBollingerTrendCycle.HFCXtrimStdDevLong[0] != 0)
			{
				if(CrossAbove(Close,myDonchianChannel.Mean,1))
				{
					EnterLong();
					Alert("EnterLong", Priority.High, "Possibility for Long!!!", NinjaTrader.Core.Globals.InstallDir+@"\sounds\Alert1.wav", 60, Brushes.Black, Brushes.Yellow);  
				}
			}
			
			if(CrossAbove(Close,myBollinger.Upper,1))
			{
				ExitLong();
			}
			
			//Short
			if (myHFCBollingerTrendCycle.HFCTrendCycle[0] != 1 && myHFCBollingerTrendCycle.HFCXtrimStdDevShort[0] != 0)
			{
				if(CrossBelow(Close,myDonchianChannel.Mean,1))
				{
					EnterShort();
					Alert("EnterShort", Priority.High, "Possibility for Short!!!", NinjaTrader.Core.Globals.InstallDir+@"\sounds\Alert1.wav", 60, Brushes.Black, Brushes.Yellow);  
				}
			}
			
			if(CrossBelow(Close,myBollinger.Lower,1))
			{
				ExitShort();
			}
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="BB% - Length", Description="Length for BB%", Order=1, GroupName="Parameters")]
		public int BBPLength
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, double.MaxValue)]
		[Display(Name="BB% - StdDev", Description="BB% StdDeviaiton", Order=2, GroupName="Parameters")]
		public double BBPStandardDeviation
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="DonChian - Length", Order=3, GroupName="Parameters")]
		public int DonChainLength
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="BB - Length", Description="Bollinger Band Length", Order=4, GroupName="Parameters")]
		public int BBLength
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, double.MaxValue)]
		[Display(Name="BB - StdDev", Description="Bollinger Bands Standard Deviaiton", Order=5, GroupName="Parameters")]
		public double BBStandardDeviation
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(0.0, 1.0)]
		[Display(Name="Long Threshold", Order=6, GroupName="Parameters")]
		public double LongThreshold
		{ get; set; }		

		[NinjaScriptProperty]
		[Range(0.0, 1.0)]
		[Display(Name="Short Threshold", Order=7, GroupName="Parameters")]
		public double ShortThreshold
		{ get; set; }		

		
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> HFCMyPlot
		{
			get { return Values[0]; }
		}
		#endregion

	}
}
