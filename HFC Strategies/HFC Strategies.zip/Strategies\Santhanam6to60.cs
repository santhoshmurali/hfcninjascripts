#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class Santhanam6to60 : Strategy
	{
		private SMA mySMALong;
		private SMA mySMAMedium;
		private SMA mySMAShort;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"This is a long term trend strategy";
				Name										= "Santhanam6to60";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				SMALong					= 50;
				SMAMedium					= 30;
				SMAShort					= 20;
				BBLength					= 33;
				BBStdDev					= 1;
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom strategy logic here.
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(50, int.MaxValue)]
		[Display(Name="SMALong", Description="Long Term SMA", Order=1, GroupName="Parameters")]
		public int SMALong
		{ get; set; }

		[NinjaScriptProperty]
		[Range(30, int.MaxValue)]
		[Display(Name="SMAMedium", Description="Medium SMA", Order=2, GroupName="Parameters")]
		public int SMAMedium
		{ get; set; }

		[NinjaScriptProperty]
		[Range(20, int.MaxValue)]
		[Display(Name="SMAShort", Description="ShortTermSMA", Order=3, GroupName="Parameters")]
		public int SMAShort
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="BBLength", Description="Bollinger Bands Length", Order=4, GroupName="Parameters")]
		public int BBLength
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="BBStdDev", Description="Bollinger Bands Standard Deviation", Order=5, GroupName="Parameters")]
		public int BBStdDev
		{ get; set; }
		#endregion

	}
}
